package com.example.fyp_garageku.customer.registration

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.fyp_garageku.R
import com.example.fyp_garageku.VerifyEmail
import com.example.fyp_garageku.databinding.FragmentCustRegistrationBinding
import com.example.fyp_garageku.dataclass.Customers
import com.example.fyp_garageku.dataclass.Users
import com.example.fyp_garageku.helper_class.Hash
import com.example.fyp_garageku.helper_class.SendEmail
import com.example.fyp_garageku.helper_class.Validation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.StdOutSqlLogger
import org.jetbrains.exposed.sql.addLogger
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import java.text.SimpleDateFormat
import java.util.*


class RegistrationFragment : Fragment() {
    private lateinit var registrationViewModel: RegistrationViewModel
    private var _binding: FragmentCustRegistrationBinding? = null
    private val binding get() = _binding!!
    private val helper = Hash()
    private var code = 0
    private val validator = Validation()
    companion object {
        fun newInstance() = RegistrationFragment()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentCustRegistrationBinding.inflate(inflater, container, false)
        val view = binding.root
        val hashedPw = helper.getSHA512(binding.registrationTxtPW.text?.trim().toString())
        var isSent: Boolean

        binding.registrationTxtEmail.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {
                validateEmail()
            }
        })

        binding.registrationTxtPhone.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {
                validatePhone()
            }
        })

        binding.registrationTxtPW.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {
                validatePW()
            }
        })

        binding.registrationTxtUsername.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {
                validateUsername()
            }
        })

        binding.registerBtnRegister.setOnClickListener {
            if(validation()) {
                binding.custRegProgressLayout.bringToFront()
                binding.custRegProgressLayout.visibility = View.VISIBLE
                val sender = SendEmail()
                val job = GlobalScope.launch() {
                    val (isEmailExist, isUsernameExist) = withContext(Dispatchers.IO) { isEmailExist() }
                    if (!isEmailExist && !isUsernameExist) {
                        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
                        code = Random(System.nanoTime()).nextInt(999999 - 100000 + 1) + 100000
                        val currentDate = sdf.format(Date())
                        val senderEmail = activity?.getString(R.string.official_email).toString()
                        val password = activity?.getString(R.string.email_pw).toString()
                        val recipient = binding.registrationTxtEmail.text.toString()
                        val subject = "Registration Email Verification"
                        val message = "Dear ${binding.registrationTxtUsername.text}, \n" +
                                "Thank you for registering at " + getString(R.string.company_name) +
                                "\nWe have received your registration on $currentDate.\n" +
                                "Verification Code: " + "$code"
                        isSent = withContext(Dispatchers.IO) {
                            sender.sendEmail(
                                senderEmail,
                                password,
                                recipient,
                                message,
                                subject
                            )
                        }
                        withContext(Dispatchers.Main) {
                            if (isSent) {
                                val intent = Intent(activity, VerifyEmail::class.java)
                                intent.putExtra(
                                    "email",
                                    binding.registrationTxtEmail.text?.trim().toString()
                                )
                                intent.putExtra("password", hashedPw)
                                intent.putExtra(
                                    "username",
                                    binding.registrationTxtUsername.text?.trim().toString()
                                )
                                intent.putExtra(
                                    "phone",
                                    binding.registrationTxtPhone.text?.trim().toString()
                                )

                                val selectedId: Int =
                                    binding.registerRadGrpGender.checkedRadioButtonId
                                val radioButton = activity?.findViewById<RadioButton>(selectedId)
                                intent.putExtra("gender", radioButton?.text.toString())
                                intent.putExtra("verificationCode", code)
                                startActivity(intent)
                                binding.custRegProgressLayout.visibility = View.GONE
                            }
                            binding.custRegProgressLayout.visibility = View.GONE
                        }
                    } else if (isEmailExist) {
                        withContext(Dispatchers.Main) {
                            Toast.makeText(
                                activity,
                                "The email has been registered!",
                                Toast.LENGTH_LONG
                            ).show()
                            binding.registrationEmail.error =
                                getString(R.string.existed_email_error)
                            binding.custRegProgressLayout.visibility = View.GONE
                        }
                    } else {
                        withContext(Dispatchers.Main) {
                            Toast.makeText(
                                activity,
                                "The username has been registered!",
                                Toast.LENGTH_LONG
                            ).show()
                            binding.registrationEmail.error =
                                getString(R.string.existed_email_error)
                            binding.custRegProgressLayout.visibility = View.GONE
                        }
                    }
                }
            }
        }
        return view
    }

    private suspend fun isEmailExist():Pair<Boolean,Boolean>{
        var existEmail = false
        var existUsername = false
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)
                val user = Users.selectAll().forEach {
                    if (it[Users.email] == binding.registrationTxtEmail.text?.trim().toString()) {
                        existEmail = true
                    }
                }
                val cust = Customers.selectAll().forEach {
                    if (it[Customers.cust_name] == binding.registrationTxtUsername.text?.trim().toString()){
                        existUsername = true
                    }
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
        return Pair(existEmail,existUsername)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        registrationViewModel = ViewModelProvider(this).get(RegistrationViewModel::class.java)
        // TODO: Use the ViewModel
    }

    private fun validateUsername():Boolean{
        return  !validator.isNull(
            binding.registrationTxtUsername.text?.trim().toString(),
            binding.registrationUsername
        )
    }

    private fun validateEmail():Boolean{
        return  !validator.isNull(
            binding.registrationTxtEmail.text?.trim().toString(),
            binding.registrationEmail
        )
    }

    private fun validatePW():Boolean{
        return validator.isPassword(
            binding.registrationTxtPW.text?.trim().toString(),
            binding.registrationPw
        ) && !validator.isNull(
            binding.registrationTxtPW.text?.trim().toString(),
            binding.registrationPw
        )
    }
    private fun validatePhone():Boolean{
        return !validator.isNull(
            binding.registrationTxtPhone.text?.trim().toString(),
            binding.registrationPhone
        ) && validator.isPhone(
            binding.registrationTxtPhone.text?.trim().toString(),
            binding.registrationPhone
        )
    }

    private fun validation():Boolean{
        return validateEmail() && validatePW() && validatePhone() && validateUsername()
    }
}