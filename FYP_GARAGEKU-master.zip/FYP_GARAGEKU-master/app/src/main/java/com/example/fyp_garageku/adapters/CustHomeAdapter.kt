package com.example.fyp_garageku.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.fyp_garageku.R
import com.example.fyp_garageku.customer.ViewAllWorkshop
import com.example.fyp_garageku.customer.WorkshopDetails
import com.example.fyp_garageku.dataclass.HomeData
import com.squareup.picasso.Picasso

class CustHomeAdapter(private val context: Context,
                      private val dataset : List<HomeData>,
                      private val type:String
) : RecyclerView.Adapter<CustHomeAdapter.ItemViewHolder>() {

    class ItemViewHolder(private val view : View) : RecyclerView.ViewHolder(view) {
        val img : ImageView = view.findViewById(R.id.home_img)
        val txtName : TextView = view.findViewById(R.id.home_label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(context)
            .inflate(R.layout.item_home, parent, false)

        return ItemViewHolder(adapterLayout)
    }
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        holder.txtName.text = item.name
        when (type) {
            "service" -> {
                Picasso.get()
                    .load("http://test.onmyfinger.com/images/service${item.id}.jpg")
                    .placeholder(R.drawable.placeholder)
                    .error(R.drawable.placeholder)
                    .into(holder.img)
            }
            "workshop" -> {
                Picasso.get()
                    .load("http://test.onmyfinger.com/images/merchant${item.id}displaypicture.jpg")
                    .placeholder(R.drawable.placeholder)
                    .error(R.drawable.placeholder)
                    .into(holder.img)
            }
        }

        holder.itemView.setOnClickListener{
            when (type) {
                "service" -> {
                    val intent = Intent(context, ViewAllWorkshop::class.java)
                    intent.putExtra("service",item.name)
                    intent.putExtra("type","Service")
                    context.startActivity(intent)
                }
                "workshop" -> {
                    val intent = Intent(context, WorkshopDetails::class.java)
                    intent.putExtra("id",item.id)
                    intent.putExtra("name",item.name)
                    context.startActivity(intent)
                }
            }
        }
    }

    override fun getItemCount() = dataset.size



}