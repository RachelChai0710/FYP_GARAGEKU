package com.example.fyp_garageku.merchant.registration

import android.app.TimePickerDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ScrollView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.fyp_garageku.R
import com.example.fyp_garageku.databinding.FragmentMerchantRegistrationBinding
import com.example.fyp_garageku.dataclass.Customers
import com.example.fyp_garageku.dataclass.Merchant_Registrations
import com.example.fyp_garageku.dataclass.Users
import com.example.fyp_garageku.helper_class.Hash
import com.example.fyp_garageku.helper_class.SendEmail
import com.example.fyp_garageku.helper_class.Validation
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.*
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction
import java.text.SimpleDateFormat
import java.util.*


class Registration : Fragment() {
    private lateinit var registrationViewModel: RegistrationViewModel
    private var _binding: FragmentMerchantRegistrationBinding? = null
    private val binding get() = _binding!!
    private val scope = CoroutineScope(Dispatchers.IO + CoroutineName("RegistrationScope"))
    private val validator = Validation()

    companion object {
        fun newInstance() = Registration()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentMerchantRegistrationBinding.inflate(inflater, container, false)
        val view = binding.root
        val context = activity
        // Create an ArrayAdapter using the string array and a default spinner layout

        if (context != null) {
            ArrayAdapter.createFromResource(
                context,
                R.array.banks,
                android.R.layout.simple_spinner_item
            ).also { adapter ->
                // Specify the layout to use when the list of choices appears
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                // Apply the adapter to the spinner
                binding.registerSpinnerBanks.adapter = adapter
            }
        }

        binding.registrationTxtWorkshopName.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateWorkshopName()
            }
        })

        binding.registrationTxtUsername.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateOwnerName()
            }
        })

        binding.registrationTxtEmail.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateEmail()
            }
        })

        binding.registrationTxtPW.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validatePW()
            }
        })

        binding.registrationTxtPhone.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateOwnerPhone()
            }
        })

        binding.registrationTxtAddress.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateAddress()
            }
        })

        binding.registrationWorkshopTxtPhone.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateOfficePhone()
            }
        })

        binding.registrationWorkshopTxtFrom.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateTime(
                    binding.registrationWorkshopTxtFrom.text?.trim().toString(),
                    binding.registrationWorkshopTxtTo.text?.trim().toString()
                )
            }
        })

        binding.registrationWorkshopTxtTo.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateTime(
                    binding.registrationWorkshopTxtFrom.text?.trim().toString(),
                    binding.registrationWorkshopTxtTo.text?.trim().toString()
                )
            }
        })

        binding.registrationTxtCompanyName.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateComName()
            }
        })

        binding.registrationTxtSST.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateSST()
            }
        })

        binding.registrationTxtAccNo.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateAccNo()
            }
        })

        binding.registrationTxtAccName.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateAccName()
            }
        })

        binding.registerBtnRegister.setOnClickListener() {
            binding.merchantRegisterProgressBar.visibility = View.VISIBLE
            binding.merchantRegisterProgressBar.bringToFront()
            val scrollView = activity?.findViewById<ScrollView>(R.id.register_scrollView)
            if (scrollView != null) {
                scrollView.isEnabled = false
            }
            val job = scope.launch() {
                val result1 = withContext(Dispatchers.IO) { insertToDB() }

                if (result1 != 0) {
                    val sdf = SimpleDateFormat("dd/M/yyyy hh:mm:ss")
                    val currentDate = sdf.format(Date())
                    val senderEmail = getString(R.string.official_email)
                    val password = getString(R.string.email_pw)
                    val recipient = binding.registrationTxtEmail.text.toString()
                    val subject = "Your registration has been successfully submitted"
                    val message = "Dear ${binding.registrationTxtUsername.text}, \n" +
                            "Thank you for registering your workshop at " + getString(R.string.company_name) +
                            "\nWe have received your registration on $currentDate.\n" +
                            "Your registration is being processed by ${getString(R.string.company_name)}'s admin."
                    val sender = SendEmail()
                    val isSent = withContext(Dispatchers.IO) {
                        sender.sendEmail(
                            senderEmail,
                            password,
                            recipient,
                            message,
                            subject
                        )
                    }

                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            activity,
                            "Your registration is accepted!",
                            Toast.LENGTH_LONG
                        ).show()
                        if (isSent) {
                            Toast.makeText(
                                activity,
                                "An confirmation email is sent!",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                        else{
                            Toast.makeText(
                                activity,
                                "Failed to sent confirmation email!",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                        activity?.finish()
                    }
                }
            }

        }

        binding.registrationWorkshopOperationFrom.setEndIconOnClickListener() {
            timePickerDialog(binding.registrationWorkshopTxtFrom)
        }

        binding.registrationWorkshopOperationTo.setEndIconOnClickListener() {
            timePickerDialog(binding.registrationWorkshopTxtTo)
        }
        return view
    }

    private fun timePickerDialog(textInputEditText: TextInputEditText) {
        val cal = Calendar.getInstance()
        val timeSetListener = TimePickerDialog.OnTimeSetListener { _, hour, minute ->
            cal.set(Calendar.HOUR_OF_DAY, hour)
            cal.set(Calendar.MINUTE, minute)
            textInputEditText.setText(SimpleDateFormat("HHmm").format(cal.time))
        }
        TimePickerDialog(
            activity,
            timeSetListener,
            cal.get(Calendar.HOUR_OF_DAY),
            cal.get(Calendar.MINUTE),
            true
        ).show()
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        registrationViewModel = ViewModelProvider(this).get(RegistrationViewModel::class.java)
        // TODO: Use the ViewModel
    }


    private fun validateTime(from: String, to: String): Boolean {
        binding.registrationWorkshopOperationTo.errorIconDrawable = null
        binding.registrationWorkshopOperationFrom.errorIconDrawable = null
        var validFrom = false
        var validTo = false
        if (from.isNullOrBlank()) {
            binding.registrationWorkshopOperationFrom.error = getString(R.string.required_error)
            validFrom = false
        } else {
            binding.registrationWorkshopOperationFrom.error = ""
            validFrom = true
        }

        if (to.isNullOrBlank()) {
            binding.registrationWorkshopOperationTo.error = getString(R.string.required_error)
            validTo = false
        } else {
            binding.registrationWorkshopOperationTo.error = ""
            validTo = true
        }

        if (from > to && validFrom && validTo) {
            binding.registrationWorkshopOperationTo.error =
                getString(R.string.operation_hours_error)
            binding.registrationWorkshopOperationFrom.error =
                getString(R.string.operation_hours_error)
        } else {
            binding.registrationWorkshopOperationTo.error = ""
            binding.registrationWorkshopOperationFrom.error = ""
        }

        return from < to
    }

    private fun validatePW():Boolean{
        return validator.isPassword(
            binding.registrationTxtPW.text?.trim().toString(),
            binding.registrationPw
        ) && !validator.isNull(
            binding.registrationTxtPW.text?.trim().toString(),
            binding.registrationPw
        )
    }

    private fun validateEmail():Boolean{
        return !validator.isNull(
            binding.registrationTxtEmail.text?.trim().toString(),
            binding.registrationEmail
        )
    }

    private fun validateWorkshopName():Boolean{
        return !validator.isNull(
            binding.registrationTxtWorkshopName.text?.trim().toString(),
            binding.registrationWorkshopName
        )
    }

    private fun validateAddress():Boolean{
        return !validator.isNull(
            binding.registrationTxtAddress.text.toString(),
            binding.registrationAddress
        )
    }

    private fun validateComName():Boolean{
        return !validator.isNull(
            binding.registrationTxtCompanyName.text?.trim().toString(),
            binding.registrationCompanyName
        )
    }

    private fun validateComRegNo():Boolean{
        return !validator.isNull(
            binding.registrationTxtRegNo.text?.trim().toString(),
            binding.registrationCompanyRegNo
        )
    }

    private fun validateSST():Boolean{
        return !validator.isNull(
            binding.registrationTxtSST.text?.trim().toString(),
            binding.registrationSst
        )
    }

    private fun validateOwnerName():Boolean{
        return !validator.isNull(
            binding.registrationTxtUsername.text?.trim().toString(),
            binding.registrationUsername
        ) && validator.isLetter(
            binding.registrationTxtUsername.text?.trim().toString(),
            binding.registrationUsername
        )
    }

    private fun validateOwnerPhone():Boolean{
        return !validator.isNull(
            binding.registrationTxtPhone.text?.trim().toString(),
            binding.registrationPhone
        ) && validator.isPhone(
            binding.registrationTxtPhone.text?.trim().toString(),
            binding.registrationPhone
        )
    }


    private fun validateOfficePhone():Boolean{
        return !validator.isNull(
            binding.registrationWorkshopTxtPhone.text?.trim().toString(),
            binding.registrationWorkshopPhone
        ) &&
                validator.isPhone(
                    binding.registrationWorkshopTxtPhone.text?.trim().toString(),
                    binding.registrationWorkshopPhone
                )
    }

    private fun validateAccName():Boolean{
        return !validator.isNull(
            binding.registrationTxtAccName.text?.trim().toString(),
            binding.registrationBankAccName
        ) && validator.isLetter(
            binding.registrationTxtAccName.text?.trim().toString(),
            binding.registrationBankAccName
        )
    }

    private fun validateAccNo():Boolean{
        return !validator.isNull(
            binding.registrationTxtAccNo.text?.trim().toString(),
            binding.registrationBankAccNo
        )
    }

    private fun validation(): Boolean {
        val from = binding.registrationWorkshopTxtFrom.text?.trim().toString()
        val to = binding.registrationWorkshopTxtTo.text?.trim().toString()
        var validFromTo = validateTime(from, to)

        val valid =
            validatePW() && validateEmail() && validateWorkshopName() && validateAddress() && validateComName() && validateComRegNo() && validateSST()
                    && validateOwnerName() && validateOwnerPhone() && validateOfficePhone() && validateAccName()
                    && validateAccNo() && validFromTo
        return valid
    }

    private suspend fun isEmailExist():Pair<Boolean,Boolean>{
        var existEmail = false
        var existUsername = false
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)
                val user = Users.selectAll().forEach {
                    if (it[Users.email] == binding.registrationTxtEmail.text?.trim().toString()) {
                        existEmail = true
                    }
                }
                val cust = Customers.selectAll().forEach {
                    if (it[Customers.cust_name] == binding.registrationTxtUsername.text?.trim().toString()){
                        existUsername = true
                    }
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
        return Pair(existEmail,existUsername)
    }

    private suspend fun insertToDB(): Int {
        val email = binding.registrationTxtEmail.text?.trim().toString()
        val workshopName = binding.registrationTxtWorkshopName.text?.trim().toString()
        val website = binding.registrationTxtWebsite.text?.trim().toString()
        val address = binding.registrationTxtAddress.text.toString()
        val comName = binding.registrationTxtCompanyName.text?.trim().toString()
        val comRegNo = binding.registrationTxtRegNo.text?.trim().toString()
        val sstID = binding.registrationTxtSST.text?.trim().toString()
        val ownerName = binding.registrationTxtUsername.text?.trim().toString()
        val officePhone = binding.registrationWorkshopTxtPhone.text?.trim().toString()
        val ownerPhone = binding.registrationTxtPhone.text?.trim().toString()
        val bankName = binding.registerSpinnerBanks.selectedItem.toString()
        val accName = binding.registrationTxtAccName.text?.trim().toString()
        val accNo = binding.registrationTxtAccNo.text?.trim().toString()
        val from = binding.registrationWorkshopTxtFrom.text?.trim().toString()
        val to = binding.registrationWorkshopTxtTo.text?.trim().toString()
        val operationHours = "$from-$to"
        val helper = Hash()
        val pw = binding.registrationTxtPW.text?.trim().toString()
        val hashedPw = helper.getSHA512(pw)
        var regID = 0
        var valid = false
        withContext(Dispatchers.Main) {
            valid = validation()
        }

        if (valid) {
            val (isEmailExist,isUsernameExist) = withContext(Dispatchers.IO) { isEmailExist() }
            if(!isEmailExist && !isUsernameExist) {
                try {
                    Database.connect(
                        "jdbc:mysql://110.4.46.121/carportal",
                        "com.mysql.jdbc.Driver",
                        "fyp", "fyp2020"
                    )
                    transaction {
                        addLogger(StdOutSqlLogger)
                        regID = Merchant_Registrations.insert {
                            it[workshop_name] = workshopName
                            it[Merchant_Registrations.website] = website
                            it[Merchant_Registrations.address] = address
                            it[company_name] = comName
                            it[company_reg_no] = comRegNo
                            it[sst_id] = sstID
                            it[email_address] = email
                            it[owner_name] = ownerName
                            it[office_phone] = officePhone
                            it[owner_phone] = ownerPhone
                            it[password] = hashedPw
                            it[bank_name] = bankName
                            it[bank_account_name] = accName
                            it[bank_account_number] = accNo
                            it[operation_hours] = operationHours
                        } get Merchant_Registrations.reg_id
                    }

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            else if (isEmailExist){
                withContext(Dispatchers.Main){
                    Toast.makeText(activity,"The email has been registered!",Toast.LENGTH_LONG).show()
                    binding.registrationEmail.error = getString(R.string.existed_email_error)
                    binding.merchantRegisterProgressBar.visibility = View.GONE
                }
            }
            else{
                withContext(Dispatchers.Main){
                    Toast.makeText(activity,"The username has been registered!",Toast.LENGTH_LONG).show()
                    binding.registrationEmail.error = getString(R.string.existed_email_error)
                    binding.merchantRegisterProgressBar.visibility = View.GONE
                }
            }
        } else {
            withContext(Dispatchers.Main) {
                binding.merchantRegisterProgressBar.visibility = View.GONE
                val scrollView = activity?.findViewById<ScrollView>(R.id.register_scrollView)
                if (scrollView != null) {
                    scrollView.isEnabled = true
                }
            }
        }

        return regID
    }
}