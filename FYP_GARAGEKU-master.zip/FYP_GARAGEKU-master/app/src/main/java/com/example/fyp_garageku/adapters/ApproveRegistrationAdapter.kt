package com.example.fyp_garageku.adapters

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.admin.ApproveRegistrationItem
import com.example.fyp_garageku.dataclass.MerchantRegistrationsData
import com.example.fyp_garageku.dataclass.Merchant_Registrations
import com.example.fyp_garageku.dataclass.Merchants
import com.example.fyp_garageku.dataclass.Users
import com.example.fyp_garageku.helper_class.SendEmail
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.exceptions.DuplicateColumnException
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction

class ApproveRegistrationAdapter (private val context: Context,
                                  val dataset : ArrayList<MerchantRegistrationsData>,
                                  val fragmentManager: FragmentManager
                                  ) :RecyclerView.Adapter<ApproveRegistrationAdapter.ItemViewHolder>() {

    class ItemViewHolder(private val view : View) :RecyclerView.ViewHolder(view) {
        val layout : LinearLayout = view.findViewById(R.id.item_layout)
        val workshopNameTextView : TextView = view.findViewById(R.id.workshop_name_textview)
        val companyNameTextView : TextView = view.findViewById(R.id.company_name_textview)
        val rejectButton : ImageButton = view.findViewById(R.id.reject_button)
        val approveButton : ImageButton = view.findViewById(R.id.approve_button)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
       val adapterLayout = LayoutInflater.from(parent.context)
           .inflate(R.layout.item_approve_registration, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]

        holder.workshopNameTextView.text = item.workshop_name
        holder.companyNameTextView.text = item.company_name

        holder.layout.setOnClickListener{
            val intent = Intent(context, ApproveRegistrationItem::class.java)
            intent.putExtra("id",item.reg_id)
            (context as Activity).startActivityForResult(intent, 2404)
        }

        holder.rejectButton.setOnClickListener{
            showDenyAlertDialog(context, item.reg_id, position)
        }

        //check if email is valid
        val thread = Thread {
            var invalidEmail = false
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)
                    //check if duplicate email
                    val registration =
                        Merchant_Registrations.select(Op.build { Merchant_Registrations.reg_id eq item.reg_id })
                            .first()

                    val count =
                        Users.select(Op.build {
                            Users.email eq registration[Merchant_Registrations.email_address] }).count()

                    invalidEmail = count != 0L

                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            if (invalidEmail) {
                holder.approveButton.setOnClickListener{
                    Toast.makeText(context.applicationContext,
                        "Error : This email already exists.", Toast.LENGTH_SHORT).show()
                }
            } else {
                holder.approveButton.setOnClickListener{
                    showApproveAlertDialog(context, item.reg_id, position)
                }
            }


        }
        thread.start()

    }

    override fun getItemCount() = dataset.size

    private fun showApproveAlertDialog(
        context: Context,
        regID: Int,
        position: Int,
    ) {
        val builder: AlertDialog.Builder = AlertDialog.Builder(context)
        val sharedPref = context.getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        val userID = sharedPref?.getString("id", "")?.toInt()!!
        var invalidEmail = false
        builder.setTitle("Confirm approval?")
        builder.setPositiveButton(
            "Yes"
        ) { dialog, _ ->
            // update database
            val thread = Thread {
                try {
                    Database.connect(
                        "jdbc:mysql://110.4.46.121/carportal",
                        "com.mysql.jdbc.Driver",
                        "fyp", "fyp2020"
                    )
                    transaction {
                        addLogger(StdOutSqlLogger)

                        val registration =
                            Merchant_Registrations.select(Op.build { Merchant_Registrations.reg_id eq regID })
                                .first()

                        //update status to complete
                        Merchant_Registrations.update({ Merchant_Registrations.reg_id eq regID })
                        {
                            it[approval_status] = "Approved"
                            it[admin_id] = userID
                        }

                        //add user to db
                        Users.insert {
                            it[email] = registration[Merchant_Registrations.email_address]
                            it[password] = registration[Merchant_Registrations.password]
                            it[user_type_id] = 1
                        }

                        //check user id
                        val user =
                            Users.select(Op.build { Users.email eq registration[Merchant_Registrations.email_address] })
                                .first()

                        //add user to db
                        Merchants.insert {
                            it[workshop_name] = registration[Merchant_Registrations.workshop_name]
                            it[website] = registration[Merchant_Registrations.website]
                            it[address] = registration[Merchant_Registrations.address]
                            it[company_name] = registration[Merchant_Registrations.company_name]
                            it[company_reg_no] = registration[Merchant_Registrations.company_reg_no]
                            it[sst_id] = registration[Merchant_Registrations.sst_id]
                            it[owner_name] = registration[Merchant_Registrations.owner_name]
                            it[owner_phone] = registration[Merchant_Registrations.owner_phone]
                            it[manager_name] = registration[Merchant_Registrations.owner_name]
                            it[manager_phone] = registration[Merchant_Registrations.owner_phone]
                            it[email_address] = registration[Merchant_Registrations.email_address]
                            it[office_phone] = registration[Merchant_Registrations.office_phone]
                            it[bank_name] = registration[Merchant_Registrations.bank_name]
                            it[bank_account_name] = registration[Merchant_Registrations.bank_account_name]
                            it[bank_account_number] = registration[Merchant_Registrations.bank_account_number]
                            it[operation_hours] = registration[Merchant_Registrations.operation_hours]
                            it[user_id] = user[Users.id]
                        }

                        //send email
                        val sender = SendEmail()

                        GlobalScope.launch() {
                            val isSent = withContext(Dispatchers.IO) {
                                sender.sendEmail(
                                    context.resources.getString(R.string.official_email),
                                    context.resources.getString(R.string.email_pw),
                                    registration[Merchant_Registrations.email_address],
                                    context.resources.getString(R.string.email_approve_registration_body),
                                    context.resources.getString(R.string.email_approve_registration_subject),
                                )
                            }
                        }

                    }

                        dialog.dismiss()
                        deleteItem(position)

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            thread.start()
            Toast.makeText(context.applicationContext,
                "Registration approved!", Toast.LENGTH_SHORT).show()
        }
        builder.setNegativeButton(
            "Cancel"
        ) { dialog, _ ->
            dialog.dismiss()
        }

        builder.show()
    }

    private fun showDenyAlertDialog(
        context: Context,
        regID: Int,
        position: Int
    ) {
        val builder: AlertDialog.Builder = AlertDialog.Builder(context)
        val sharedPref = context.getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        val userID = sharedPref?.getString("id", "")?.toInt()!!
        builder.setTitle("Reason for rejection")
        val input = EditText(context)
        input.hint = "Reason"
        input.inputType = InputType.TYPE_CLASS_TEXT
        builder.setView(input)
        builder.setPositiveButton(
            "Reject"
        ) { dialog, _ ->
            // update database
            val thread = Thread {
                try {
                    Database.connect(
                        "jdbc:mysql://110.4.46.121/carportal",
                        "com.mysql.jdbc.Driver",
                        "fyp", "fyp2020"
                    )
                    transaction {
                        addLogger(StdOutSqlLogger)
                        //update status to denied
                        Merchant_Registrations.update({ Merchant_Registrations.reg_id eq regID } )
                        {
                            it[approval_status] = "Denied"
                            it[admin_id] = userID
                        }

                        //get email from DB
                        val registration =
                            Merchant_Registrations.select(Op.build { Merchant_Registrations.reg_id eq regID })
                                .first()

                        //send email
                        val sender = SendEmail()

                        GlobalScope.launch() {
                            val isSent = withContext(Dispatchers.IO) {
                                sender.sendEmail(
                                    context.resources.getString(R.string.official_email),
                                    context.resources.getString(R.string.email_pw),
                                    registration[Merchant_Registrations.email_address],
                                    context.resources.getString(R.string.email_reject_registration_body)+
                                            input.text +
                                            context.resources.getString(R.string.email_closing),
                                    context.resources.getString(R.string.email_reject_registration_subject),
                                )
                            }
                        }
                    }

                    dialog.dismiss()
                    deleteItem(position)

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            thread.start()
            Toast.makeText(context.applicationContext,
                "Registration denied!", Toast.LENGTH_SHORT).show()
        }
        builder.setNegativeButton(
            "Cancel"
        ) { dialog, _ ->
            dialog.dismiss()

        }

        builder.show()
    }

    private fun deleteItem(position: Int){
        dataset.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, dataset.size)
    }

}