package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table

object Booking_Services: Table() {
    val service_id = integer("service_id")
        .references(Services.service_id)
    val booking_id = integer("booking_id")
        .references(Bookings.booking_id)
    override val primaryKey = PrimaryKey(booking_id,service_id)
}