package com.example.fyp_garageku.merchant.editprofile

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.MerchantEmployees
import com.example.fyp_garageku.dataclass.Merchants
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction

class EditStaffDetails : AppCompatActivity() {

    private lateinit var ownerNameTextView: TextView
    private lateinit var ownerPhoneTextView: TextView
    private lateinit var managerNameTextView: TextView
    private lateinit var managerPhoneTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_staff_details)

        supportActionBar?.title = "Edit Staff Details"
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        //view variables
        ownerNameTextView = findViewById(R.id.owner_name_textview)
        ownerPhoneTextView = findViewById(R.id.owner_phone_textview)
        managerNameTextView = findViewById(R.id.manager_name_textview)
        managerPhoneTextView = findViewById(R.id.manager_phone_textview)

        loadData()

        //add event listeners
        ownerNameTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "Owner Name")
            intent.putExtra("value", ownerNameTextView.text)
            startActivityForResult(intent, 2404)
        }
        ownerPhoneTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "Owner Phone")
            intent.putExtra("value", ownerPhoneTextView.text)
            startActivityForResult(intent, 2404)
        }
        managerNameTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "Manager Name")
            intent.putExtra("value", managerNameTextView.text)
            startActivityForResult(intent, 2404)
        }
        managerPhoneTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "Manager Phone")
            intent.putExtra("value", managerPhoneTextView.text)
            startActivityForResult(intent, 2404)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode  == AppCompatActivity.RESULT_OK && requestCode == 2404) {
            if (data != null){
                val name = data.getStringExtra("name")
                val newValue = data.getStringExtra("newValue")
                when (name) {
                    "Owner Name" ->
                        ownerNameTextView.text = newValue
                    "Owner Phone" ->
                        ownerPhoneTextView.text = newValue
                    "Manager Name" ->
                        managerNameTextView.text = newValue
                    "Manager Phone" ->
                        managerPhoneTextView.text = newValue
                }
            }
        }
    }

    private fun loadData(){
        val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        var userID = 0
        userID = sharedPref?.getString("id","")?.toInt()!!

        //fetch data from db
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    //get data from DB
                    val merchant = Merchants.select(Op.build { Merchants.user_id eq userID}).first()

                    //load data into textview
                    runOnUiThread{
                        ownerNameTextView.text = merchant[Merchants.owner_name]
                        ownerPhoneTextView.text = merchant[Merchants.owner_phone]
                        managerNameTextView.text = merchant[Merchants.manager_name]
                        managerPhoneTextView.text = merchant[Merchants.manager_phone]
                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

}