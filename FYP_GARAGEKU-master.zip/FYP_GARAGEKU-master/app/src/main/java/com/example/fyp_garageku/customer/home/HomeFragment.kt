package com.example.fyp_garageku.customer.home

import android.Manifest
import android.annotation.SuppressLint
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.os.Handler
import android.transition.Slide
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.widget.NestedScrollView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.denzcoskun.imageslider.constants.ActionTypes
import com.denzcoskun.imageslider.constants.ScaleTypes
import com.denzcoskun.imageslider.interfaces.ItemChangeListener
import com.denzcoskun.imageslider.interfaces.ItemClickListener
import com.denzcoskun.imageslider.interfaces.TouchListener
import com.denzcoskun.imageslider.models.SlideModel
import com.example.fyp_garageku.R
import com.example.fyp_garageku.adapters.CustHomeAdapter
import com.example.fyp_garageku.databinding.FragmentHomeBinding
import com.example.fyp_garageku.dataclass.*
import com.example.fyp_garageku.helper_class.GeocodingLocation
import com.google.android.gms.location.*
import com.google.android.gms.location.LocationRequest
import com.vmadalin.easypermissions.EasyPermissions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction

class HomeFragment : Fragment(), EasyPermissions.PermissionCallbacks {
    companion object {
        private const val PERMISSION_LOCATION_REQUEST_CODE = 1
    }

    private lateinit var homeViewModel: HomeViewModel
    private lateinit var _binding: FragmentHomeBinding
    private val binding get() = _binding!!
    private var startIndex: Long = 0
    private val workshopList = mutableListOf<HomeData>()
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    private var currentLocation: Location? = null

    @SuppressLint("MissingPermission")
    override fun onStart() {
        super.onStart()

        val mLocationRequest = LocationRequest.create()
        mLocationRequest.interval = 60000
        mLocationRequest.fastestInterval = 5000
        mLocationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        val mLocationCallback: LocationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                if (locationResult == null) {
                    return
                }
                for (location in locationResult.locations) {
                    if (location != null) {
                        //TODO: UI updates.
                    }
                }
            }
        }
        if (!hasLocationPermission()) {
            requestLocationPermission()
        }
        LocationServices.getFusedLocationProviderClient(requireContext())
            .requestLocationUpdates(mLocationRequest, mLocationCallback, null)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        homeViewModel =
            ViewModelProvider(this).get(HomeViewModel::class.java)
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val view = binding.root
        var withLocation = false

        fusedLocationProviderClient =
            LocationServices.getFusedLocationProviderClient(requireContext())
        if (hasLocationPermission()) {
            checkLocation()
            val delay = 1 * 1000
            val handler = Handler()
            var i = 0
            handler.postDelayed(object : Runnable {
                override fun run() {
                    if (currentLocation != null || i == 5) { // just remove call backs
                        if (currentLocation != null) {
                            withLocation = true
                            initiaWorkshopRecycleView(withLocation, false)
                        } else {
                            withLocation = false
                            initiaWorkshopRecycleView(withLocation, false)
                        }
                        handler.removeCallbacks(this)
                    } else { // post again
                        i++
                        checkLocation()
                        handler.postDelayed(this, delay.toLong())
                    }
                }
            }, delay.toLong())
        } else {
            requestLocationPermission()
        }
        initiaServicesRecycleView()
        initiaImageSlider()

        binding.homeNestedScrollView.setOnScrollChangeListener(NestedScrollView.OnScrollChangeListener { v, scrollX, scrollY, oldScrollX, oldScrollY ->
            val view: View = v.getChildAt(v.childCount - 1)
            val diff: Int =
                view.bottom + v.paddingBottom - (v.height + v.scrollY)
            if (diff == 0) {
                startIndex += 10
                binding.homeProgressBar.visibility = View.VISIBLE
                initiaWorkshopRecycleView(withLocation, true)
            }
        })
        return view
    }

    private fun initiaServicesRecycleView() {
        val context = activity
        GlobalScope.launch {
            val list = withContext(Dispatchers.IO) { loadServices() }

            withContext(Dispatchers.Main) {
                val layoutManager =
                    LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
                binding.recAllServices.layoutManager = layoutManager
                val myAdapter = context?.let { CustHomeAdapter(it, list, "service") }
                binding.recAllServices.adapter = myAdapter
                binding.recAllServices.setHasFixedSize(true)
            }
        }
    }

    private suspend fun loadServices(): MutableList<HomeData> {
        binding.recAllServices.removeAllViewsInLayout()
        val serviceList = mutableListOf<HomeData>()

        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                var service: HomeData
                addLogger(StdOutSqlLogger)

                Service_Categories.select (Op.build {
                    Service_Categories.status eq "Available"
                }).map {
                    service = HomeData(
                        it[Service_Categories.name],
                        it[Service_Categories.cat_id]
                    )
                    serviceList.add(service)
                }

            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return serviceList
    }

    private fun initiaImageSlider(){
        var imageList: ArrayList<SlideModel>
        GlobalScope.launch {
            withContext(Dispatchers.IO) {
                   imageList = loadAdvertisement()
            }

            withContext(Dispatchers.Main) {
                binding.imageSlider.setImageList(imageList, ScaleTypes.FIT)
                binding.imageSlider.setItemClickListener(object : ItemClickListener {
                    override fun onItemSelected(position: Int) {
                        // You can listen here.
                    }
                })

                binding.imageSlider.setItemChangeListener(object : ItemChangeListener {
                    override fun onItemChanged(position: Int) {
                        //println("Pos: " + position)
                    }
                })

                binding.imageSlider.setTouchListener(object : TouchListener {
                    override fun onTouched(touched: ActionTypes) {
                        if (touched == ActionTypes.DOWN) {
                            binding.imageSlider.stopSliding()
                        } else if (touched == ActionTypes.UP) {
                            binding.imageSlider.startSliding(1000)
                        }
                    }
                })
            }
        }
    }
    private  suspend fun loadAdvertisement():ArrayList<SlideModel>{
        var imageList = ArrayList<SlideModel>()
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)
                val list = Advertisement_Images.selectAll().toMutableList()
                for (item in list){
                    imageList.add(SlideModel("http://test.onmyfinger.com/images/advertisement${item[Advertisement_Images.image_id]}.jpg",item[Advertisement_Images.title]))
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
        return imageList
    }

    private fun initiaWorkshopRecycleView(withLocation: Boolean, isScrollBottom: Boolean) {
        val context = activity
        binding.recTopRatedWorkshop.removeAllViewsInLayout()
        binding.homeProgressBar.visibility = View.VISIBLE
        GlobalScope.launch {
            withContext(Dispatchers.IO) {
                if (withLocation)
                    loadWorkshopsWithLocation()
                else
                    loadWorkshops()
            }

            withContext(Dispatchers.Main) {
                val layoutManager = GridLayoutManager(context, 2)
                binding.recTopRatedWorkshop.layoutManager = layoutManager
                val myAdapter = context?.let { CustHomeAdapter(it, workshopList, "workshop") }
                binding.recTopRatedWorkshop.adapter = myAdapter
                binding.recTopRatedWorkshop.setHasFixedSize(true)
                binding.homeProgressBar.visibility = View.GONE
                binding.recTopRatedWorkshop.visibility = View.VISIBLE
            }
        }
    }

    private suspend fun loadWorkshopsWithLocation() {
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                var workshop: HomeData
                addLogger(StdOutSqlLogger)

                Merchants.selectAll().limit(10, startIndex)
                    .orderBy(Merchants.rating to SortOrder.DESC).map {
                        val address = it[Merchants.address]
                        val locationAdd =
                            GeocodingLocation().getAddressFromLocation(address, requireContext())
                        val results = FloatArray(3)
                        Location.distanceBetween(
                            currentLocation!!.latitude,
                            currentLocation!!.longitude,
                            locationAdd.latitude,
                            locationAdd.longitude,
                            results
                        )
                        if (results[0] < 5000) { // if <5 km away from current location, add the workshop to display
                            workshop = HomeData(
                                it[Merchants.workshop_name],
                                it[Merchants.merchant_id]
                            )
                            workshopList.add(workshop)
                        }
                    }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private suspend fun loadWorkshops() {
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                var workshop: HomeData
                addLogger(StdOutSqlLogger)

                Merchants.selectAll().limit(10, startIndex)
                    .orderBy(Merchants.rating to SortOrder.DESC).map {
                        workshop = HomeData(
                            it[Merchants.workshop_name],
                            it[Merchants.merchant_id]
                        )
                        workshopList.add(workshop)
                    }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun hasLocationPermission() =
        EasyPermissions.hasPermissions(
            requireContext(),
            Manifest.permission.ACCESS_FINE_LOCATION
        ) &&
                EasyPermissions.hasPermissions(
                    requireContext(),
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )

    private fun requestLocationPermission() {
        EasyPermissions.requestPermissions(
            this,
            "The application cannot filter the merchant if location permission is not granted!",
            PERMISSION_LOCATION_REQUEST_CODE,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        EasyPermissions.requestPermissions(
            this,
            "The application cannot filter the merchant if location permission is not granted!",
            PERMISSION_LOCATION_REQUEST_CODE,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this)
    }

    override fun onPermissionsDenied(requestCode: Int, perms: List<String>) {
        initiaWorkshopRecycleView(false, false)
    }

    override fun onPermissionsGranted(requestCode: Int, perms: List<String>) {
        initiaWorkshopRecycleView(true, false)
        Toast.makeText(requireContext(), "Location Granted!", Toast.LENGTH_LONG).show()
    }

    @SuppressLint("MissingPermission")
    private fun checkLocation() {
        fusedLocationProviderClient.lastLocation.addOnSuccessListener { location: Location? ->
            if (location != null) {
                currentLocation = location
            }
        }
    }
}