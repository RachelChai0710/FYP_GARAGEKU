package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table

object Quotation_Services: Table() {
    val service_id = integer("service_id")
        .references(Services.service_id)
    val quote_id = integer("quote_id")
        .references(Quotations.quote_id)
    override val primaryKey = PrimaryKey(service_id,quote_id)
}