package com.example.fyp_garageku.customer.inquiries

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.*
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fyp_garageku.adapters.CustHomeAdapter
import com.example.fyp_garageku.adapters.CustInquiriesAdapter
import com.example.fyp_garageku.customer.CustomerHomepage
import com.example.fyp_garageku.databinding.FragmentCustInquiriesBinding
import com.example.fyp_garageku.dataclass.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.*

class InquiriesFragment : Fragment()  {

    private lateinit var inquiriesViewModel: InquiriesViewModel
    private var _binding: FragmentCustInquiriesBinding? = null
    private val binding get() = _binding!!
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        inquiriesViewModel =
            ViewModelProvider(this).get(InquiriesViewModel::class.java)
        _binding = FragmentCustInquiriesBinding.inflate(inflater, container, false)
        initiaInquiriesRecycleView()

        return binding.root
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun initiaInquiriesRecycleView() {
        val context = activity
        GlobalScope.launch {
            var list = withContext(Dispatchers.IO) { loadInquiries() }

            withContext(Dispatchers.Main) {
                val layoutManager =
                    LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
                binding.inquiriesRecView.layoutManager = layoutManager
                binding.inquiriesRecView.addItemDecoration(
                    DividerItemDecoration(
                        binding.inquiriesRecView.context,
                        layoutManager.orientation
                    )
                )
                list = list.groupBy { it.name }.entries.mapNotNull  { it.value.maxByOrNull { it.time.toString() } }.toMutableList()
                val sharedPref = activity?.getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
                val custID = sharedPref?.getString("id", "")?.toInt()
                val myAdapter = context?.let { CustInquiriesAdapter(it, list,(custID ?: 0),activity as CustomerHomepage) }
                binding.inquiriesRecView.adapter = myAdapter
                binding.inquiriesRecView.setHasFixedSize(true)
                binding.inquiriesProgress.visibility = View.GONE
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private suspend fun loadInquiries(): MutableList<CustInquiriesData> {
        binding.inquiriesRecView.removeAllViewsInLayout()
        val inquiriesList = mutableListOf<CustInquiriesData>()
        val sharedPref = activity?.getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        val custID = sharedPref?.getString("id", "")?.toInt()
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                var inquiry: CustInquiriesData
                addLogger(StdOutSqlLogger)

                Quotations.join(Merchants,JoinType.INNER,additionalConstraint = {Quotations.merchant_id eq Merchants.merchant_id})
                    .slice(Quotations.quote_id,Quotations.merchant_id,Merchants.workshop_name,Quotations.date,Quotations.status)
                    .select(Op.build { Quotations.cust_id eq (custID ?: 0) })
                    .orderBy(Quotations.date to SortOrder.DESC)
                    .map {
                        val formatter: DateTimeFormatter =
                            DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT)
                                .withLocale(Locale.UK)
                                .withZone(ZoneId.systemDefault())
                        val formattedDate = formatter.format(it[Quotations.date])
                    inquiry = CustInquiriesData(
                        it[Quotations.quote_id],
                        it[Quotations.merchant_id],
                        it[Merchants.workshop_name],
                        formattedDate,
                        "",
                        "Read"
                    )
                        val serviceList = Quotation_Services.join(Services,JoinType.INNER,additionalConstraint = {Quotation_Services.service_id eq Services.service_id})
                            .slice(Services.name)
                            .select(Op.build { Quotation_Services.quote_id eq inquiry.quoteID!!}).toMutableList()
                        var service = ""
                        for (item in serviceList){
                            service += if (item == serviceList.last())
                                "${item[Services.name]}"
                            else
                                "${item[Services.name]} \n"
                        }
                        inquiry.service = service
                        val replyList = Replies.join(Quotations,JoinType.INNER,additionalConstraint = {Replies.quote_id eq Quotations.quote_id})
                            .join(Merchants,JoinType.INNER,additionalConstraint = {Quotations.merchant_id eq Merchants.merchant_id})
                            .slice(Replies.reply_date,Replies.status,Replies.quote_id,Quotations.merchant_id)
                            .selectAll().orderBy(Replies.reply_date  to SortOrder.ASC).toMutableList()
                        if (!replyList.isNullOrEmpty()) {
                            for (item in replyList){
                                if (item[Quotations.merchant_id] == inquiry.merchantID){
                                    if (item[Replies.reply_date] > it[Quotations.date]){
                                        val formattedReplyDate = formatter.format(item[Replies.reply_date])
                                        inquiry.status = item[Replies.status]
                                        inquiry.time = formattedReplyDate
                                    }

                                }
                            }

                        }
                        inquiriesList.add(inquiry)
                        val selected = inquiriesList.filter { it.merchantID == inquiry.merchantID }
                        for (item in selected){
                            if (item.status == "Unread"){
                                for (inquiry in inquiriesList){
                                    if (inquiry.merchantID == item.merchantID){
                                        inquiry.status = "Unread"
                                    }
                                }
                            }
                        }
                }

            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
        return inquiriesList
    }

}