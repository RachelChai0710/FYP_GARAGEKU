package com.example.fyp_garageku.customer

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.denzcoskun.imageslider.constants.ActionTypes
import com.denzcoskun.imageslider.constants.ScaleTypes
import com.denzcoskun.imageslider.interfaces.ItemChangeListener
import com.denzcoskun.imageslider.interfaces.ItemClickListener
import com.denzcoskun.imageslider.interfaces.TouchListener
import com.denzcoskun.imageslider.models.SlideModel
import com.example.fyp_garageku.R
import com.example.fyp_garageku.adapters.ReviewsAdapter
import com.example.fyp_garageku.databinding.ActivityWorkshopDetailsBinding
import com.example.fyp_garageku.dataclass.*
import com.example.fyp_garageku.helper_class.GeocodingLocation
import kotlinx.coroutines.*
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.*
import kotlin.collections.ArrayList


class WorkshopDetails : AppCompatActivity(){
    private lateinit var binding: ActivityWorkshopDetailsBinding
    private var name = ""
    private var serviceList = mutableListOf<ServiceData>()
    private var merchantId = 0
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWorkshopDetailsBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        setSupportActionBar(binding.detailsToolbar)
        actionBar?.setDisplayHomeAsUpEnabled(true)

        val job = GlobalScope.async {
            loadMerchant()
            loadService()
            loadReview()
            loadMerchantPhotos()
        }

        binding.buttonLayout.bringToFront()
    }

    fun back(v: View) {
        onBackPressed()
    }

    fun btnMapOnClick(v: View) {
        val address = binding.detailsWorkshopTxtAdd.text.toString()
        val locationAdd =
            GeocodingLocation().getAddressFromLocation(address, this)
        // Create a Uri from an intent string. Use the result to create an Intent.
        val gmmIntentUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${locationAdd.latitude},${locationAdd.longitude}")
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
        mapIntent.setPackage("com.google.android.apps.maps")
        startActivity(mapIntent)
    }

    fun viewAllOnClick(v: View) {
        val intent = Intent(this, AllReviews::class.java)
        intent.putExtra("workshopID", merchantId)
        startActivity(intent)
    }

    fun askForQuoteOnClick(v: View) {
        val dialog = DialogInquiriesFragment()
        val arg = Bundle()
        arg.putInt("workshopID", merchantId)
        dialog.arguments = arg
        dialog.setList(serviceList)
        dialog.show(supportFragmentManager, "Ask For Quote")
    }

    fun bookNowOnClick(v: View) {
        if (serviceList.isNotEmpty()) {
            val intent = Intent(this, BookAppointment::class.java)
            intent.putExtra("workshopID", merchantId)
            intent.putExtra("serviceList", ArrayList(serviceList))
            intent.putExtra("name",binding.detailsWorkshopName.text.toString())
            startActivity(intent)
        } else {
            Toast.makeText(
                this,
                "This workshop does not have any available services to book",
                Toast.LENGTH_LONG
            ).show()
        }

    }

    private suspend fun loadMerchant() {
        merchantId = intent.getIntExtra("id", 0)
        name = intent.getStringExtra("name").toString()
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)

                val merchant =
                    Merchants
                        .select(Op.build { Merchants.merchant_id eq merchantId }).first()
                GlobalScope.launch {
                    withContext(Dispatchers.Main) {
                        binding.detailsWorkshopTxtAdd.text = merchant[Merchants.address]
                        binding.detailsWorkshopTxtEmail.text = merchant[Merchants.email_address]
                        binding.detailsWorkshopTxtPhone.text = merchant[Merchants.office_phone]
                        binding.detailsWorkshopName.text = name
                        binding.detailsWorkshopTxtHours.text = merchant[Merchants.operation_hours]
                        binding.detailsWorkshopRating.rating = merchant[Merchants.rating].toFloat()
                        binding.workshopDetailsTxtRating.text =
                            "(${String.format("%.2f", merchant[Merchants.rating])})"
                    }
                }


            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private suspend fun loadService() {
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)

                //get data from DB
                val merchant =
                    Merchants.select(Op.build { Merchants.merchant_id eq merchantId }).first()
                val count = Service_Categories.select(Op.build {
                    Service_Categories.status eq "Available"
                }).count().toInt()
                val idList = Service_Categories
                    .slice(Service_Categories.cat_id)
                    .select(Op.build {
                        Service_Categories.status eq "Available"
                    }).toMutableList()
                for (i in 0 until count) {
                    val catID = idList[i][Service_Categories.cat_id]
                    //category header
                    val serviceCategory =
                        Service_Categories.select(Op.build {
                            Service_Categories.cat_id eq catID and (Service_Categories.status eq "Available")
                        }).first()
                    //category contents
                    val services = Merchant_Services.join(Services, JoinType.INNER, null, null) {
                        (Merchant_Services.service_id eq Services.service_id)
                    }.select {
                        Services.cat_id eq catID and
                                (Merchant_Services.merchant_id eq merchant[Merchants.merchant_id]) and
                                (Services.status eq "Available")
                    }.toMutableList()

                    if (services.isNotEmpty()) {
                        runOnUiThread {
                            val category = serviceCategory[Service_Categories.name]
                            val list = ArrayList<String>()
                            //header
                            val header = layoutInflater.inflate(
                                R.layout.item_merchant_profile_services_header,
                                null
                            )
                            header.findViewById<TextView>(R.id.header_textview).text = category
                            binding.workshopDetailsServicesLayout.addView(header)

                            //content
                            for (item in services) {
                                val service = item[Services.name]
                                val serviceItem = layoutInflater.inflate(
                                    R.layout.item_merchant_profile_services,
                                    null
                                )
                                serviceItem.findViewById<TextView>(R.id.item_textview).text =
                                    service
                                binding.workshopDetailsServicesLayout.addView(serviceItem)
                                serviceList.add(ServiceData(service, item[Services.service_id]))
                            }

                        }
                    }
                }
                runOnUiThread {
                    binding.detailsWorkshopBtnBook.isEnabled = true
                    binding.detailsWorkshopBtnAsk.isEnabled = true
                }

            }

        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    @RequiresApi(Build.VERSION_CODES.O)
    private suspend fun loadReview() {
        val list = mutableListOf<ReviewData>()
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)

                val count = Reviews.join(Bookings, JoinType.INNER, null, null) {
                    Reviews.booking_id eq Bookings.booking_id
                }
                    .select(Op.build { Bookings.merchant_id eq merchantId }).count()

                Reviews.join(Bookings, JoinType.INNER, null, null) {
                    Reviews.booking_id eq Bookings.booking_id
                }
                    .join(Customers, JoinType.INNER, null, null) {
                        (Bookings.cust_id eq Customers.cust_id)
                    }
                    .select(Op.build { Bookings.merchant_id eq merchantId })
                    .limit(3)
                    .orderBy(Reviews.review_date, SortOrder.DESC).map{
                        val formatter: DateTimeFormatter =
                            DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT)
                                .withLocale(Locale.UK)
                                .withZone(ZoneId.systemDefault())
                        val formattedDate = formatter.format(it[Reviews.review_date])

                        val serviceList = Booking_Services.join(Services,JoinType.INNER, null, null) {
                            (Booking_Services.service_id eq Services.service_id)
                        }
                            .select(Op.build { Booking_Services.booking_id eq it[Bookings.booking_id] }).toMutableList()
                        var service = ""
                        for (item in serviceList){
                            service += if (item[Services.name] == serviceList.last()[Services.name]){
                                "${item[Services.name]}"
                            } else
                                "${item[Services.name]} \n"
                        }

                        list.add(
                            ReviewData(
                            it[Customers.cust_name],
                            it[Reviews.review],
                            it[Customers.imageURL],
                            formattedDate,
                            it[Reviews.anonymous],
                            it[Reviews.rating].toFloat(),
                            service
                        ))
                    }

                GlobalScope.launch {
                    withContext(Dispatchers.Main) {
                        binding.detailsWorkshopLblRatingCount.text = "($count)"
                        if (list.isNotEmpty()) {
                            val layoutManager =
                                LinearLayoutManager(
                                    this@WorkshopDetails,
                                    LinearLayoutManager.VERTICAL,
                                    false
                                )
                            binding.detailsWorkshopRecReviews.layoutManager = layoutManager
                            binding.detailsWorkshopRecReviews.addItemDecoration(
                                DividerItemDecoration(
                                    binding.detailsWorkshopRecReviews.context,
                                    layoutManager.orientation
                                )
                            )
                            val myAdapter = ReviewsAdapter(this@WorkshopDetails, list)
                            binding.detailsWorkshopRecReviews.adapter = myAdapter
                            binding.detailsWorkshopRecReviews.setHasFixedSize(true)
                            binding.detailsBtnViewAll.isEnabled = true
                        } else {
                            binding.detailsBtnViewAll.isEnabled = false
                            binding.detailsWorkshopRecReviews.visibility = View.GONE
                        }
                    }
                }


            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private suspend fun loadMerchantPhotos() {
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)
                val imageList = ArrayList<SlideModel>()
                val list = Merchant_Images.select(Merchant_Images.merchant_id eq merchantId).toMutableList()
                for (item in list){
                    imageList.add(SlideModel("http://test.onmyfinger.com/images/merchant_image_${item[Merchant_Images.image_id]}.jpg"))
                }
                GlobalScope.launch {
                    withContext(Dispatchers.Main){
                        binding.detailsWorkshopImg.setImageList(imageList, ScaleTypes.FIT)
                        binding.detailsWorkshopImg.setItemClickListener(object : ItemClickListener {
                            override fun onItemSelected(position: Int) {
                                // You can listen here.
                            }
                        })

                        binding.detailsWorkshopImg.setItemChangeListener(object : ItemChangeListener {
                            override fun onItemChanged(position: Int) {
                                //println("Pos: " + position)
                            }
                        })

                        binding.detailsWorkshopImg.setTouchListener(object : TouchListener {
                            override fun onTouched(touched: ActionTypes) {
                                if (touched == ActionTypes.DOWN) {
                                    binding.detailsWorkshopImg.stopSliding()
                                } else if (touched == ActionTypes.UP) {
                                    binding.detailsWorkshopImg.startSliding(1000)
                                }
                            }
                        })
                    }

                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }

    }
}