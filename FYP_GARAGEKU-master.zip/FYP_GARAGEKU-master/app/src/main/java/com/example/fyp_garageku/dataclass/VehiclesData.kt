package com.example.fyp_garageku.dataclass

data class VehiclesData(
    var vehicle_id:Int? = 0,
    var car_type:String? = "",
    var brand:String?="",
    var model:String?="",
    var cust_id:Int?= 0,
    var year:Int? = 0,
    var carPlate:String? = "",
    var cc: Double? = 0.00)
