package com.example.fyp_garageku.merchant.inquiries

import android.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.denzcoskun.imageslider.ImageSlider
import com.denzcoskun.imageslider.constants.ScaleTypes
import com.denzcoskun.imageslider.models.SlideModel
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.*
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction

class InquiriesReply : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inquiries_reply)

        supportActionBar?.title = "Reply to Inquiry"
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val id = intent.extras?.getInt("id")!!
        val services = intent.extras?.getString("service")!!
        val vehicle = intent.extras?.getString("vehicle")!!
        val customer = intent.extras?.getString("customer")!!
        val date = intent.extras?.getString("date")!!
        val description = intent.extras?.getString("description")!!

        val vehicleTextView : TextView = findViewById(R.id.vehicle_textview)
        val servicesTextView : TextView = findViewById(R.id.services_textview)
        val custNameTextView : TextView = findViewById(R.id.cust_name_textview)
        val dateTextView : TextView = findViewById(R.id.date_textview)
        val descriptionTextView : TextView = findViewById(R.id.description_textview)

        val replyEditText : EditText = findViewById(R.id.reply_edittext)

        servicesTextView.text = services
        dateTextView.text = date
        custNameTextView.text = customer
        vehicleTextView.text = vehicle
        if (description != "") {
            descriptionTextView.text = description
        } else {
            descriptionTextView.text = "-"
        }

        //load images
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    val images = Quotation_Images.select(Quotation_Images.quote_id eq id).toList()
                    runOnUiThread {
                        val imageSlider = findViewById<ImageSlider>(R.id.image_slider)
                        val noImageText = findViewById<TextView>(R.id.no_images_text)

                        if (images.isEmpty())
                        {
                            noImageText.visibility = View.VISIBLE
                        }
                        else
                        {
                            val imageList = ArrayList<SlideModel>()
                            for (image in images){
                                val imgID = image[Quotation_Images.img_id]
                                val imageString  = "http://test.onmyfinger.com/images/quotation_image_$imgID.jpg"
                                imageList.add(SlideModel(imageString))
                                imageSlider.setImageList(imageList, ScaleTypes.CENTER_INSIDE)

                                imageSlider.visibility = View.VISIBLE
                            }
                        }
                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()

        if(replyEditText.requestFocus()) {
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.confirm_button_menu, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.confirm_button) {
            // check if edittext contains text
            val replyEditText = findViewById<EditText>(R.id.reply_edittext)

            if (replyEditText.text.toString().trim().isNotEmpty()){
                val builder: AlertDialog.Builder = AlertDialog.Builder(this)
                builder.setTitle("Are you sure?")
                builder.setPositiveButton(
                    "Yes"
                ) { _, _ ->
                    addReply()
                }
                builder.setNegativeButton(
                    "Cancel"
                ) { dialog, _ ->
                    dialog.dismiss()
                }
                builder.show()
            } else {
                Toast.makeText(this, "Please enter a reply!", Toast.LENGTH_SHORT).show()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun addReply(){
        val quoteID = intent.extras?.getInt("id")!!
        val replyEditText = findViewById<EditText>(R.id.reply_edittext)
        //update database
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    //add reply to database
                    Replies.insert {
                        it[reply] = replyEditText.text.toString()
                        it[quote_id] = quoteID
                    }

                    //update status to replied
                    Quotations.update({Quotations.quote_id eq quoteID}) {
                        it[status] = "Replied"
                    }

                }
                setResult(RESULT_OK, intent)
                runOnUiThread{
                    Toast.makeText(applicationContext, "Reply sent!", Toast.LENGTH_SHORT).show()
                }
                finish()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

}