package com.example.fyp_garageku.admin.manageservices

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.*
import com.skydoves.expandablelayout.expandableLayout
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction

class ManageCategories : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_categories)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.title = "Manage Services"

        loadData()
    }

    private fun loadData() {
        val servicesLayout = findViewById<LinearLayout>(R.id.services_layout)
        servicesLayout.removeAllViews()

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    //get service categories
                    val serviceCategory = Service_Categories.select{Service_Categories.status eq "Available"}

                    for (category in serviceCategory) {
                        val catID = category[Service_Categories.cat_id]
                        val categoryName = category[Service_Categories.name]

                        val services = Services.select{Services.status eq "Available"}.toMutableList()

                        runOnUiThread {
                            // create expandable layout
                            val expandableLayout = expandableLayout {
                                setParentLayoutResource(R.layout.item_edit_services_expandable_parent)
                                setSecondLayoutResource(R.layout.item_edit_services_expandable_second)
                                setShowSpinner(true)
                                setSpinnerAnimate(true)
                                setSpinnerMargin(12f)
                                setSpinnerRotation(90)
                                setDuration(100)
                            }

                            //set header text to service category
                            expandableLayout.parentLayout.findViewById<TextView>(R.id.header_textview).text =
                                category[Service_Categories.name]
                            expandableLayout.parentLayout.setOnClickListener {
                                if (expandableLayout.isExpanded) {
                                    expandableLayout.collapse()
                                    expandableLayout.secondLayout.visibility = View.INVISIBLE
                                } else {
                                    expandableLayout.secondLayout.visibility = View.VISIBLE
                                    expandableLayout.expand()
                                }
                            }

                            //add child layouts
                            for (item in services) {
                                val serviceID = item[Services.service_id]
                                val name = item[Services.name]
                                val desc = item[Services.description]

                                val childView = layoutInflater.inflate(
                                    R.layout.item_remove_expandable_child,
                                    null
                                )
                                childView.findViewById<TextView>(R.id.child_textview).text = name
                                childView.findViewById<TextView>(R.id.child_desc_textview).text = desc

                                //add listeners
                                childView.findViewById<ImageButton>(R.id.edit).setOnClickListener {
                                    val intent = Intent(this@ManageCategories, ManageCategoriesItem::class.java)
                                    intent.putExtra("id", serviceID)
                                    intent.putExtra("name", name)
                                    intent.putExtra("desc", desc)
                                    startActivityForResult(intent, 2404)
                                }

                                childView.findViewById<ImageButton>(R.id.delete).setOnClickListener {
                                    val remove = showConfirmRemoveDialog(childView, serviceID, name, categoryName)
                                }

                                expandableLayout.secondLayout.findViewById<LinearLayout>(R.id.second_layout)
                                    .addView(childView)
                            }

                            //add expandable layout
                            servicesLayout.addView(expandableLayout)
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode  == RESULT_OK && requestCode == 2404) {
            loadData()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.add_services_button_menu, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.add_category_dropdown) {
            val intent = Intent(this, ManageCategoriesAddCategory::class.java)
            startActivityForResult(intent, 2404)
        } else if (item.itemId == R.id.edit_category_dropdown) {
            val intent = Intent(this, ManageCategoriesEditCategory::class.java)
            startActivityForResult(intent, 2404)
        } else if (item.itemId == R.id.add_service_dropdown){
            val intent = Intent(this, ManageCategoriesAddService::class.java)
            startActivityForResult(intent, 2404)
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showConfirmRemoveDialog(view : View, serviceID: Int, name: String, categoryName : String){
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle("Remove Service")
        builder.setMessage("Are you sure to remove the service '$name' from '$categoryName'?")
        builder.setPositiveButton(
            "Yes"
        ) { _, _ ->
            val thread = Thread {
                try {
                    Database.connect(
                        "jdbc:mysql://110.4.46.121/carportal",
                        "com.mysql.jdbc.Driver",
                        "fyp", "fyp2020"
                    )
                    transaction {
                        addLogger(StdOutSqlLogger)
                        Merchant_Services.deleteWhere{Merchant_Services.service_id eq serviceID }

                        Services.update({ Services.service_id eq serviceID }) {
                            it[Services.status] = "Unavailable"
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            thread.start()
            Toast.makeText(applicationContext,
                "Service deleted.", Toast.LENGTH_SHORT).show()
            view.visibility = View.GONE
        }
        builder.setNegativeButton(
            "Cancel"
        ) { dialog, _ ->
            dialog.dismiss()
        }
        builder.show()
    }

}