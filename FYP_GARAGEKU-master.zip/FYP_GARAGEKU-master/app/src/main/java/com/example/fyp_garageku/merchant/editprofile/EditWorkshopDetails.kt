package com.example.fyp_garageku.merchant.editprofile

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.Merchants
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction

class EditWorkshopDetails : AppCompatActivity() {

    private lateinit var workshopNameTextView : TextView
    private lateinit var websiteTextView : TextView
    private lateinit var emailTextView : TextView
    private lateinit var workshopAddressTextView : TextView
    private lateinit var officePhoneTextView : TextView
    private lateinit var operationHoursTextView : TextView
    private lateinit var companyNameTextView : TextView
    private lateinit var companyNumTextView : TextView
    private lateinit var sstIDTextView : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_workshop_details)

        supportActionBar?.title = "Edit Workshop Details"
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        //view variables
        workshopNameTextView = findViewById(R.id.workshop_name_textview)
        websiteTextView = findViewById(R.id.website_textview)
        emailTextView = findViewById(R.id.email_textview)
        workshopAddressTextView = findViewById(R.id.workshop_address_textview)
        officePhoneTextView = findViewById(R.id.office_phone_textview)
        operationHoursTextView = findViewById(R.id.operation_hours_textview)
        companyNameTextView = findViewById(R.id.company_name_textview)
        companyNumTextView = findViewById(R.id.company_num_textview)
        sstIDTextView = findViewById(R.id.sst_id_textview)

        loadData()

        //add event listeners
        workshopNameTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "Workshop Name")
            intent.putExtra("value", workshopNameTextView.text)
            startActivityForResult(intent, 2404)
        }
        websiteTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "Website")
            intent.putExtra("value", websiteTextView.text)
            startActivityForResult(intent, 2404)
        }
        emailTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "Email")
            intent.putExtra("value", emailTextView.text)
            startActivityForResult(intent, 2404)
        }
        workshopAddressTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "Workshop Address")
            intent.putExtra("value", workshopAddressTextView.text)
            startActivityForResult(intent, 2404)
        }
        officePhoneTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "Office Phone")
            intent.putExtra("value", officePhoneTextView.text)
            startActivityForResult(intent, 2404)
        }
        operationHoursTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "Operation Hours")
            intent.putExtra("value", operationHoursTextView.text)
            startActivityForResult(intent, 2404)
        }
        companyNameTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "Registered Company Name")
            intent.putExtra("value", companyNameTextView.text)
            startActivityForResult(intent, 2404)
        }
        companyNumTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "Company Registration No.")
            intent.putExtra("value", companyNumTextView.text)
            startActivityForResult(intent, 2404)
        }
        sstIDTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "SST ID")
            intent.putExtra("value", sstIDTextView.text)
            startActivityForResult(intent, 2404)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode  == RESULT_OK && requestCode == 2404) {
            if (data != null){
                val name = data.getStringExtra("name")
                val newValue = data.getStringExtra("newValue")
                when (name) {
                    "Workshop Name" ->
                        workshopNameTextView.text = newValue
                    "Website" ->
                        websiteTextView.text = newValue
                    "Email" ->
                        emailTextView.text = newValue
                    "Workshop Address" ->
                        workshopAddressTextView.text = newValue
                    "Office Phone" ->
                        officePhoneTextView.text = newValue
                    "Operation Hours" ->
                        operationHoursTextView.text = newValue
                    "Registered Company Name" ->
                        companyNameTextView.text = newValue
                    "Company Registration No." ->
                        companyNumTextView.text = newValue
                    "SST ID" ->
                        sstIDTextView.text = newValue
                }
            }
        }
    }

    private fun loadData(){
        val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        var userID = 0
        userID = sharedPref?.getString("id","")?.toInt()!!

        //fetch data from db
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    //get data from DB
                    val merchant = Merchants.select(Op.build { Merchants.user_id eq userID}).first()

                    //load data into textview
                    runOnUiThread{
                        workshopNameTextView.text = merchant[Merchants.workshop_name]
                        websiteTextView.text = merchant[Merchants.website]
                        emailTextView.text = merchant[Merchants.email_address]
                        workshopAddressTextView.text = merchant[Merchants.address]
                        officePhoneTextView.text = merchant[Merchants.office_phone]
                        operationHoursTextView.text = merchant[Merchants.operation_hours]
                        companyNameTextView.text = merchant[Merchants.company_name]
                        companyNumTextView.text = merchant[Merchants.company_reg_no]
                        sstIDTextView.text = merchant[Merchants.sst_id].toString()
                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

}