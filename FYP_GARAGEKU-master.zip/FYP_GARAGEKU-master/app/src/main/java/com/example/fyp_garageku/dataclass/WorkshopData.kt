package com.example.fyp_garageku.dataclass

data class WorkshopData(
    var id:Int? = 0,
    var name:String? = "",
    var address:String? = "",
    var email:String?="",
    var phone:String?="",
    var rating: Float? = 0.0f)
