package com.example.fyp_garageku.dataclass

data class ReviewData (
    var name:String? = "",
    var review:String? = "",
    var imageURL:String? = "",
    var date:String? = "",
    var isAnonymous:Boolean,
    var rating:Float = 0f,
    var service:String? = ""
)