package com.example.fyp_garageku.merchant.bookings

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.Bookings
import com.example.fyp_garageku.dataclass.Quotations
import com.example.fyp_garageku.dataclass.Replies
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction

class BookingsReply : AppCompatActivity() {

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bookings_reply)

        supportActionBar?.title = "Reply to Booking"
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val serviceNameTextView: TextView = findViewById(R.id.service_name_textview)
        val dateTextView: TextView = findViewById(R.id.date_textview)
        val timeTextView: TextView = findViewById(R.id.time_textview)
        val vehicleTextView: TextView = findViewById(R.id.vehicle_textview)
        val custNameTextView: TextView = findViewById(R.id.cust_name_textview)
        val completeLayout: LinearLayout = findViewById(R.id.complete_layout)

        val services = intent.extras?.getString("services")!!
        val date = intent.extras?.getString("date")!!
        val day = intent.extras?.getString("day")!!
        val time = intent.extras?.getString("time")!!
        val vehicle = intent.extras?.getString("vehicle")!!
        val custName = intent.extras?.getString("custName")!!
        val type = intent.extras?.getString("type")!!

        serviceNameTextView.text = services
        dateTextView.text = "$day, $date"
        timeTextView.text = time
        vehicleTextView.text = vehicle
        custNameTextView.text = custName

        if (type == "Approved"){
            completeLayout.visibility = View.VISIBLE

            findViewById<Button>(R.id.complete_button).setOnClickListener {
                markComplete()
            }
        } else {
            completeLayout.visibility = View.GONE
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val type = intent.extras?.getString("type")!!
        if (type == "Placed"){
            menuInflater.inflate(R.menu.confirm_deny_button_menu, menu)
        }
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.confirm_button) {
            val builder: AlertDialog.Builder = AlertDialog.Builder(this)
            builder.setTitle("Are you sure you want to accept this booking?")
            builder.setPositiveButton(
                "Yes"
            ) { _, _ ->
                addBooking()
            }
            builder.setNegativeButton(
                "Cancel"
            ) { dialog, _ ->
                dialog.dismiss()
            }
            builder.show()
        } else if (item.itemId == R.id.reject_button) {
            val builder: AlertDialog.Builder = AlertDialog.Builder(this)
            builder.setTitle("Are you sure you want to cancel this booking?")
            builder.setPositiveButton(
                "Yes"
            ) { _, _ ->
                cancelBooking()
            }
            builder.setNegativeButton(
                "Cancel"
            ) { dialog, _ ->
                dialog.dismiss()
            }
            builder.show()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun addBooking(){
        val bookingID = intent.extras?.getInt("bookingID")!!

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    Bookings.update({ Bookings.booking_id eq bookingID}) {
                        it[status] = "Approved"
                    }

                }
                setResult(RESULT_OK, intent)
                finish()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

    private fun cancelBooking(){
        val bookingID = intent.extras?.getInt("bookingID")!!

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    Bookings.update({ Bookings.booking_id eq bookingID}) {
                        it[status] = "Cancelled"
                    }

                }
                setResult(RESULT_OK, intent)
                finish()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

    private fun markComplete(){
        val bookingID = intent.extras?.getInt("bookingID")!!

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    Bookings.update({ Bookings.booking_id eq bookingID}) {
                        it[status] = "Serviced"
                    }

                }
                setResult(RESULT_OK, intent)
                finish()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }
}