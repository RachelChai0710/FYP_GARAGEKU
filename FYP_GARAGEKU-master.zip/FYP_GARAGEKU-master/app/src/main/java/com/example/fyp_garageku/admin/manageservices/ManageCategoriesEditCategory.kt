package com.example.fyp_garageku.admin.manageservices

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Base64
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.drawToBitmap
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.*
import com.example.fyp_garageku.helper_class.RetrofitInstance
import com.squareup.picasso.Picasso
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction
import org.w3c.dom.Text
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.http.Url
import java.io.ByteArrayOutputStream

class ManageCategoriesEditCategory : AppCompatActivity() {

    private val categoryList = ArrayList<String>()
    private val categoryIDList = ArrayList<Int>()

    var newImg = false
    var newImgUrl : Uri = Uri.EMPTY

    private lateinit var imageImageView : ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_categories_edit_category)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.title = "Edit Category"

        val spinner = findViewById<Spinner>(R.id.category_spinner)

        val editTextView = findViewById<TextView>(R.id.edit_name_textview)
        val categoryEditText = findViewById<EditText>(R.id.category_name_edittext)
        val selectLayout = findViewById<RelativeLayout>(R.id.select_image_layout)
        imageImageView = findViewById(R.id.select_image_imageview)
        val changeImageButton = findViewById<Button>(R.id.change_image_button)

        editTextView.visibility = View.GONE
        categoryEditText.visibility = View.GONE
        selectLayout.visibility = View.GONE
        imageImageView.visibility = View.GONE

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                categoryEditText.setText(spinner.selectedItem.toString())

                val catID = categoryIDList[pos]

                Picasso.get()
                    .load("http://test.onmyfinger.com/images/" + "service" + catID + ".jpg")
                    .placeholder(R.drawable.icon_loading)
                    .error(R.drawable.error)
                    .into(imageImageView)

                newImg = false

                editTextView.visibility = View.VISIBLE
                categoryEditText.visibility = View.VISIBLE
                selectLayout.visibility = View.VISIBLE
                imageImageView.visibility = View.VISIBLE
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {}
        }

        changeImageButton.setOnClickListener{
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"

            getPicture.launch(intent)
        }

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    val serviceCategory = Service_Categories.select{ Service_Categories.status eq "Available"}

                    for (category in serviceCategory) {
                        categoryList.add(category[Service_Categories.name])
                        categoryIDList.add(category[Service_Categories.cat_id])
                    }
                }

                runOnUiThread {
                    val arrayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categoryList)

                    spinner.adapter = arrayAdapter
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()

    }

    //activity for edit picture
    private var getPicture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {

            val data: Intent? = result.data

            val imgURL  = data?.data
            newImg = true
            newImgUrl = imgURL!!
            val previewImageView = ImageView(this)

            val params : ViewGroup.LayoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT )
            previewImageView.layoutParams = params

            Picasso.get()
                .load(imgURL)
                .resize(800,800)
                .centerCrop()
                .into(previewImageView)

            val inputStream = contentResolver.openInputStream(imgURL!!)
            val bitmap = BitmapFactory.decodeStream(inputStream)

            val builder: AlertDialog.Builder = AlertDialog.Builder(this)
            builder.setTitle("Confirm")
            builder.setMessage("Set this image as the new picture?")
            builder.setView(previewImageView)
            builder.setPositiveButton(
                "Yes"
            ) { _, _ ->
                imageImageView.setImageBitmap(bitmap)
            }
            builder.setNegativeButton(
                "Cancel"
            ) { dialog, _ ->
                dialog.dismiss()
            }
            builder.show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.confirm_trash_button_menu, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.delete_button) {
            showDeleteDialog()
        } else if (item.itemId == R.id.confirm_button) {
            showConfirmEditDialog()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showDeleteDialog(){
        val spinner = findViewById<Spinner>(R.id.category_spinner)
        val position = spinner.selectedItemPosition
        val id = categoryIDList[position]
        val name = spinner.selectedItem.toString()

        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle("Confirm deletion")
        builder.setMessage("Are you sure you want to delete the category $name?")
        builder.setPositiveButton(
            "Yes"
        ) { dialog, _ ->
            // update database
            val thread = Thread {
                try {
                    Database.connect(
                        "jdbc:mysql://110.4.46.121/carportal",
                        "com.mysql.jdbc.Driver",
                        "fyp", "fyp2020"
                    )
                    transaction {
                        addLogger(StdOutSqlLogger)

                        Service_Categories.update({Service_Categories.cat_id eq id}) {
                            it[Service_Categories.status] = "Unavailable"
                        }
                    }
                    dialog.dismiss()
                    setResult(RESULT_OK, intent)
                    finish()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            thread.start()
        }
        builder.setNegativeButton(
            "Cancel"
        ) { dialog, _ ->
            dialog.dismiss()
        }

        builder.show()
    }

    private fun showConfirmEditDialog(){
        val spinner = findViewById<Spinner>(R.id.category_spinner)
        val editText = findViewById<EditText>(R.id.category_name_edittext)
        val position = spinner.selectedItemPosition
        val id = categoryIDList[position]
        val name = spinner.selectedItem.toString()
        val newName = editText.text.toString()

        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle("Confirm changes")
        builder.setPositiveButton(
            "Yes"
        ) { dialog, _ ->
            // update database
            val thread = Thread {
                try {
                    Database.connect(
                        "jdbc:mysql://110.4.46.121/carportal",
                        "com.mysql.jdbc.Driver",
                        "fyp", "fyp2020"
                    )
                    transaction {
                        addLogger(StdOutSqlLogger)

                        Service_Categories.update({ Service_Categories.cat_id eq id }) {
                            it[Service_Categories.name] = newName
                        }
                    }

                    //upload image
                    if (newImg){
                        val inputStream = contentResolver.openInputStream(newImgUrl!!)
                        val bitmap = BitmapFactory.decodeStream(inputStream)
                        val byteArray = ByteArrayOutputStream()
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArray)
                        val base64img : String = Base64.encodeToString(byteArray.toByteArray(), Base64.DEFAULT)
                        val url :String = "service" + id + ".jpg"

                        val call : Call<CallResponse> = RetrofitInstance.api.UploadImage(base64img, url)

                        call.enqueue(object : Callback<CallResponse> {
                            override fun onResponse(call: Call<CallResponse>, response: Response<CallResponse>) {
                                if (response.isSuccessful){
                                    Toast.makeText(applicationContext,  response.body()!!.message, Toast.LENGTH_LONG).show()
                                }
                            }

                            override fun onFailure(call: Call<CallResponse>, t: Throwable) {
                                Toast.makeText(applicationContext,  t.message, Toast.LENGTH_LONG).show()
                            }

                        })
                    }

                    dialog.dismiss()
                    setResult(RESULT_OK, intent)
                    finish()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            thread.start()
        }
        builder.setNegativeButton(
            "Cancel"
        ) { dialog, _ ->
            dialog.dismiss()
        }

        builder.show()
    }

}