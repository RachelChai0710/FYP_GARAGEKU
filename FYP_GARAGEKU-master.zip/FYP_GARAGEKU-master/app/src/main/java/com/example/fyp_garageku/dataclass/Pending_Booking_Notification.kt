package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table

object Pending_Booking_Notification: Table() {
    val notification_id = integer("notification_id")
    val booking_id = integer("booking_id")
        .references(Bookings.booking_id)
    override val primaryKey = PrimaryKey(notification_id)
}