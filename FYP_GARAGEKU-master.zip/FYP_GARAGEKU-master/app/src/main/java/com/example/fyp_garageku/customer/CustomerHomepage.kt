package com.example.fyp_garageku.customer

import android.app.SearchManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.fyp_garageku.R
import com.example.fyp_garageku.adapters.CustInquiriesAdapter
import com.example.fyp_garageku.databinding.ActivityCustomerHomepageBinding
import com.example.fyp_garageku.dataclass.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.*


class CustomerHomepage : AppCompatActivity(),CustInquiriesAdapter.CustInquiriesAdapterListener{
    private lateinit var binding: ActivityCustomerHomepageBinding
    private lateinit var navController: NavController
    private var unreadCount = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCustomerHomepageBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        setSupportActionBar(binding.toolbar)
        navController = findNavController(R.id.nav_home_fragment)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.homeFragment, R.id.custInquiriesFragment, R.id.custProfileFragment
            )
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        binding.custNavView.setupWithNavController(navController)

        navController.addOnDestinationChangedListener { _, destination, _ ->
            if (destination.id == R.id.custProfileFragment) {
                binding.toolbar.visibility = View.GONE

            } else if (destination.id == R.id.homeFragment) {
                binding.toolbar.visibility = View.VISIBLE
                menuInflater.inflate(R.menu.cust_home_menu, binding.toolbar.menu)
            } else {
                binding.toolbar.visibility = View.VISIBLE
                binding.toolbar.menu.clear()
            }
        }
        showInquiriesBadge()
        val handler = Handler()
        val delay = 1 * 1000
        handler.postDelayed(object : Runnable {
            override fun run() {
                showInquiriesBadge()
                //reset timer
                val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
                val custID = sharedPref?.getString("id", "0")?.toInt()
                if (custID!=0){
                    handler.postDelayed(this, delay.toLong())
                }
            }
        }, delay.toLong())

    }

    override fun onPrepareOptionsMenu(menu: Menu?): Boolean {
        menu?.clear()
        menuInflater.inflate(R.menu.cust_home_menu, menu)
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == R.id.location) {
            val id = navController.currentDestination?.id
            navController.popBackStack(id!!, true)
            navController.navigate(id)
        } else {
            val searchView = item.actionView as androidx.appcompat.widget.SearchView
            val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
            searchView.setBackgroundColor(Color.WHITE)
            searchView.apply {
                setSearchableInfo(searchManager.getSearchableInfo(componentName))
                isSubmitButtonEnabled = true
            }
            searchView.setOnQueryTextListener(object :
                androidx.appcompat.widget.SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String?): Boolean {
                    return false
                }

                override fun onQueryTextChange(newText: String?): Boolean {
                    return false
                }

            })

        }
        return super.onOptionsItemSelected(item)
    }

    private fun showInquiriesBadge(){
        GlobalScope.launch {
            withContext(Dispatchers.IO){loadInquiries()}
            if (unreadCount > 0) {
                withContext(Dispatchers.Main) {
                    var badge = binding.custNavView.getOrCreateBadge(R.id.custInquiriesFragment)
                    badge.isVisible = true
                    badge.number = unreadCount
                }
            }
        }
    }

    private suspend fun loadInquiries(){
        val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        val custID = sharedPref?.getString("id", "0")?.toInt()
        if (custID != 0){
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    var inquiry: CustInquiriesData
                    addLogger(StdOutSqlLogger)

                    unreadCount = Quotations.join(
                        Replies,
                        JoinType.INNER,
                        additionalConstraint = { Quotations.quote_id eq Replies.quote_id })
                        .select{ Quotations.cust_id eq (custID ?: 0) and (Replies.status eq "Unread")}
                        .orderBy(Replies.reply_date to SortOrder.DESC).count().toInt()

                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

    }

    override fun onInquiryCountUpdated(row:Int) {
        var badge = binding.custNavView.getOrCreateBadge(R.id.custInquiriesFragment)
        badge.isVisible = true
        badge.number = unreadCount - row
        unreadCount -= row
        if (badge.number == 0){
            badge.isVisible = false
        }
    }


}

