package com.example.fyp_garageku.adapters

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.getSystemService
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.fyp_garageku.R
import com.example.fyp_garageku.customer.BookAppointment
import com.example.fyp_garageku.customer.DialogReviewFragment
import com.example.fyp_garageku.dataclass.AppointmentsData
import com.example.fyp_garageku.dataclass.Booking_Services
import com.example.fyp_garageku.dataclass.Bookings
import com.example.fyp_garageku.dataclass.Pending_Booking_Notification
import com.example.fyp_garageku.helper_class.AlarmReceiver
import com.squareup.picasso.Picasso
import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction

class AppointmentsAdapter(
    private val context: Context,
    private val dataset: MutableList<AppointmentsData>,
    private val isAll: Boolean,
    private val listener: AppointmentDialogListener
) : RecyclerView.Adapter<AppointmentsAdapter.ItemViewHolder>() {
    private lateinit var selectedHolder: ItemViewHolder

    interface AppointmentDialogListener {
        fun onDeletedAll()
        fun onCancelled(notificationID:Int)
    }

    class ItemViewHolder(private val view: View) : RecyclerView.ViewHolder(view) {
        val txtBookingSlot: TextView = view.findViewById(R.id.appointments_bookingSlot)
        val imgWorkshop: CircleImageView = view.findViewById(R.id.appointments_workshop_img)
        val txtName: TextView = view.findViewById(R.id.appointments_name)
        val txtVehicle: TextView = view.findViewById(R.id.appointments_vehicle)
        val txtStatus: TextView = view.findViewById(R.id.appointments_status)
        val btnReview: Button = view.findViewById(R.id.appointments_btnReview)
        val txtService: TextView = view.findViewById(R.id.appointments_service)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(context)
            .inflate(R.layout.item_appointments, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        holder.txtBookingSlot.text = "${item.bookedDate} ${item.slot}"
        holder.txtName.text = item.name
        holder.txtVehicle.text = item.vehicle
        holder.txtStatus.text = item.status
        holder.txtService.text = item.service
        Picasso.get()
            .load("http://test.onmyfinger.com/images/merchant${item.merchantID}displaypicture.jpg")
            .placeholder(R.drawable.placeholder)
            .error(R.drawable.placeholder)
            .into(holder.imgWorkshop)
        Glide.with(context)

        when (item.status) {
            "Serviced" -> {
                holder.btnReview.visibility = View.VISIBLE
                holder.btnReview.text = context.getString(R.string.review)
            }
            "Placed" -> {
                holder.btnReview.visibility = View.VISIBLE
                holder.btnReview.text = context.getString(R.string.cancel)
            }
            else -> {
                holder.btnReview.visibility = View.GONE
            }
        }

        holder.btnReview.setOnClickListener {
            when (holder.btnReview.text) {
                "Cancel" -> {
                    GlobalScope.launch {
                        val isSuccess =
                            withContext(Dispatchers.IO) { updateStatus(item.bookingID!!) }

                        withContext(Dispatchers.Main) {
                            val builder = AlertDialog.Builder(context)
                            //set title for alert dialog
                            builder.setTitle("Cancel Appointment")
                            //set message for alert dialog
                            builder.setMessage("Are you sure to cancel appointment on ${holder.txtBookingSlot.text}?")

                            //performing positive action
                            builder.setPositiveButton("Yes") { _, _ ->
                                if (isSuccess) {
                                    if (!isAll) {
                                        dataset.removeAt(position);
                                        notifyItemRemoved(position);
                                        notifyItemRangeChanged(position, dataset.size)
                                        if (dataset.size == 0) {
                                            listener.onDeletedAll()
                                        }
                                    } else {
                                        item.status = "Cancelled"
                                        holder.btnReview.visibility = View.GONE
                                        notifyItemChanged(position)
                                    }
                                    Toast.makeText(
                                        context,
                                        "Your appointment is cancelled!",
                                        Toast.LENGTH_LONG
                                    ).show()
                                } else {
                                    Toast.makeText(
                                        context,
                                        "Failed to cancel the appointment! Please try again.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }

                            //performing negative action
                            builder.setNegativeButton("No") { _, _ ->

                            }
                            // Create the AlertDialog
                            val alertDialog: AlertDialog = builder.create()
                            // Set other dialog properties
                            alertDialog.setCancelable(false)
                            alertDialog.show()
                        }
                    }
                }
                "Review" -> {
                    val arg = Bundle()
                    arg.putString("name", item.name)
                    arg.putString("service", item.service)
                    arg.putString("vehicle", item.vehicle)
                    arg.putInt("position", position)
                    selectedHolder = holder
                    item.bookingID?.let { it1 -> arg.putInt("bookingID", it1) }
                    item.merchantID?.let { it1 -> arg.putInt("merchantID", it1) }
                    callDialog(arg)
                }
            }
        }
    }

    private suspend fun updateStatus(id: Int): Boolean {
        var booking = 0

        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)
                //get data from DB
                booking = Bookings.update({ Bookings.booking_id eq id }) {
                    it[status] = "Cancelled"
                }
                val notificationID =
                    Pending_Booking_Notification.select(Op.build { Pending_Booking_Notification.booking_id eq id}).first()[Pending_Booking_Notification.notification_id]
                listener.onCancelled(notificationID)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return booking != 0
    }

    private fun callDialog(arg: Bundle) {
        val dialog = DialogReviewFragment(this)
        dialog.arguments = arg
        val ft = (context as AppCompatActivity).supportFragmentManager.beginTransaction()
        dialog.show(ft, "Review and Rating")
    }

    override fun getItemCount() = dataset.size

    fun onSubmitted(position: Int) {
        if (!isAll) {
            dataset.removeAt(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, dataset.size)
            if (dataset.size == 0) {
                listener.onDeletedAll()
            }
        } else {
            dataset[position].status = "Reviewed"
            selectedHolder.btnReview.visibility = View.GONE
            notifyItemChanged(position)
        }
    }

}