package com.example.fyp_garageku.customer

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fyp_garageku.adapters.AppointmentsAdapter
import com.example.fyp_garageku.databinding.FragmentCancelledAppointmentsBinding
import com.example.fyp_garageku.dataclass.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction

class CancelledAppointmentsFragment : Fragment(),AppointmentsAdapter.AppointmentDialogListener {
    private lateinit var _binding: FragmentCancelledAppointmentsBinding
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentCancelledAppointmentsBinding.inflate(inflater, container, false)

        initiaRecycleView()

        return binding.root
    }

    fun initiaRecycleView() {
        binding.cancelledRecView.removeAllViewsInLayout()
        binding.cancelledProgress.visibility = View.VISIBLE
        binding.cancelledRecView.visibility = View.GONE
        binding.resultNotFoundLayout.visibility = View.GONE
        GlobalScope.launch {
            val list = withContext(Dispatchers.IO){
                loadAppointments()
            }

            withContext(Dispatchers.Main) {
                val layoutManager =
                    LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
                binding.cancelledRecView.layoutManager = layoutManager
                binding.cancelledRecView.addItemDecoration(
                    DividerItemDecoration(
                        binding.cancelledRecView.context,
                        layoutManager.orientation
                    )
                )
                if (list.isNotEmpty()) {
                    val myAdapter = AppointmentsAdapter(requireContext(), list,false,this@CancelledAppointmentsFragment)
                    binding.cancelledRecView.adapter = myAdapter
                    binding.cancelledRecView.setHasFixedSize(true)
                    binding.cancelledProgress.visibility = View.GONE
                    binding.cancelledRecView.visibility = View.VISIBLE
                    binding.resultNotFoundLayout.visibility = View.GONE
                } else {
                    binding.cancelledProgress.visibility = View.GONE
                    binding.cancelledRecView.visibility = View.GONE
                    binding.resultNotFoundLayout.visibility = View.VISIBLE
                }
            }
        }
    }

    private suspend fun loadAppointments():MutableList<AppointmentsData> {
        val list = mutableListOf<AppointmentsData>()
        val sharedPref = activity?.getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        val id = sharedPref?.getString("id", "")?.toInt()
        try {
            val db = Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                var appointments: AppointmentsData
                addLogger(StdOutSqlLogger)

                Bookings.join(Time_Slots, JoinType.INNER, null, null) {
                    (Bookings.slot_id eq Time_Slots.timeslot_id)
                }
                    .join(Merchants, JoinType.INNER, null, null) {
                        (Bookings.merchant_id eq Merchants.merchant_id)
                    }
                    .join(Vehicles, JoinType.INNER, null, null) {
                        (Bookings.vehicle_id eq Vehicles.vehicle_id)
                    }
                    .select(Op.build { Bookings.status eq "Cancelled" and (Bookings.cust_id eq id!! )})
                    .orderBy(Bookings.date to SortOrder.DESC).map {
                        val start = "${it[Time_Slots.start_time].toString().substring(0,2)}:${it[Time_Slots.start_time].toString().substring(2)}"
                        val end = "${it[Time_Slots.end_time].toString().substring(0,2)}:${it[Time_Slots.end_time].toString().substring(2)}"
                        val slot = "$start - $end"
                        val vehicle = "${it[Vehicles.brand]} - ${it[Vehicles.model]} ${it[Vehicles.year]} (${it[Vehicles.car_plate]})"

                        val serviceList = Booking_Services.join(Services,JoinType.INNER, null, null) {
                            (Booking_Services.service_id eq Services.service_id)
                        }
                            .select(Op.build { Booking_Services.booking_id eq it[Bookings.booking_id] }).toMutableList()
                        var service = ""
                        for (item in serviceList){
                            service += if (item[Services.name] == serviceList.last()[Services.name]){
                                "${item[Services.name]}"
                            } else
                                "${item[Services.name]} \n"
                        }

                        appointments = AppointmentsData(
                            it[Bookings.booking_id],
                            it[Bookings.merchant_id],
                            it[Bookings.bookedDate],
                            slot,
                            it[Bookings.status],
                            it[Merchants.workshop_name],
                            vehicle,
                            service
                        )
                        list.add(appointments)
                    }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    override fun onDeletedAll() {
        binding.cancelledRecView.visibility = View.GONE
        binding.resultNotFoundLayout.visibility = View.VISIBLE
    }

    override fun onCancelled(notificationID: Int) {

    }
}