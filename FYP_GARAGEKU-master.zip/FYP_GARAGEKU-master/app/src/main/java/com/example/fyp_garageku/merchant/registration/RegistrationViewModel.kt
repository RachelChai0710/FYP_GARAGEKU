package com.example.fyp_garageku.merchant.registration

import androidx.lifecycle.ViewModel

class RegistrationViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}