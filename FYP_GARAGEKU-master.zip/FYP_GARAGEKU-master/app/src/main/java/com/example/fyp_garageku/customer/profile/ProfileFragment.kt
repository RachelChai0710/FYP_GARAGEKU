package com.example.fyp_garageku.customer.profile

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.example.fyp_garageku.*
import com.example.fyp_garageku.databinding.FragmentCustProfileBinding
import com.facebook.AccessToken
import com.facebook.GraphRequest
import com.facebook.HttpMethod
import com.facebook.login.LoginManager
import org.jetbrains.exposed.sql.*
import com.example.fyp_garageku.customer.MyAppointments
import com.example.fyp_garageku.customer.MyVehicles
import com.google.android.gms.auth.api.signin.GoogleSignIn

import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task


class ProfileFragment : Fragment() {

  private lateinit var profileViewModel: ProfileViewModel
  private var _binding: FragmentCustProfileBinding? = null
  private val binding get() = _binding!!
  override fun onCreateView(
    inflater: LayoutInflater,
    container: ViewGroup?,
    savedInstanceState: Bundle?
  ): View? {
    profileViewModel =
            ViewModelProvider(this).get(ProfileViewModel::class.java)
    _binding = FragmentCustProfileBinding.inflate(inflater, container, false)
    val view = binding.root
    val account = GoogleSignIn.getLastSignedInAccount(activity)

    val sharedPref = activity?.getSharedPreferences(
      "GaragekuSP", Context.MODE_PRIVATE)
    profileViewModel.email.value = sharedPref?.getString("email","")
    profileViewModel.phone.value = sharedPref?.getString("phone","")
    profileViewModel.userName.value = sharedPref?.getString("username","")

    //load data to text views
    profileViewModel.userName.observe(viewLifecycleOwner, Observer {
      binding.profileCustUsername.text = it.toString()
    })
    profileViewModel.phone.observe(viewLifecycleOwner, Observer {
      binding.profileCustPhone.text =  it.toString()
    })
    profileViewModel.email.observe(viewLifecycleOwner, Observer {
      binding.profileCustEmail.text = it.toString()
    })

    if (AccessToken.getCurrentAccessToken() != null || account != null) {
      val imageURL = sharedPref?.getString("imageURL", "")
      Glide.with(this).load(imageURL).error(R.drawable.ic_baseline_account_circle_white_24).into(binding.profilePic)
    }
    //Button onclick
    binding.profileChangePw.setOnClickListener(){
      activity?.let{
        val intent = Intent (it, ChangePassword::class.java)
        intent.putExtra("email",sharedPref?.getString("email",""))
        it.startActivity(intent)
      }
    }
    binding.profileMyAppointment.setOnClickListener(){
      activity?.let{
        val intent = Intent (it, MyAppointments::class.java)
        it.startActivity(intent)
      }
    }
    binding.profileMyVehicles.setOnClickListener(){
      activity?.let{
        val intent = Intent (it, MyVehicles::class.java)
        it.startActivity(intent)
      }
    }
    binding.profileLogout.setOnClickListener(){
      activity?.let{
        val editor = sharedPref?.edit()
        editor?.clear()?.apply()

        if (AccessToken.getCurrentAccessToken() != null) {
          GraphRequest(
            AccessToken.getCurrentAccessToken(), "/me/permissions/", null, HttpMethod.DELETE,
            GraphRequest.Callback {
              AccessToken.setCurrentAccessToken(null)
              LoginManager.getInstance().logOut()
            }
          ).executeAsync()
        }
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
          .requestEmail()
          .requestProfile()
          .build()
        val mGoogleSignInClient = GoogleSignIn.getClient(requireActivity(), gso)

        if (account!= null){
          mGoogleSignInClient.signOut()
            .addOnCompleteListener(requireActivity(), object : OnCompleteListener<Void?> {
              override fun onComplete(task: Task<Void?>) {
                Toast.makeText(it,"Logged Out Successfully!",Toast.LENGTH_LONG).show()
                val intent = Intent (it, Login::class.java)
                it.startActivity(intent)
                it.finish()
              }
            })
        }

        val intent = Intent (it, Login::class.java)
        activity?.startActivity(intent)
        activity?.finish()
      }
    }
    return view
  }

}