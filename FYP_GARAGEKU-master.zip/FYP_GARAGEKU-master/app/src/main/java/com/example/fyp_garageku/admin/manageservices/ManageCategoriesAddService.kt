package com.example.fyp_garageku.admin.manageservices

import android.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.Merchant_Registrations
import com.example.fyp_garageku.dataclass.Service_Categories
import com.example.fyp_garageku.dataclass.Services
import com.example.fyp_garageku.dataclass.Users
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction

class ManageCategoriesAddService : AppCompatActivity() {

    private val categoryList = ArrayList<String>()
    private val categoryIDList = ArrayList<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_categories_add_service)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.title = "Add New Service"

        val spinner = findViewById<Spinner>(R.id.category_spinner)

        val editTextView = findViewById<TextView>(R.id.edit_name_textview)
        val nameEditText = findViewById<EditText>(R.id.service_name_edittext)
        val editDescTextView = findViewById<TextView>(R.id.edit_desc_textview)
        val descEditText = findViewById<EditText>(R.id.service_desc_edittext)

        editTextView.visibility = View.GONE
        nameEditText.visibility = View.GONE
        editDescTextView.visibility = View.GONE
        descEditText.visibility = View.GONE

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                editTextView.visibility = View.VISIBLE
                nameEditText.visibility = View.VISIBLE
                editDescTextView.visibility = View.VISIBLE
                descEditText.visibility = View.VISIBLE
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {}
        }

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    val serviceCategory = Service_Categories.select{ Service_Categories.status eq "Available"}

                    for (category in serviceCategory) {
                        categoryList.add(category[Service_Categories.name])
                        categoryIDList.add(category[Service_Categories.cat_id])
                    }
                }

                runOnUiThread {
                    val arrayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categoryList)

                    spinner.adapter = arrayAdapter
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.confirm_button_menu, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.confirm_button) {
            showConfirmDialog()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showConfirmDialog() {
        val spinner = findViewById<Spinner>(R.id.category_spinner)
        val position = spinner.selectedItemPosition
        val id = categoryIDList[position]
        val name = spinner.selectedItem.toString()

        val nameEditText = findViewById<EditText>(R.id.service_name_edittext)
        val descEditText = findViewById<EditText>(R.id.service_desc_edittext)

        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle("Add New Service")
        builder.setMessage("Are you sure you want to add a new service to the category $name?")
        builder.setPositiveButton(
            "Yes"
        ) { dialog, _ ->
            // update database
            val thread = Thread {
                try {
                    Database.connect(
                        "jdbc:mysql://110.4.46.121/carportal",
                        "com.mysql.jdbc.Driver",
                        "fyp", "fyp2020"
                    )
                    transaction {
                        addLogger(StdOutSqlLogger)

                        Services.insert {
                            it[Services.name] = nameEditText.text.toString()
                            it[Services.description] = descEditText.text.toString()
                            it[Services.cat_id] = id
                            it[Services.status] = "Available"
                        }
                    }
                    dialog.dismiss()
                    setResult(RESULT_OK, intent)
                    finish()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            thread.start()
        }
        builder.setNegativeButton(
            "Cancel"
        ) { dialog, _ ->
            dialog.dismiss()
        }

        builder.show()

    }

}