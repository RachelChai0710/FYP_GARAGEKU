package com.example.fyp_garageku.customer

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.example.fyp_garageku.R
import com.example.fyp_garageku.databinding.ActivityInquiriesDetailsBinding
import com.example.fyp_garageku.dataclass.*
import com.example.fyp_garageku.helper_class.Hash
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.*

class InquiriesDetails : AppCompatActivity() {
    private lateinit var binding: ActivityInquiriesDetailsBinding
    private var workshopName = ""

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInquiriesDetailsBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        workshopName = intent.getStringExtra("name").toString()
        this.title = workshopName
        GlobalScope.launch {
            withContext(Dispatchers.IO) { loadQuotation() }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private suspend fun loadQuotation() {
        val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        val custID = sharedPref?.getString("id", "")?.toInt()
        val hash = Hash()
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)
                val quote = Quotations.join(
                    Merchants,
                    JoinType.INNER,
                    additionalConstraint = { Quotations.merchant_id eq Merchants.merchant_id })
                    .join(
                        Vehicles,
                        JoinType.INNER,
                        additionalConstraint = { Quotations.vehicle_id eq Vehicles.vehicle_id })
                    .select {
                        Merchants.workshop_name eq workshopName and (Quotations.cust_id eq (custID
                            ?: 0))
                    }
                    .orderBy(Quotations.date to SortOrder.ASC).toMutableList()
                val reply = Replies
                    .join(
                        Quotations,
                        JoinType.INNER,
                        additionalConstraint = { Replies.quote_id eq Quotations.quote_id })
                    .join(
                        Merchants,
                        JoinType.INNER,
                        additionalConstraint = { Quotations.merchant_id eq Merchants.merchant_id })
                    .slice(Replies.reply, Replies.reply_date, Replies.quote_id)
                    .select {
                        Merchants.workshop_name eq workshopName and (Quotations.cust_id eq (custID
                            ?: 0))
                    }.orderBy(Replies.reply_date to SortOrder.DESC).toMutableList()
                val timeList = mutableListOf<Instant>()
                if (quote.isNotEmpty()) {
                    val layoutParams =
                        LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
                    layoutParams.setMargins(0, 30, 0, 10)
                    val formatter: DateTimeFormatter =
                        DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT)
                            .withLocale(Locale.UK)
                            .withZone(ZoneId.systemDefault())
                    for (item in quote) {
                        val quoteID = item[Quotations.quote_id]
                        val serviceList = Quotation_Services.join(Services,JoinType.INNER,additionalConstraint = {Quotation_Services.service_id eq Services.service_id})
                            .slice(Services.name)
                            .select(Op.build { Quotation_Services.quote_id eq quoteID}).toMutableList()
                        var service = ""
                        for (item in serviceList){
                            service += if (item == serviceList.last())
                                "${item[Services.name]}"
                            else
                                "${item[Services.name]} \n"
                        }
                        GlobalScope.launch {
                            withContext(Dispatchers.Main) {
                                val time = layoutInflater.inflate(
                                    R.layout.item_time,
                                    null
                                )
                                timeList.add(item[Quotations.date])
                                val formattedDate = formatter.format(item[Quotations.date])
                                time.findViewById<TextView>(R.id.dateTime).text = formattedDate
                                binding.inquiriesLinearLayout.addView(time, layoutParams)

                                val quotation = layoutInflater.inflate(
                                    R.layout.item_quotation,
                                    null
                                )
                                quotation.findViewById<TextView>(R.id.quotation_id).text =
                                    "#${hash.getShortHash(item[Quotations.quote_id].toLong())}"
                                quotation.findViewById<TextView>(R.id.quotation_txtService).text =
                                    service
                                quotation.findViewById<TextView>(R.id.quotation_txtDesc).text =
                                    item[Quotations.desc]
                                quotation.findViewById<TextView>(R.id.quotation_txtCarPlate).text =
                                    item[Vehicles.car_plate]
                                quotation.findViewById<TextView>(R.id.quotation_txtBrand).text =
                                    item[Vehicles.brand]
                                quotation.findViewById<TextView>(R.id.quotation_txtModel).text =
                                    item[Vehicles.model]
                                quotation.findViewById<TextView>(R.id.quotation_txtYear).text =
                                    "(${item[Vehicles.year]})"
                                binding.inquiriesLinearLayout.addView(quotation, layoutParams)
                            }
                        }
                    }
                    if (reply.isNotEmpty()) {
                        GlobalScope.launch {
                            withContext(Dispatchers.Main) {
                                for (i in 0 until reply.size - 1) {
                                    val lastReply = reply[i]
                                    if (timeList[timeList.lastIndex].isBefore(lastReply[Replies.reply_date])) {
                                        val time = layoutInflater.inflate(
                                            R.layout.item_time,
                                            null
                                        )
                                        val formattedDate =
                                            formatter.format(lastReply[Replies.reply_date])
                                        time.findViewById<TextView>(R.id.dateTime).text =
                                            formattedDate
                                        binding.inquiriesLinearLayout.addView(time, layoutParams)

                                        val replyLayout = layoutInflater.inflate(
                                            R.layout.item_reply,
                                            null
                                        )
                                        replyLayout.findViewById<TextView>(R.id.reply_id).text =
                                            "#${hash.getShortHash(lastReply[Replies.quote_id].toLong())}"
                                        replyLayout.findViewById<TextView>(R.id.reply_txtReply).text =
                                            lastReply[Replies.reply]
                                        binding.inquiriesLinearLayout.addView(
                                            replyLayout,
                                            layoutParams
                                        )
                                        reply.removeAt(i)
                                    }

                                }
                                for (item in reply) {
                                    val time = layoutInflater.inflate(
                                        R.layout.item_time,
                                        null
                                    )
                                    var position = 0
                                        for (i in 0 until timeList.size) {
                                            val isAfter = timeList[i].isAfter(item[Replies.reply_date])

                                            if (isAfter){
                                                position = i * 2
                                                timeList.add(i,item[Replies.reply_date])
                                                break
                                            }
                                        }

                                    val childList = mutableListOf<View>()
                                    for (i in position until binding.inquiriesLinearLayout.childCount) {
                                        val view = binding.inquiriesLinearLayout.getChildAt(i)
                                            childList.add(view)


                                    }
                                    val formattedDate = formatter.format(item[Replies.reply_date])
                                    time.findViewById<TextView>(R.id.dateTime).text = formattedDate
                                    if (time.parent != null) {
                                        (time.parent as ViewGroup).removeView(time)
                                    }

                                    binding.inquiriesLinearLayout.addView(
                                        time,
                                        position,
                                        layoutParams
                                    )
                                    position++
                                    val replyLayout = layoutInflater.inflate(
                                        R.layout.item_reply,
                                        null
                                    )
                                    replyLayout.findViewById<TextView>(R.id.reply_id).text =
                                        "#${hash.getShortHash(item[Replies.quote_id].toLong())}"
                                    replyLayout.findViewById<TextView>(R.id.reply_txtReply).text =
                                        item[Replies.reply]
                                    binding.inquiriesLinearLayout.addView(
                                        replyLayout,
                                        position,
                                        layoutParams
                                    )
                                    for (item in childList) {
                                        position++
                                        if (item.parent != null) {
                                            (item.parent as ViewGroup).removeView(item)
                                        }
                                        binding.inquiriesLinearLayout.addView(
                                            item,
                                            position,
                                            layoutParams
                                        )
                                    }
                                }
                                binding.inquiriesNestedScrollView.post {
                                    binding.inquiriesNestedScrollView.fullScroll(View.FOCUS_DOWN)
                                }
                            }
                        }
                    }
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

}