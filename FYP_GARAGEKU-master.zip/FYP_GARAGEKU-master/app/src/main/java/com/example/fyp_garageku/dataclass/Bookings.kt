package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.`java-time`.timestamp

object Bookings : Table() {
    val booking_id = integer("booking_id").autoIncrement()
    val merchant_id = integer("merchant_id")
        .uniqueIndex()
        .references(Merchants.merchant_id)
    val cust_id = integer("cust_id")
        .uniqueIndex()
        .references(Customers.cust_id)
    val slot_id = integer("slot_id")
        .uniqueIndex()
        .references(Time_Slots.timeslot_id)
    val vehicle_id = integer("vehicle_id")
        .uniqueIndex()
        .references(Vehicles.vehicle_id)
    val date = timestamp("date")
    val status = varchar("status",45)
    val bookedDate = varchar("bookedDate",45)
    override val primaryKey = PrimaryKey(booking_id)
}