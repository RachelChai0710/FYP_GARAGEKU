package com.example.fyp_garageku.adapters

import android.content.Context
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.Customers
import com.example.fyp_garageku.dataclass.ReviewData
import com.example.fyp_garageku.dataclass.Reviews
import com.example.fyp_garageku.dataclass.Services
import org.jetbrains.exposed.sql.ResultRow
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.*

class ReviewsAdapter (private val context: Context,
                      private val dataset : List<ReviewData>
) : RecyclerView.Adapter<ReviewsAdapter.ItemViewHolder>() {

    class ItemViewHolder(private val view: View) : RecyclerView.ViewHolder(view) {
        val txtName: TextView = view.findViewById(R.id.merchant_review_name)
        val txtService: TextView = view.findViewById(R.id.merchant_review_service)
        val txtReview : TextView = view.findViewById(R.id.merchant_review)
        val txtDate : TextView = view.findViewById(R.id.merchant_review_date)
        val img: ImageView = view.findViewById(R.id.merchant_review_img)
        val ratingBar: RatingBar = view.findViewById(R.id.merchant_review_rating)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(context)
            .inflate(R.layout.item_reviews, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        val name = item.name

        if (item.isAnonymous){
            var temp = ""
            if (name != null) {
                for (i in 1 until name.length-1){
                    temp += "*"
                }
            }
            val hideName = (name?.substring(0,1) ?: "") + temp + (name?.substring(name.length - 1) ?: "")
            holder.txtName.text = hideName
        }
        else{
            holder.txtName.text = name
        }
        if (!item.imageURL.isNullOrBlank())
            Glide.with(context).load(item.imageURL).error(R.drawable.ic_baseline_account_circle_24).into(holder.img)
        if (item.review.isNullOrBlank()){
            holder.txtReview.visibility = View.GONE
        }
        holder.txtReview.text = item.review
        holder.txtService.text = item.service
        holder.txtDate.text = item.date
        holder.ratingBar.rating = item.rating
    }

    override fun getItemCount() = dataset.size


}