package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table

object Services: Table() {
    val service_id = integer("service_id").autoIncrement()
    val name = varchar("name",45)
    val description = varchar("description",100)
    val cat_id = integer("cat_id")
    val status = varchar("status",45)

    override val primaryKey = PrimaryKey(service_id)
}