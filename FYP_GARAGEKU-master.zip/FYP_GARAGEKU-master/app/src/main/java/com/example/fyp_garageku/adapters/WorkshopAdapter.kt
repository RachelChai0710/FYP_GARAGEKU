package com.example.fyp_garageku.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.fyp_garageku.R
import com.example.fyp_garageku.customer.WorkshopDetails
import com.example.fyp_garageku.dataclass.Merchants
import com.example.fyp_garageku.dataclass.WorkshopData
import com.squareup.picasso.Picasso

class WorkshopAdapter (private val context: Context,
                       private val dataset : List<WorkshopData>
) : RecyclerView.Adapter<WorkshopAdapter.ItemViewHolder>() {

    class ItemViewHolder(view : View) : RecyclerView.ViewHolder(view) {
        val txtName : TextView = view.findViewById(R.id.view_all_workshop_name)
        val txtAddress : TextView = view.findViewById(R.id.view_all_workshop_address)
        val img: ImageView = view.findViewById(R.id.view_all_workshops_img)
        val txtEmail : TextView = view.findViewById(R.id.view_all_workshop_email)
        val txtPhone : TextView = view.findViewById(R.id.view_all_workshop_phone)
        val ratingBar: RatingBar = view.findViewById(R.id.view_all_workshop_rating)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(context)
            .inflate(R.layout.item_workshops, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        holder.txtName.text = item.name
        holder.txtAddress.text = item.address
        holder.txtEmail.text = item.email
        holder.txtPhone.text = item.phone
        holder.ratingBar.rating = item.rating!!
        Picasso.get()
            .load("http://test.onmyfinger.com/images/merchant${item.id}displaypicture.jpg")
            .placeholder(R.drawable.placeholder)
            .error(R.drawable.placeholder)
            .into(holder.img)
        holder.itemView.setOnClickListener{
            val intent = Intent(context, WorkshopDetails::class.java)
            intent.putExtra("name",holder.txtName.text)
            intent.putExtra("id",item.id)
            context.startActivity(intent)
        }
    }

    override fun getItemCount() = dataset.size


}