package com.example.fyp_garageku.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.admin.viewusers.ViewCustomers
import com.example.fyp_garageku.admin.viewusers.ViewMerchants
import com.example.fyp_garageku.merchant.bookings.BookingsReply

class ViewUsersAdapter (private val context: Context,
                               val nameList : ArrayList<String>,
                               val idList : ArrayList<Int>,
                               private val selectedType : String
) : RecyclerView.Adapter<ViewUsersAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val textview : TextView = view.findViewById(R.id.textview)
        val layout : LinearLayout = view.findViewById(R.id.layout)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_view_user, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        holder.textview.text = nameList[position]
        val id = idList[position]

        holder.layout.setOnClickListener {
            if (selectedType == "Customers"){
                val intent = Intent(context, ViewCustomers::class.java)
                intent.putExtra("id", id)
                context.startActivity(intent)
            } else if (selectedType == "Merchants"){
                val intent = Intent(context, ViewMerchants::class.java)
                intent.putExtra("id", id)
                context.startActivity(intent)
            }

        }
    }

    override fun getItemCount() = nameList.size

}