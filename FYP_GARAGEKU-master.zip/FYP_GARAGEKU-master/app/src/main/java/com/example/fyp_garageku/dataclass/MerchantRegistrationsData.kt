package com.example.fyp_garageku.dataclass

data class MerchantRegistrationsData(
    val reg_id : Int,
    val workshop_name : String,
    val company_name : String
    )
