package com.example.fyp_garageku.customer

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.example.fyp_garageku.R
import com.example.fyp_garageku.adapters.AppointmentsAdapter
import com.example.fyp_garageku.databinding.DialogReviewBinding
import com.example.fyp_garageku.dataclass.*
import com.squareup.picasso.Picasso
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction
import java.math.BigDecimal

class DialogReviewFragment(val adapter:AppointmentsAdapter): DialogFragment()  {
    private var _binding: DialogReviewBinding? = null
    private val binding get() = _binding!!
    private var position = 0
    private var bookingID = 0
    private var merchantID = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = DialogReviewBinding.inflate(inflater, container, false)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog?.window?.requestFeature(Window.FEATURE_NO_TITLE)

        binding.reviewBtnClose.setOnClickListener {
            dialog?.dismiss()
        }

        if (arguments != null) {
            val args = arguments
            binding.reviewName.text = args?.getString("name")
            binding.reviewService.text = args?.getString("service")
            binding.reviewVehicle.text = args?.getString("vehicle")
            position = args?.getInt("position")!!
            bookingID = args?.getInt("bookingID")!!
            merchantID = args?.getInt("merchantID")!!
            Picasso.get()
                .load("http://test.onmyfinger.com/images/merchant${merchantID}displaypicture.jpg")
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder)
                .into(binding.reviewImgWorkshop)
        }

        binding.reviewBtnSubmit.setOnClickListener{
            btnSubmitOnClick()
        }


        return binding.root
    }

    private fun btnSubmitOnClick(){
        if(binding.reviewRatingBar.rating > 0){
            GlobalScope.launch {
                val isInserted = withContext(Dispatchers.IO){insertToDB()}
                withContext(Dispatchers.Main){
                    if (isInserted){
                        Toast.makeText(requireContext(),"Your review is successfully submitted!",Toast.LENGTH_LONG).show()
                        adapter.onSubmitted(position)
                        dialog?.dismiss()
                    }
                    else{
                        Toast.makeText(requireContext(),"Failed to submit the review! Please try again.",Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        else{
            Toast.makeText(requireContext(),"Failed to submit the review! Please select the rating.",Toast.LENGTH_LONG).show()
        }


    }

    private suspend fun insertToDB():Boolean{
        var isInserted = false
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)
                val id = Reviews.insert {
                    it[review] = binding.reviewTxtReview.text?.trim().toString()
                    it[rating] = binding.reviewRatingBar.rating.toBigDecimal()
                    it[anonymous] = binding.reviewCkbAnonymous.isChecked
                    it[booking_id] = bookingID
                } get Reviews.review_id

                if (id!= 0){
                    val count = Reviews
                        .join(Bookings,JoinType.INNER,null,null){
                            Reviews.booking_id eq Bookings.booking_id
                        }
                        .select(Op.build { Bookings.merchant_id eq merchantID and
                            (Bookings.status eq "Reviewed")}).count().toInt() + 1
                    val merchantRating =
                        Reviews
                            .join(Bookings,JoinType.INNER,null,null){
                                Bookings.booking_id eq Reviews.booking_id
                            }
                            .slice(Reviews.rating.sum())
                        .select(Op.build { Bookings.merchant_id eq merchantID}).first()
                    val rating = merchantRating[Reviews.rating.sum()]

                    var averageRating: BigDecimal = if (count != 0){
                        rating?.div(count.toBigDecimal())!!
                    } else{
                        binding.reviewRatingBar.rating.toBigDecimal()
                    }

                    val updatedMerchant = Merchants.update({Merchants.merchant_id eq merchantID}){
                        it[Merchants.rating] = averageRating!!
                    }

                    val updatedBooking = Bookings.update({ Bookings.booking_id eq bookingID }) {
                        it[status] = "Reviewed"
                    }
                    isInserted = updatedBooking!= 0 && updatedMerchant!= 0
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
        return isInserted
    }
}