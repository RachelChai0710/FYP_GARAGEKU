package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table

object Vehicles : Table() {
    val vehicle_id = integer("vehicle_id").autoIncrement()
    val car_type = varchar("car_type",45)
    val brand = varchar("brand",45)
    val model = varchar("model",100)
    val year = integer("year")
    val car_plate = varchar("car_plate",20)
    val cc = decimal("cc",2,5)

    val cust_id = integer("cust_id")
        .references(Customers.cust_id)
    override val primaryKey = PrimaryKey(vehicle_id)
}