package com.example.fyp_garageku.helper_class

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.fyp_garageku.R
import com.example.fyp_garageku.customer.BookAppointment
import com.example.fyp_garageku.customer.MyAppointments
import com.example.fyp_garageku.dataclass.Bookings
import com.example.fyp_garageku.dataclass.Vehicles
import com.example.fyp_garageku.dataclass.VehiclesData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import javax.xml.transform.ErrorListener

class AlarmReceiver : BroadcastReceiver() {
    private val NOTIFICATION_ID = 0

    override fun onReceive(context: Context?, intent: Intent?) {
        val title = intent!!.getStringExtra("title").toString()
        val content = intent!!.getStringExtra("content").toString()

        val i = Intent(context, MyAppointments::class.java)
        intent!!.flags =
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        val pendingIntent = PendingIntent.getActivity(context, 0, i, 0)

        val builder: NotificationCompat.Builder? = context?.let {
            NotificationCompat.Builder(it, "garagekuBooking")
                .setSmallIcon(R.drawable.ic_baseline_car_repair_24)
                .setContentTitle(title)
                .setContentText(content)
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
        }

        context?.let { NotificationManagerCompat.from(it) }
            ?.notify(NOTIFICATION_ID, builder!!.build())
    }


}

