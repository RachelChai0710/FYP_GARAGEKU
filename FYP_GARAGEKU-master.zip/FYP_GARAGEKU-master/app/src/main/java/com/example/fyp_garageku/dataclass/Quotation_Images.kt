package com.example.fyp_garageku.dataclass

import com.example.fyp_garageku.dataclass.Merchant_Images.autoIncrement
import org.jetbrains.exposed.sql.Table

object Quotation_Images: Table() {
    val img_id = integer("img_id").autoIncrement()
    val quote_id = integer("quote_id")
        .references(Quotations.quote_id)
    override val primaryKey = PrimaryKey(img_id)
}