package com.example.fyp_garageku.helper_class

import android.util.Log

class SendEmail {
    suspend fun sendEmail(senderEmail:String,password:String,recipient:String,message:String,subject: String): Boolean {
        val sender = GmailSender(senderEmail, password)
        try {
            sender.sendMail(subject, message, senderEmail, recipient)
        } catch (ex: Exception) {
            Log.d("Email Sending Exception", ex.toString())
            return false
        }
        return true
    }
}