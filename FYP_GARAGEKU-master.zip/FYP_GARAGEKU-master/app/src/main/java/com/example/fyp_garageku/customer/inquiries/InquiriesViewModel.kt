package com.example.fyp_garageku.customer.inquiries

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class InquiriesViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is Inquires Fragment"
    }
    val text: LiveData<String> = _text
}