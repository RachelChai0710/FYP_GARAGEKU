package com.example.fyp_garageku.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.MerchantBookingsData
import com.example.fyp_garageku.dataclass.Quotations
import com.example.fyp_garageku.merchant.bookings.BookingsReply
import com.example.fyp_garageku.merchant.inquiries.InquiriesReply
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.StdOutSqlLogger
import org.jetbrains.exposed.sql.addLogger
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update

class MerchantBookingsAdapter (private val context: Context,
                                val dataset : ArrayList<MerchantBookingsData>,
                                private val selectedType : String,
                                val fragment : Fragment
) : RecyclerView.Adapter<MerchantBookingsAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val vehicleTextView : TextView = view.findViewById(R.id.vehicle_textview)
        val servicesTextView : TextView = view.findViewById(R.id.services_textview)
        val dateTextView : TextView = view.findViewById(R.id.date_textview)
        val timeTextView : TextView = view.findViewById(R.id.time_textview)
        val custNameTextView : TextView = view.findViewById(R.id.cust_name_textview)
        val dayTextView : TextView = view.findViewById(R.id.day_textview)
        val layout : LinearLayout = view.findViewById(R.id.item_layout)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_merchant_bookings, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        holder.dateTextView.text = item.bookedDate
        holder.vehicleTextView.text = item.vehicleName
        holder.timeTextView.text = item.timeSlot
        holder.custNameTextView.text = item.custName
        holder.dayTextView.text = item.day

        var servicesText = ""
        for (service in item.services){
            servicesText = servicesText + service + "\n"
        }
        servicesText = servicesText.trim()
        holder.servicesTextView.text = servicesText

        holder.layout.setOnClickListener {
            val intent = Intent(context, BookingsReply::class.java)
            intent.putExtra("bookingID", item.bookingID)
            intent.putExtra("services", servicesText)
            intent.putExtra("date", item.date)
            intent.putExtra("day", item.day)
            intent.putExtra("time", item.timeSlot)
            intent.putExtra("vehicle", item.vehicleName)
            intent.putExtra("custName", item.custName)
            intent.putExtra("type", selectedType)
            fragment.startActivityForResult(intent, 12)
        }
    }

    override fun getItemCount() = dataset.size

}