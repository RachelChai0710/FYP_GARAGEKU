package com.example.fyp_garageku.customer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.viewpager2.widget.ViewPager2
import androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback
import com.example.fyp_garageku.R
import com.example.fyp_garageku.adapters.AppointmentFragmentAdapter
import com.example.fyp_garageku.databinding.ActivityBookAppointmentBinding
import com.example.fyp_garageku.databinding.ActivityMyAppointmentsBinding
import com.google.android.material.tabs.TabLayout

class MyAppointments : AppCompatActivity() {
    private lateinit var binding: ActivityMyAppointmentsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMyAppointmentsBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val fm = supportFragmentManager
        val adapter = AppointmentFragmentAdapter(fm, lifecycle)
        binding.appointmentViewPager.adapter = adapter

        binding.appointmentTabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                if (tab != null) {
                    binding.appointmentViewPager.currentItem = tab.position
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
            }
        })

        binding.appointmentViewPager.registerOnPageChangeCallback(object : OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                binding.appointmentTabLayout.selectTab(binding.appointmentTabLayout.getTabAt(position))
            }
        })


    }


}