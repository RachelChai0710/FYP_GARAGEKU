package com.example.fyp_garageku.admin.viewusers

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.Customers
import com.squareup.picasso.Picasso
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction

class ViewCustomers : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_customers)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.title = "View User"

        val id = intent.getIntExtra("id", 0)

        val custImageView = findViewById<ImageView>(R.id.cust_imageview)
        val custNameTextView = findViewById<TextView>(R.id.cust_name_textview)
        val custPhoneTextView = findViewById<TextView>(R.id.cust_phone_textview)
        val genderTextView = findViewById<TextView>(R.id.gender_textview)

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {

                    addLogger(StdOutSqlLogger)
                    //get data from DB
                    val cust = Customers.select { Customers.cust_id eq id }.first()

                    //load data into textview
                    runOnUiThread{
                        Picasso.get()
                            .load(cust[Customers.imageURL])
                            .placeholder(R.drawable.icon_loading)
                            .error(R.drawable.error)
                            .into(custImageView)

                        custNameTextView.text = cust[Customers.cust_name]
                        custPhoneTextView.text = cust[Customers.cust_phone]
                        genderTextView.text = cust[Customers.gender]
                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()

    }
}