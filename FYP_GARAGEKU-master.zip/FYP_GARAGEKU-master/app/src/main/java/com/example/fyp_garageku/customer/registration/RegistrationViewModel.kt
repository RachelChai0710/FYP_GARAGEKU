package com.example.fyp_garageku.customer.registration

import androidx.lifecycle.ViewModel

class RegistrationViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}