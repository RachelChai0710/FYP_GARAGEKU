package com.example.fyp_garageku.adapters

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.*
import com.squareup.picasso.Picasso
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction

class MerchantImageGridAdapter(private val context: Context,
                               private val images: ArrayList<String>,
                               private val imageID: ArrayList<Int>) :
    RecyclerView.Adapter<MerchantImageGridAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imageView : ImageView = view.findViewById(R.id.imageview)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_grid_image, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val path = images[position]

        Picasso.get()
            .load("http://test.onmyfinger.com/images/$path")
            .placeholder(R.drawable.icon_loading)
            .resize(500, 500)
            .centerCrop()
            .into(holder.imageView)

        holder.imageView.setOnClickListener {
            //handle click event on image
            val builder: AlertDialog.Builder = AlertDialog.Builder(context)
            builder.setTitle("Confirm")
            builder.setMessage("Remove this image?")
            builder.setPositiveButton(
                "Yes"
            ) { _, _ ->
                removeImage(imageID[position])
                deleteItem(position)
            }
            builder.setNegativeButton(
                "Cancel"
            ) { dialog, _ ->
                dialog.dismiss()
            }
            builder.show()
        }
    }

    private fun removeImage(imageID : Int){
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    Merchant_Images.deleteWhere { Merchant_Images.image_id eq imageID }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

    override fun getItemCount() = images.size

    private fun deleteItem(position: Int){
        images.removeAt(position)
        imageID.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, images.size)
    }

}