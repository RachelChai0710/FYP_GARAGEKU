package com.example.fyp_garageku.dataclass

data class CallResponse (
    val message: String
)