package com.example.fyp_garageku.merchant.bookings

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.adapters.MerchantBookingsAdapter
import com.example.fyp_garageku.adapters.MerchantInquiriesAdapter
import com.example.fyp_garageku.dataclass.*
import kotlinx.coroutines.selects.select
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.*

class BookingsFragment : Fragment() {

    private lateinit var bookingsViewModel: BookingsViewModel
    private lateinit var selected : String

    private lateinit var pendingTextView : TextView
    private lateinit var approvedTextView : TextView
    private lateinit var rejectedTextView : TextView

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        bookingsViewModel =
                ViewModelProvider(this).get(BookingsViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_merchant_bookings, container, false)

        pendingTextView = root.findViewById(R.id.pending_textview)
        approvedTextView = root.findViewById(R.id.approved_textview)
        rejectedTextView = root.findViewById(R.id.rejected_textview)

        selected = "Placed"

        pendingTextView.setOnClickListener {
            selected = "Placed"
            changeSelection()
            loadData()
        }
        approvedTextView.setOnClickListener {
            selected = "Approved"
            changeSelection()
            loadData()
        }
        rejectedTextView.setOnClickListener {
            selected = "Cancelled"
            changeSelection()
            loadData()
        }

        changeSelection()
        loadData()

        return root
    }

    private fun changeSelection(){
        pendingTextView.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_default))
        approvedTextView.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_default))
        rejectedTextView.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_default))
        pendingTextView.setTypeface(null, Typeface.NORMAL)
        approvedTextView.setTypeface(null, Typeface.NORMAL)
        rejectedTextView.setTypeface(null, Typeface.NORMAL)

        when (selected) {
            "Placed" ->
            {
                pendingTextView.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_selected_blue))
                pendingTextView.setTypeface(null, Typeface.BOLD)
            }
            "Approved" ->
            {
                approvedTextView.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_selected_blue))
                approvedTextView.setTypeface(null, Typeface.BOLD)
            }
            "Cancelled" ->
            {
                rejectedTextView.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_selected_blue))
                rejectedTextView.setTypeface(null, Typeface.BOLD)
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        loadData()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun loadData(){
        val dataset = ArrayList<MerchantBookingsData>()
        val sharedPref = activity?.getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        var userID = 0
        userID = sharedPref?.getString("id","")?.toInt()!!

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {

                    addLogger(StdOutSqlLogger)
                    //get data from DB
                    val joinedTable = Bookings.join(Customers, JoinType.INNER, null, null){
                        (Bookings.cust_id eq Customers.cust_id)
                    }.join(Vehicles, JoinType.INNER, null, null){
                        (Bookings.vehicle_id eq Vehicles.vehicle_id)

                    }.join(Time_Slots, JoinType.INNER, null, null) {
                        (Bookings.slot_id eq Time_Slots.timeslot_id)
                    }

                    var bookings :Query = joinedTable.selectAll()

                    if (selected == "Placed"){
                        bookings = joinedTable.select(
                            Bookings.merchant_id eq userID and (Bookings.status eq selected)
                        ).orderBy(Bookings.date to SortOrder.ASC)
                    } else if (selected == "Approved"){
                        bookings = joinedTable.select(
                            Bookings.merchant_id eq userID and ((Bookings.status eq selected) or (Bookings.status eq "Serviced") or (Bookings.status eq "Reviewed"))
                        ).orderBy(Bookings.date to SortOrder.ASC)
                    }else if (selected == "Cancelled"){
                        bookings = joinedTable.select(
                            Bookings.merchant_id eq userID and (Bookings.status eq selected)
                        ).orderBy(Bookings.date to SortOrder.ASC)
                    }

                    for (row in bookings){
                        val formatter: DateTimeFormatter =
                            DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT)
                                .withLocale(Locale.UK)
                                .withZone(ZoneId.systemDefault())
                        val formattedDate = formatter.format(row[Bookings.date])

                        val serviceList : ArrayList<String> = arrayListOf()
                        val bookingID = row[Bookings.booking_id]

                        //get each service for the specific quotation and add to an arraylist
                        val services = Booking_Services.join(Services, JoinType.INNER, null, null){
                            (Booking_Services.service_id eq Services.service_id)
                        }.select(Booking_Services.booking_id eq bookingID)

                        for (service in services){
                            serviceList.add(service[Services.name])
                        }

                        dataset.add(
                            MerchantBookingsData(
                                row[Bookings.booking_id],
                                row[Bookings.slot_id],
                                row[Bookings.cust_id],
                                formattedDate,
                                row[Bookings.bookedDate],
                                row[Bookings.merchant_id],
                                row[Bookings.vehicle_id],
                                serviceList,
                                row[Vehicles.brand] + " " + row[Vehicles.model] + " " + row[Vehicles.year],
                                row[Time_Slots.start_time] + " - " + row[Time_Slots.end_time],
                                row[Customers.cust_name],
                                row[Time_Slots.day]
                                )
                        )
                    }

                    //load data into textview
                    activity?.runOnUiThread{
                        val bookingsRV = activity?.findViewById<RecyclerView>(R.id.bookings_recyclerView)
                        val adapter = MerchantBookingsAdapter(requireContext(), dataset, selected, this@BookingsFragment )
                        bookingsRV?.layoutManager = LinearLayoutManager(requireContext())
                        bookingsRV?.adapter = adapter

                        bookingsRV?.setHasFixedSize(true)

                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

}