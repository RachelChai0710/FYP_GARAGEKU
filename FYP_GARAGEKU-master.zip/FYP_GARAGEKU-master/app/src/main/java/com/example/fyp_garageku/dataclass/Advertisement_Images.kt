package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table

object Advertisement_Images : Table() {
    val image_id = integer("image_id").autoIncrement()
    val title = varchar("title",45)
}
