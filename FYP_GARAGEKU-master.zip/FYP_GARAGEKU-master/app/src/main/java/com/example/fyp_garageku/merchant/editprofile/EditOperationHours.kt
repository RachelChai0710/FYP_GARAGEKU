package com.example.fyp_garageku.merchant.editprofile

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.*
import com.skydoves.expandablelayout.expandableLayout
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction

class EditOperationHours : AppCompatActivity() {

    private val addList: ArrayList<Int> = ArrayList()
    private val removeList: ArrayList<Int> = ArrayList()
    private var userID = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_operation_hours)

        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Edit Operation Hours"

        val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        userID = sharedPref?.getString("id", "")?.toInt()!!

        loadData()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.confirm_button_menu, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.confirm_button) {
            val builder: AlertDialog.Builder = AlertDialog.Builder(this)
            builder.setTitle("Confirm changes?")
            builder.setPositiveButton("Yes"){ dialog,_ ->
                transactChanges()
                dialog.dismiss()
            }
            builder.setNegativeButton("No"){ dialog,_ ->
                dialog.dismiss()
            }
            builder.show()

        }
        return super.onOptionsItemSelected(item)
    }

    private fun loadData() {
        val hoursLayout = findViewById<LinearLayout>(R.id.hours_layout)
        hoursLayout.removeAllViews()

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    val days: ArrayList<String> = arrayListOf(
                        "Monday",
                        "Tuesday",
                        "Wednesday",
                        "Thursday",
                        "Friday",
                        "Saturday",
                        "Sunday"
                    )

                    val merchantSlotList = arrayListOf<Int>()

                    //get merchant slots
                    val merchantSlots = Merchant_Booking_Slots.select { Merchant_Booking_Slots.merchant_id eq userID }
                    for (row in merchantSlots) {
                        merchantSlotList.add(row[Merchant_Booking_Slots.timeslot_id])
                    }

                    //get all slots
                    for (day in days) {
                        val slots = Time_Slots.select { Time_Slots.day eq day }.toMutableList()
                        runOnUiThread {
                            // create expandable layout
                            val expandableLayout = expandableLayout {
                                setParentLayoutResource(R.layout.item_edit_services_expandable_parent)
                                setSecondLayoutResource(R.layout.item_edit_services_expandable_second)
                                setShowSpinner(true)
                                setSpinnerAnimate(true)
                                setSpinnerMargin(12f)
                                setSpinnerRotation(90)
                                setDuration(100)
                            }

                            //set header text to service category
                            expandableLayout.parentLayout.findViewById<TextView>(R.id.header_textview).text = day
                            expandableLayout.parentLayout.setOnClickListener {
                                if (expandableLayout.isExpanded) {
                                    expandableLayout.collapse()
                                    expandableLayout.secondLayout.visibility = View.INVISIBLE
                                } else {
                                    expandableLayout.secondLayout.visibility = View.VISIBLE
                                    expandableLayout.expand()
                                }
                            }

                            //add child layouts
                            for (slot in slots) {
                                val childView = layoutInflater.inflate(
                                    R.layout.item_checkbox_expandable_child,
                                    null
                                )
                                childView.findViewById<TextView>(R.id.child_textview).text =
                                    slot[Time_Slots.start_time] + " - " + slot[Time_Slots.end_time]

                                val checkbox = childView.findViewById<CheckBox>(R.id.checkbox)
                                if (merchantSlotList.contains(slot[Time_Slots.timeslot_id])) {
                                    checkbox.isChecked = true
                                }
                                //set checkbox listener
                                checkbox.setOnCheckedChangeListener { _, isChecked ->
                                    if (isChecked) {
                                        addSlot(slot[Time_Slots.timeslot_id])
                                    } else {
                                        removeSlot(slot[Time_Slots.timeslot_id])
                                    }
                                }

                                expandableLayout.secondLayout.findViewById<LinearLayout>(R.id.second_layout)
                                    .addView(childView)
                            }

                            //add expandable layout
                            hoursLayout.addView(expandableLayout)
                        }

                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

    private fun addSlot(slotID : Int) {
        if(removeList.contains(slotID)){
            removeList.remove(slotID)
        } else {
            addList.add(slotID)
        }
    }

    private fun removeSlot(slotID : Int) {
        if(addList.contains(slotID)){
            addList.remove(slotID)
        } else {
            removeList.add(slotID)
        }
    }

    private fun transactChanges(){
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    for (slotID in addList){
                        Merchant_Booking_Slots.insert {
                            it[merchant_id] = userID
                            it[timeslot_id] = slotID
                            it[max_cust] = 10
                        }
                    }

                    for (slotID in removeList){
                        Merchant_Booking_Slots.deleteWhere {
                            Merchant_Booking_Slots.merchant_id eq userID and
                                    (Merchant_Booking_Slots.timeslot_id eq slotID)
                        }
                    }

                    setResult(RESULT_OK, intent)
                    finish()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()

    }

}