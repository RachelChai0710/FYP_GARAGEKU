package com.example.fyp_garageku.customer

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.AdapterView
import android.widget.AdapterView.OnItemSelectedListener
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fyp_garageku.adapters.CustHomeAdapter
import com.example.fyp_garageku.adapters.InquiryPhotoAdapter
import com.example.fyp_garageku.adapters.QuoteServiceAdapter
import com.example.fyp_garageku.adapters.TableVehiclesAdapater
import com.example.fyp_garageku.databinding.DialogInquiriesBinding
import com.example.fyp_garageku.dataclass.*
import com.example.fyp_garageku.helper_class.RetrofitInstance
import com.squareup.picasso.Picasso
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.ByteArrayOutputStream


class DialogInquiriesFragment : DialogFragment(),InquiryPhotoAdapter.ReviewPhotoListener  {
    private var _binding: DialogInquiriesBinding? = null
    private val binding get() = _binding!!
    private var serviceList = mutableListOf<ServiceData>()
    private val photoList = ArrayList<Int>()
    private lateinit var tableVehiclesAdapater: TableVehiclesAdapater
    private lateinit var serviceAdapter: QuoteServiceAdapter
    fun setList(list: MutableList<ServiceData>) {
        serviceList = list
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = DialogInquiriesBinding.inflate(inflater, container, false)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog?.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog?.setCancelable(false)
        binding.quoteBtnClose.setOnClickListener {
            if (photoList.size > 1){
                for (item in photoList){
                    deleteImage(item)
                }
            }
            dialog?.dismiss()
        }

        initiaRecycleView()
        initiaRecService()
        photoList.add(0)
        loadRecPhoto()

        binding.quoteBtnSubmit.setOnClickListener{
            GlobalScope.launch {
                val isSubmitted = withContext(Dispatchers.IO){submit()}
                withContext(Dispatchers.Main){
                    if (isSubmitted){
                        Toast.makeText(activity, "Your inquiry is sent to the merchant",Toast.LENGTH_LONG).show()
                        dialog?.dismiss()
                    }
                    else{
                        Toast.makeText(activity, "Failed to send the inquiry! Please try again",Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        return binding.root
    }

    private fun deleteImage(imageID:Int){
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    Quotation_Images.deleteWhere { Quotation_Images.img_id eq imageID }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

    private suspend fun submit():Boolean{
        var isSubmitted = false
        val checkedServiceList = serviceAdapter.getCheckedServiceList()
        if (checkedServiceList.isNotEmpty()){
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)
                    var merchantID = 0
                    val sharedPref = activity?.getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
                    val id = sharedPref?.getString("id", "")?.toInt()
                    if (arguments != null){
                        merchantID = requireArguments().getInt("workshopID")
                    }

                    val vehicleID = tableVehiclesAdapater.getSelectedVehicle().vehicle_id!!.toInt()
                    val quoteID = Quotations.insert {
                        it[desc] = binding.quoteTxtDesc.text.toString()
                        it[cust_id] = (id?.toInt() ?: 0)
                        it[merchant_id] = merchantID
                        it[vehicle_id] = vehicleID
                    } get Quotations.quote_id

                    if (checkedServiceList != null && quoteID != null) {
                        for (item in checkedServiceList){
                            Quotation_Services.insert {
                                it[quote_id] = quoteID
                                it[service_id] = item
                            }
                        }
                    }

                    for (item in photoList){
                        Quotation_Images.update({Quotation_Images.img_id eq item}) {
                            it[quote_id] = quoteID
                        }
                    }

                    isSubmitted = quoteID != null
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        else{
            withContext(Dispatchers.Main){
                Toast.makeText(requireContext(),"Please select at least 1 service",Toast.LENGTH_LONG)
            }
        }
        return isSubmitted
    }

    private fun loadRecPhoto(){
        val layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        val adapter = context?.let { InquiryPhotoAdapter(it, photoList,this) }!!
        binding.recPhoto.layoutManager = layoutManager
        binding.recPhoto.adapter = adapter
        binding.recPhoto.setHasFixedSize(true)
    }

    private fun initiaRecService() {
        val layoutManager = GridLayoutManager(context, 2)
        binding.quoteRecService.layoutManager = layoutManager
        serviceAdapter = context?.let { QuoteServiceAdapter(it, serviceList, ArrayList<Int>(),false) }!!
        binding.quoteRecService.adapter = serviceAdapter
        binding.quoteRecService.setHasFixedSize(true)
    }

    private fun initiaRecycleView() {
        val context = activity
        GlobalScope.launch {
            val list = withContext(Dispatchers.IO) {
                loadVehicles()
            }

            withContext(Dispatchers.Main) {
                val layoutManager = LinearLayoutManager(context)
                binding.quoteRecVehicle.layoutManager = layoutManager
                binding.quoteRecVehicle.addItemDecoration(
                    DividerItemDecoration(
                        binding.quoteRecVehicle.context,
                        layoutManager.orientation
                    )
                )
                tableVehiclesAdapater = context?.let { TableVehiclesAdapater(it, list,false) }!!
                binding.quoteRecVehicle.adapter = tableVehiclesAdapater
                binding.quoteRecVehicle.setHasFixedSize(true)
            }
        }
    }

    private fun loadVehicles(): MutableList<VehiclesData> {
        binding.quoteRecVehicle.removeAllViewsInLayout()
        val vehicleList = mutableListOf<VehiclesData>()

        val sharedPref = activity?.getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        val id = sharedPref?.getString("id", "")?.toInt()

        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                var vehiclesData: VehiclesData
                addLogger(StdOutSqlLogger)

                Vehicles.select(Op.build {
                    Vehicles.cust_id eq (id?.toInt() ?: 0)
                }).map {
                    vehiclesData = VehiclesData(
                        it[Vehicles.vehicle_id],
                        it[Vehicles.car_type],
                        it[Vehicles.brand],
                        it[Vehicles.model],
                        it[Vehicles.cust_id],
                        it[Vehicles.year],
                        it[Vehicles.car_plate],
                        it[Vehicles.cc].toDouble()
                    )
                    vehicleList.add(vehiclesData)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return vehicleList
    }

    private var getPicture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data: Intent? = result.data

            val imgURL  = data?.data

            val previewImageView = ImageView(requireContext())

            val params : ViewGroup.LayoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT )
            previewImageView.layoutParams = params

            Picasso.get()
                .load(imgURL)
                .resize(800,800)
                .centerCrop()
                .into(previewImageView)

            val inputStream = activity?.contentResolver?.openInputStream(imgURL!!)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            val byteArray = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArray)
            val base64img: String =
                Base64.encodeToString(byteArray.toByteArray(), Base64.DEFAULT)

            val builder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
            builder.setTitle("Confirm")
            builder.setMessage("Upload this image?")
            builder.setView(previewImageView)
            builder.setPositiveButton(
                "Yes"
            ) { _, _ ->
                uploadImage(base64img)
            }
            builder.setNegativeButton(
                "Cancel"
            ) { dialog, _ ->
                dialog.dismiss()
            }
            builder.show()
        }
    }

    private fun uploadImage(base64img : String){
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)
                    val list = ArrayList<Int>()
                    for (item in photoList){
                        if (item != 0){
                            list.add(item)
                        }
                    }
                    photoList.clear()

                    val newImageID = Quotation_Images.insert {
                    } get Quotation_Images.img_id

                    val name = "quotation_image_$newImageID.jpg"

                    Log.d("name", name)

                    val call: Call<CallResponse> =
                        RetrofitInstance.api.UploadImage(base64img, name)

                    call.enqueue(object : Callback<CallResponse> {
                        override fun onResponse(
                            call: Call<CallResponse>,
                            response: Response<CallResponse>
                        ) {
                            if (response.isSuccessful) {
                                photoList.add(newImageID)
                                for (item in list){
                                    photoList.add(item)
                                }
                                photoList.add(0)
                                loadRecPhoto()
                            }
                        }
                        override fun onFailure(call: Call<CallResponse>, t: Throwable) {
                            Toast.makeText(
                                requireContext(),
                                t.message,
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    })

                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

    override fun onClickAdd() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"

        getPicture.launch(intent)
    }

}