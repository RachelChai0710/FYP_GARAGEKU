package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table

object UserTypes : Table() {
    val id = integer("id")
        .uniqueIndex()
    val usertype = varchar("usertype", 20)
    override val primaryKey = PrimaryKey(id)
}