package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table

object MerchantEmployees : Table () {
    val id = integer("id")
    val emp_name = varchar("emp_name", 45)
    val phone = varchar("phone", 11)
}
