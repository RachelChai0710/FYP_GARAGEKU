package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table

object Merchant_Registrations : Table() {
    val reg_id = integer("reg_id").autoIncrement()
    val workshop_name = varchar("workshop_name", 45)
    val website = varchar("website", 45)
    val address = varchar("address", 100)
    val company_name = varchar("company_name", 45)
    val company_reg_no = varchar("company_reg_no", 45)
    val sst_id = varchar("sst_id", 15)
    val email_address = varchar("email_address", 45)
    val office_phone = varchar("office_phone", 13)
    val owner_name = varchar("owner_name", 45)
    val owner_phone = varchar("owner_phone", 45)
    val password = char("password",128)
    val bank_name = varchar("bank_name", 45)
    val bank_account_name = varchar("bank_account_name", 45)
    val bank_account_number = varchar("bank_account_number", 45)
    val operation_hours = varchar("operation_hours", 45)
    val approval_status = varchar("approval_status",45)
        .default("Pending")
    val admin_id = integer("admin_id")
        .uniqueIndex()
        .references(Admins.admin_id)
}