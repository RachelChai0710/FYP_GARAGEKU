package com.example.fyp_garageku.merchant.editprofile

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.Merchants
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction

class EditBankingDetails : AppCompatActivity() {

    private lateinit var bankNameTextView: TextView
    private lateinit var accountNameTextView: TextView
    private lateinit var accountNumTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_banking_details)

        supportActionBar?.title = "Edit Banking Details"
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        //view variables
        bankNameTextView = findViewById(R.id.bank_name_textview)
        accountNameTextView = findViewById(R.id.account_name_textview)
        accountNumTextView = findViewById(R.id.account_number_textview)

        loadData()

        //add event listeners
        bankNameTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "Bank Name")
            intent.putExtra("value", bankNameTextView.text)
            startActivityForResult(intent, 2404)
        }
        accountNameTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "Account Name")
            intent.putExtra("value", accountNameTextView.text)
            startActivityForResult(intent, 2404)
        }
        accountNumTextView.setOnClickListener {
            val intent = Intent(this, EditDetail::class.java)
            intent.putExtra("name", "Account Number")
            intent.putExtra("value", accountNumTextView.text)
            startActivityForResult(intent, 2404)
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode  == RESULT_OK && requestCode == 2404) {
            if (data != null){
                val name = data.getStringExtra("name")
                val newValue = data.getStringExtra("newValue")
                when (name) {
                    "Bank Name" ->
                        bankNameTextView.text = newValue
                    "Account Name" ->
                        accountNameTextView.text = newValue
                    "Account Number" ->
                        accountNumTextView.text = newValue
                }
            }
        }
    }

    private fun loadData(){
        val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        var userID = 0
        userID = sharedPref?.getString("id","")?.toInt()!!

        //fetch data from db
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    //get data from DB
                    val merchant = Merchants.select(Op.build { Merchants.user_id eq userID}).first()

                    //load data into textview
                    runOnUiThread{
                        bankNameTextView.text = merchant[Merchants.bank_name]
                        accountNameTextView.text = merchant[Merchants.bank_account_name]
                        accountNumTextView.text = merchant[Merchants.bank_account_number]
                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

}