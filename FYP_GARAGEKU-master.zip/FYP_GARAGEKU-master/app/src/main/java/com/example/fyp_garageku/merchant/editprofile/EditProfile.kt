package com.example.fyp_garageku.merchant.editprofile

import android.app.ActionBar
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Base64
import android.view.ViewGroup
import android.widget.*
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.*
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction
import androidx.activity.result.contract.ActivityResultContracts
import com.canhub.cropper.CropImageContract
import com.canhub.cropper.CropImageView
import com.canhub.cropper.options
import com.example.fyp_garageku.helper_class.RetrofitInstance
import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.ByteArrayOutputStream
import android.graphics.drawable.Drawable
import com.squareup.picasso.Picasso.LoadedFrom


class EditProfile : AppCompatActivity() {

    private lateinit var servicesLayout : LinearLayout

    private lateinit var merchantPictureImageView : ImageView
    private lateinit var editPhotosButton : Button
    private lateinit var editProfilePictureButton : Button

    //workshop detail views
    private lateinit var workshopNameTextViewLarge : TextView
    private lateinit var workshopNameTextView : TextView
    private lateinit var  websiteTextView : TextView
    private lateinit var  emailTextView : TextView
    private lateinit var  workshopAddressTextView : TextView
    private lateinit var officePhoneTextView : TextView
    private lateinit var  operationHoursTextView : TextView
    private lateinit var  companyNameTextView : TextView
    private lateinit var  companyNumTextView : TextView
    private lateinit var sstIDTextView : TextView

    //staff detail views
    private lateinit var  ownerNameTextView : TextView
    private lateinit var  ownerPhoneTextView : TextView
    private lateinit var  managerNameTextView : TextView
    private lateinit var  managerPhoneTextView : TextView

    private lateinit var bankNameTextView : TextView
    private lateinit var accountNameTextView : TextView
    private lateinit var accountNumberTextView : TextView

    override fun onCreate(savedInstansceState: Bundle?) {
        super.onCreate(savedInstansceState)
        setContentView(R.layout.activity_edit_profile)

        supportActionBar?.title = "Edit Profile"
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        loadViews()
        loadData()

        //set onclick events
        findViewById<TextView>(R.id.edit_details_textview).setOnClickListener {
            val intent = Intent(this, EditWorkshopDetails::class.java)
            startActivityForResult(intent, 2404)
        }

        findViewById<TextView>(R.id.edit_services_textview).setOnClickListener {
            val intent = Intent(this, EditServicesDetails::class.java)
            startActivityForResult(intent, 2404)
        }

        findViewById<TextView>(R.id.edit_staff_textview).setOnClickListener {
            val intent = Intent(this, EditStaffDetails::class.java)
            startActivityForResult(intent, 2404)
        }

        findViewById<TextView>(R.id.edit_banking_textview).setOnClickListener {
            val intent = Intent(this, EditBankingDetails::class.java)
            startActivityForResult(intent, 2404)
        }

        editPhotosButton.setOnClickListener {
            val intent = Intent(this, EditMerchantPhotos::class.java)
            startActivity(intent)
        }

        editProfilePictureButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"

            getPicture.launch(intent)
        }

    }

    private fun loadViews(){
        servicesLayout = findViewById(R.id.services_layout)

        merchantPictureImageView = findViewById(R.id.merchant_profile_imageview)
        editPhotosButton = findViewById(R.id.edit_photos_button)
        editProfilePictureButton = findViewById(R.id.edit_profile_picture_button)

        //workshop detail views
        workshopNameTextViewLarge = findViewById(R.id.workshop_name_textview_large)
        workshopNameTextView = findViewById(R.id.workshop_name_textview)
        websiteTextView  = findViewById(R.id.website_textview)
        emailTextView  = findViewById(R.id.email_textview)
        workshopAddressTextView = findViewById(R.id.workshop_address_textview)
        officePhoneTextView  = findViewById(R.id.office_phone_textview)
        operationHoursTextView  = findViewById(R.id.operation_hours_textview)
        companyNameTextView  = findViewById(R.id.company_name_textview)
        companyNumTextView  = findViewById(R.id.company_num_textview)
        sstIDTextView  = findViewById(R.id.sst_id_textview)

        //staff views
        ownerNameTextView = findViewById(R.id.owner_name_textview)
        ownerPhoneTextView  = findViewById(R.id.owner_phone_textview)
        managerNameTextView = findViewById(R.id.manager_name_textview)
        managerPhoneTextView = findViewById(R.id.manager_phone_textview)

        //banking views
        bankNameTextView = findViewById(R.id.bank_name_textview)
        accountNameTextView = findViewById(R.id.account_name_textview)
        accountNumberTextView = findViewById(R.id.account_number_textview)
    }

    //activity for profile picture
    private var getPicture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
            var userID = 0
            userID = sharedPref?.getString("id","")?.toInt()!!

            val data: Intent? = result.data

            val imgURL  = data?.data

            val previewImageView = ImageView(this)

            val params : ViewGroup.LayoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT )
            previewImageView.layoutParams = params

            Picasso.get()
                .load(imgURL)
                .resize(800,800)
                .centerCrop()
                .into(previewImageView)

            val inputStream = contentResolver.openInputStream(imgURL!!)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            val byteArray = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArray)
            val base64img : String = Base64.encodeToString(byteArray.toByteArray(), Base64.DEFAULT)
            val name :String = "merchant" + userID + "displaypicture.jpg"

            val builder: AlertDialog.Builder = AlertDialog.Builder(this)
            builder.setTitle("Confirm")
            builder.setMessage("Set this image as your profile picture?")
            builder.setView(previewImageView)
            builder.setPositiveButton(
                "Yes"
            ) { _, _ ->
                val call : Call<CallResponse> = RetrofitInstance.api.UploadImage(base64img, name)

                call.enqueue(object : Callback<CallResponse> {
                    override fun onResponse(call: Call<CallResponse>, response: Response<CallResponse>) {
                        if (response.isSuccessful){
                            Toast.makeText(applicationContext,  response.body()!!.message, Toast.LENGTH_LONG).show()
                            merchantPictureImageView.setImageBitmap(bitmap)
                        }
                    }

                    override fun onFailure(call: Call<CallResponse>, t: Throwable) {
                        Toast.makeText(applicationContext,  t.message, Toast.LENGTH_LONG).show()
                    }

                })
            }
            builder.setNegativeButton(
                "Cancel"
            ) { dialog, _ ->
                dialog.dismiss()
            }
            builder.show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        loadData()
    }

    private fun loadData(){
        val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        var userID = 0
        userID = sharedPref?.getString("id","")?.toInt()!!

        Picasso.get()
            .load("http://test.onmyfinger.com/images/" + "merchant" + userID + "displaypicture.jpg")
            .placeholder(R.drawable.icon_loading)
            .error(R.drawable.error)
            .into(merchantPictureImageView)

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    //get data from DB
                    val merchant = Merchants.select(Op.build { Merchants.user_id eq userID}).first()

                    //load data into textview
                    runOnUiThread{
                        //workshop details
                        workshopNameTextViewLarge.text = merchant[Merchants.workshop_name]
                        workshopNameTextView.text = merchant[Merchants.workshop_name]
                        websiteTextView.text = merchant[Merchants.website]
                        emailTextView.text = merchant[Merchants.email_address]
                        workshopAddressTextView.text = merchant[Merchants.address]
                        officePhoneTextView.text = merchant[Merchants.office_phone]
                        operationHoursTextView.text = merchant[Merchants.operation_hours]
                        companyNameTextView.text = merchant[Merchants.company_name]
                        companyNumTextView.text = merchant[Merchants.company_reg_no]
                        sstIDTextView.text = merchant[Merchants.sst_id].toString()

                        //staff details
                        ownerNameTextView.text = merchant[Merchants.owner_name]
                        ownerPhoneTextView.text = merchant[Merchants.owner_phone]
                        managerNameTextView.text = merchant[Merchants.manager_name]
                        managerPhoneTextView.text = merchant[Merchants.manager_phone]

                        //banking details
                        bankNameTextView.text = merchant[Merchants.bank_name]
                        accountNameTextView.text = merchant[Merchants.bank_account_name]
                        accountNumberTextView.text = merchant[Merchants.bank_account_number]

                        servicesLayout.removeAllViews()
                    }

                    //get service categories
                    val serviceCategory = Service_Categories.select{Service_Categories.status eq "Available"}

                    for (category in serviceCategory){
                        val catID = category[Service_Categories.cat_id]

                        val services = Merchant_Services.join(Services, JoinType.INNER, null, null){
                            (Merchant_Services.service_id eq Services.service_id)
                        }.select{
                            Services.cat_id eq catID and (Merchant_Services.merchant_id eq userID) and (Services.status eq "Available")
                        }.toMutableList()

                        if (services.isNotEmpty()){
                            runOnUiThread{
                                //header
                                val header = layoutInflater.inflate(R.layout.item_merchant_profile_services_header, null)
                                header.findViewById<TextView>(R.id.header_textview).text = category[Service_Categories.name]
                                servicesLayout.addView(header)

                                //content
                                for (item in services){
                                    val serviceItem = layoutInflater.inflate(R.layout.item_merchant_profile_services, null)
                                    serviceItem.findViewById<TextView>(R.id.item_textview).text = item[Services.name]
                                    servicesLayout.addView(serviceItem)
                                }
                            }
                        }
                    }

                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }
}