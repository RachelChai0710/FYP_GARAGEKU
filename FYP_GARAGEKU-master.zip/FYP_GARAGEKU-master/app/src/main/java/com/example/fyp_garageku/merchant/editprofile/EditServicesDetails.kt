package com.example.fyp_garageku.merchant.editprofile

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.*
import com.skydoves.expandablelayout.expandableLayout
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction

class EditServicesDetails : AppCompatActivity() {

    private val addList : ArrayList<Int> = ArrayList()
    private val removeList : ArrayList<Int> = ArrayList()
    private var userID = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_services_details)

        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Edit Services"

        val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        userID = sharedPref?.getString("id", "")?.toInt()!!

        loadData()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.confirm_button_menu, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.confirm_button) {
            val builder: AlertDialog.Builder = AlertDialog.Builder(this)
            builder.setTitle("Confirm changes?")
            builder.setPositiveButton("Yes"){ dialog,_ ->
                transactChanges()
                dialog.dismiss()
            }
            builder.setNegativeButton("No"){ dialog,_ ->
                dialog.dismiss()
            }
            builder.show()

        }
        return super.onOptionsItemSelected(item)
    }

    private fun loadData() {
        val servicesLayout = findViewById<LinearLayout>(R.id.services_layout)
        servicesLayout.removeAllViews()

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    //get service categories
                    val serviceCategory = Service_Categories.select{Service_Categories.status eq "Available"}

                    for (category in serviceCategory) {
                        val catID = category[Service_Categories.cat_id]

                        val services = Services.join(Merchant_Services, JoinType.LEFT, null, null) {
                            (Merchant_Services.service_id eq Services.service_id)
                        }.select {
                            Services.cat_id eq catID and
                                    ((Merchant_Services.merchant_id eq userID) or (Merchant_Services.merchant_id.isNull())) and
                                    (Services.status eq "Available")
                        }.toMutableList()

                        if (services.isNotEmpty()) {
                            runOnUiThread {
                                // create expandable layout
                                val expandableLayout = expandableLayout {
                                    setParentLayoutResource(R.layout.item_edit_services_expandable_parent)
                                    setSecondLayoutResource(R.layout.item_edit_services_expandable_second)
                                    setShowSpinner(true)
                                    setSpinnerAnimate(true)
                                    setSpinnerMargin(12f)
                                    setSpinnerRotation(90)
                                    setDuration(100)
                                }

                                //set header text to service category
                                expandableLayout.parentLayout.findViewById<TextView>(R.id.header_textview).text =
                                    category[Service_Categories.name]
                                expandableLayout.parentLayout.setOnClickListener {
                                    if (expandableLayout.isExpanded) {
                                        expandableLayout.collapse()
                                        expandableLayout.secondLayout.visibility = View.INVISIBLE
                                    } else {
                                        expandableLayout.secondLayout.visibility = View.VISIBLE
                                        expandableLayout.expand()
                                    }
                                }

                                //add child layouts
                                for (item in services) {
                                    val childView = layoutInflater.inflate(R.layout.item_checkbox_expandable_child, null)
                                    childView.findViewById<TextView>(R.id.child_textview).text = item[Services.name]

                                    val checkbox = childView.findViewById<CheckBox>(R.id.checkbox)
                                    if (item[Merchant_Services.merchant_id] != null) {
                                        checkbox.isChecked = true
                                    }
                                    //set checkbox listener
                                    checkbox.setOnCheckedChangeListener { _, isChecked ->
                                        if (isChecked){
                                            addService(item[Services.service_id])
                                        } else {
                                            removeService(item[Services.service_id])
                                        }
                                    }

                                    expandableLayout.secondLayout.findViewById<LinearLayout>(R.id.second_layout).addView(childView)
                                }

                                //add expandable layout
                                servicesLayout.addView(expandableLayout)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

    private fun addService(serviceID : Int) {
        if(removeList.contains(serviceID)){
            removeList.remove(serviceID)
        } else {
            addList.add(serviceID)
        }
    }

    private fun removeService(serviceID : Int) {
        if(addList.contains(serviceID)){
            addList.remove(serviceID)
        } else {
            removeList.add(serviceID)
        }
    }

    private fun transactChanges(){
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    for (serviceID in addList){
                        Merchant_Services.insert {
                            it[merchant_id] = userID
                            it[service_id] = serviceID
                        }
                    }

                    for (serviceID in removeList){
                        Merchant_Services.deleteWhere {
                            Merchant_Services.merchant_id eq userID and
                                    (Merchant_Services.service_id eq serviceID)
                        }
                    }

                    setResult(RESULT_OK, intent)
                    finish()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()

    }

}