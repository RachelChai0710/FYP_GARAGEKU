package com.example.fyp_garageku.customer

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.fragment.app.DialogFragment
import com.example.fyp_garageku.databinding.DialogFilterBinding

class DialogFilter: DialogFragment()  {
    private var _binding: DialogFilterBinding? = null
    private val binding get() = _binding!!
    private lateinit var listener:FilterDialogListener

    interface FilterDialogListener {
        fun onSelected(type:String,selectedItem:String)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = DialogFilterBinding.inflate(inflater, container, false)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog?.window?.requestFeature(Window.FEATURE_NO_TITLE)
        binding.filterBtnClose.setOnClickListener {
            dialog?.dismiss()
        }

        binding.filterRating.setOnRatingBarChangeListener { p0, p1, p2 ->
            listener.onSelected("rating",p1.toString())
            dialog?.dismiss()
        }
        binding.filterWorkshop.setOnCheckedChangeListener(object : RadioGroup.OnCheckedChangeListener {
            override fun onCheckedChanged(group: RadioGroup?, checkedId: Int) {
                val radio: RadioButton? = dialog?.findViewById(binding.filterWorkshop.checkedRadioButtonId)
                listener.onSelected("alphabet",radio?.text.toString())
                dialog?.dismiss()
            }
        })
        return binding.root
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        // Verify that the host activity implements the callback interface
        try {
            // Instantiate the FilterDialogListener so we can send events to the host
            listener = context as FilterDialogListener
        } catch (e: ClassCastException) {
            // The activity doesn't implement the interface, throw exception
            throw ClassCastException(
                (context.toString() +
                        " must implement FilterDialogListener")
            )
        }
    }
}