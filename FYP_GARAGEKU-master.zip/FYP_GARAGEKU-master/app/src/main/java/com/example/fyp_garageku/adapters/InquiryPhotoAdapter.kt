package com.example.fyp_garageku.adapters

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.Quotation_Images
import com.squareup.picasso.Picasso
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.StdOutSqlLogger
import org.jetbrains.exposed.sql.addLogger
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.transactions.transaction

class InquiryPhotoAdapter(private val context: Context,
                          private val dataset : ArrayList<Int>,
                          private val listener: ReviewPhotoListener
) : RecyclerView.Adapter<InquiryPhotoAdapter.ItemViewHolder>() {

    interface ReviewPhotoListener {
        fun onClickAdd()
    }

    class ItemViewHolder(private val view : View) : RecyclerView.ViewHolder(view) {
        val img : ImageView = view.findViewById(R.id.img_review_photo)
        val placeholder : ImageView = view.findViewById(R.id.img_placeholder)
        val btnDelete : ImageButton = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(context)
            .inflate(R.layout.item_review_photo, parent, false)

        return ItemViewHolder(adapterLayout)
    }
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        if (item == 0){
            Glide.with(context).
            load(R.drawable.icon_addimage)
                .error(R.drawable.icon_loading).into(holder.placeholder)
            holder.btnDelete.visibility = View.GONE
            holder.itemView.setOnClickListener {
                listener.onClickAdd()
            }
        }
        else{
            Picasso.get()
                .load("http://test.onmyfinger.com/images/quotation_image_$item.jpg")
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder)
                .into(holder.img)
            holder.placeholder.visibility = View.GONE

            holder.btnDelete.setOnClickListener{
                //handle click event on image
                val builder: AlertDialog.Builder = AlertDialog.Builder(context)
                builder.setTitle("Confirm")
                builder.setMessage("Remove this image?")
                builder.setPositiveButton(
                    "Yes"
                ) { _, _ ->
                    removeImage(item)
                    deleteItem(position)
                }
                builder.setNegativeButton(
                    "Cancel"
                ) { dialog, _ ->
                    dialog.dismiss()
                }
                builder.show()
            }
        }

    }
    private fun removeImage(imageID : Int){
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    Quotation_Images.deleteWhere { Quotation_Images.img_id eq imageID }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

    private fun deleteItem(position: Int){
        dataset.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, dataset.size)
    }

    override fun getItemCount() = dataset.size


}