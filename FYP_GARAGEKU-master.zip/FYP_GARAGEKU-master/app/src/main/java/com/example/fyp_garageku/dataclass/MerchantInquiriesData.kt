package com.example.fyp_garageku.dataclass

data class MerchantInquiriesData(
    val quoteID : Int,
    val services : ArrayList<String>,
    val customer : String,
    val date : String,
    val vehicle : String,
    val description : String
)
