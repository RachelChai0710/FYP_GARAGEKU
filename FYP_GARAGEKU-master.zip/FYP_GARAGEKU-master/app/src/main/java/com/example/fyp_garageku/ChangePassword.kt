package com.example.fyp_garageku

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import com.example.fyp_garageku.databinding.ActivityChangePasswordBinding
import com.example.fyp_garageku.dataclass.Users
import com.example.fyp_garageku.helper_class.Hash
import com.example.fyp_garageku.helper_class.Validation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction

class ChangePassword : AppCompatActivity() {
    private lateinit var binding:ActivityChangePasswordBinding
    private val validator = Validation()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChangePasswordBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        binding.changePwTxtOldPw.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateOldPassword()
            }
        })
        binding.changePwTxtNewPw.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateNewPassword()
            }
        })
        binding.registrationTxtConfirmPw.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateConfirmPassword()
            }
        })
    }

    fun changePasswordOnClick(view: View){
        binding.changePwProgress.visibility = View.VISIBLE
        val context = this
        if (validateOldPassword() && validateNewPassword() && validateConfirmPassword()) {
            val hash = Hash()
            val hashedNewPW = hash.getSHA512(binding.changePwTxtNewPw.text?.trim().toString())
            val hashedOldPW = hash.getSHA512(binding.changePwTxtOldPw.text?.trim().toString())
            GlobalScope.launch {
                val dbPW = withContext(Dispatchers.IO){loadPW()}
                if (dbPW == hashedOldPW){
                    val isSuccess = withContext(Dispatchers.IO){changeDBPW(hashedNewPW)}
                    if (isSuccess){
                        withContext(Dispatchers.Main){
                            Toast.makeText(context, "Your password is changed",Toast.LENGTH_LONG).show()
                            val intent = Intent(context, Login::class.java)
                            startActivity(intent)
                        }
                    }
                }
                else{
                    withContext(Dispatchers.Main){
                        binding.changePwOldPw.error = getString(R.string.pw_not_same)
                    }
                }
                withContext(Dispatchers.Main){
                    binding.changePwProgress.visibility = View.GONE
                }
            }
        }
    }
    private suspend fun changeDBPW(hashedNewPW: String):Boolean{
        var user = 0
        val email = intent.getStringExtra("email").toString()
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)
                //get data from DB
                user = Users.update({Users.email eq email}) {
                    it[password] = hashedNewPW
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return user != 0
    }

    private suspend fun loadPW():String{
        val email = intent.getStringExtra("email")
        var pw = ""
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)
                //get data from DB
                val user = Users.selectAll().forEach {
                    if (it[Users.email].equals(email)) {
                        pw = it[Users.password]
                    }
                }

            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return pw
    }

    private fun validateOldPassword():Boolean{
        return !validator.isNull(binding.changePwTxtOldPw.text?.trim().toString(),binding.changePwOldPw)
    }

    private fun validateNewPassword():Boolean{
        return !validator.isNull(binding.changePwTxtNewPw.text?.trim().toString(),binding.changePwNewPw) && validator.isPassword(binding.changePwTxtNewPw.text?.trim().toString(),binding.changePwNewPw)
    }

    private fun validateConfirmPassword():Boolean{
        var isMatch = false
        val isNull = validator.isNull(binding.registrationTxtConfirmPw.text?.trim().toString(),binding.changePwConfirmPw)

        if (binding.changePwTxtNewPw.text?.trim().toString() == binding.registrationTxtConfirmPw.text?.trim().toString()){
            isMatch = true
            binding.changePwConfirmPw.error = ""
        }
        else{
            isMatch = false
            binding.changePwConfirmPw.error = getString(R.string.pw_not_same)
        }
        return !isNull && isMatch
    }
}