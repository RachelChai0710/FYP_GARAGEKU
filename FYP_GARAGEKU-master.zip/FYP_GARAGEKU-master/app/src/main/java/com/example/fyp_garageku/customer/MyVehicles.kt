package com.example.fyp_garageku.customer

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.NestedScrollView
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fyp_garageku.adapters.MyVehiclesAdapter
import com.example.fyp_garageku.databinding.ActivityMyVehiclesBinding
import com.example.fyp_garageku.dataclass.Vehicles
import com.example.fyp_garageku.dataclass.VehiclesData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction

class MyVehicles : AppCompatActivity(),DialogVehicleFragment.VehicleDialogListener {
    private lateinit var binding: ActivityMyVehiclesBinding
    private var startIndex:Long = 0
    private lateinit var myAdapter:MyVehiclesAdapter
    private val vehicleList = mutableListOf<VehiclesData>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMyVehiclesBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        initiaRecycleView()

        binding.vehicleNestedScrollView.setOnScrollChangeListener(NestedScrollView.OnScrollChangeListener { v, scrollX, scrollY, oldScrollX, oldScrollY ->
            val view: View = v.getChildAt(v.childCount - 1)
            val diff: Int =
                view.bottom + v.paddingBottom - (v.height + v.scrollY)
            if (diff == 0) {
                startIndex += 10
                binding.vehicleProgress.visibility = View.VISIBLE
                initiaRecycleView()
            }
        })
    }

    fun addNewVehicle(v:View){
        val dialog = DialogVehicleFragment()
        dialog.show(supportFragmentManager,"Add New Vehicle")
    }

    private fun initiaRecycleView() {
        binding.vehicleRecView.removeAllViewsInLayout()
        binding.vehicleProgress.bringToFront()
        binding.vehicleProgress.visibility = View.VISIBLE
        val context = this
        GlobalScope.launch {
            withContext(Dispatchers.IO){
                loadVehicles()}

            withContext(Dispatchers.Main){
                val layoutManager = LinearLayoutManager(context)
                binding.vehicleRecView.layoutManager = layoutManager
                binding.vehicleRecView.addItemDecoration(
                    DividerItemDecoration(
                        binding.vehicleRecView.context,
                        layoutManager.orientation
                    )
                )
                myAdapter = MyVehiclesAdapter(context, vehicleList)
                binding.vehicleRecView.adapter = myAdapter
                binding.vehicleRecView.setHasFixedSize(true)
                binding.vehicleRecView.visibility = View.VISIBLE
                binding.vehicleProgress.visibility = View.GONE
            }
        }
    }

    private fun loadVehicles() {
        val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        val id = sharedPref?.getString("id", "")?.toInt()

        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                var vehiclesData: VehiclesData
                addLogger(StdOutSqlLogger)

                Vehicles.select(Op.build { Vehicles.cust_id eq (id?.toInt() ?: 0) }).limit(10,startIndex).map {
                    vehiclesData = VehiclesData(
                        it[Vehicles.vehicle_id],
                        it[Vehicles.car_type],
                        it[Vehicles.brand],
                        it[Vehicles.model],
                        it[Vehicles.cust_id],
                        it[Vehicles.year],
                        it[Vehicles.car_plate],
                        it[Vehicles.cc].toDouble()
                    )
                    vehicleList.add(vehiclesData)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onUpdated(position:Int) {
        binding.vehicleRecView.visibility = View.INVISIBLE
        vehicleList.clear()
        initiaRecycleView()
    }

    override fun onInserted() {
        vehicleList.clear()
        initiaRecycleView()
    }

}

