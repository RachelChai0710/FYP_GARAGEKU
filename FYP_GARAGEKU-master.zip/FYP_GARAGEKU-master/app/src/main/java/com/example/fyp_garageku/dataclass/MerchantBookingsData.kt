package com.example.fyp_garageku.dataclass

data class MerchantBookingsData(
    val bookingID : Int,
    val slotID : Int,
    val custID : Int,
    val date : String,
    val bookedDate : String,
    val merchantID : Int,
    val vehicleID : Int,
    val services : ArrayList<String>,
    val vehicleName : String,
    val timeSlot : String,
    val custName : String,
    val day : String
)
