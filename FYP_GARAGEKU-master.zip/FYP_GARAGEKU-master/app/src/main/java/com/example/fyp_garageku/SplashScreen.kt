package com.example.fyp_garageku

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.example.fyp_garageku.admin.AdminHomepage
import com.example.fyp_garageku.customer.CustomerHomepage
import com.example.fyp_garageku.merchant.MerchantHomepage

class SplashScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        val sharedPref = getSharedPreferences(
            "GaragekuSP", Context.MODE_PRIVATE)
        val userType = sharedPref?.getString("userType","")
        val email = sharedPref?.getString("email","")
        if (userType!== "" && email!= "") {
            if (userType == "merchant") {
                Handler().postDelayed({
                    val intent = Intent(this, MerchantHomepage::class.java)
                    startActivity(intent)
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    finish()
                }, 2000)

            } else if (userType == "admin") {
                Handler().postDelayed({
                    val intent = Intent(this, AdminHomepage::class.java)
                    startActivity(intent)
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    finish()
                }, 2000)
            } else {
                Handler().postDelayed({
                    val intent = Intent(this, CustomerHomepage::class.java)
                    startActivity(intent)
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    finish()
                }, 2000)
            }

        }
        else {
            Handler().postDelayed({
                val intent = Intent(this, Login::class.java)
                startActivity(intent)
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                finish()
            }, 2000)
        }
    }
}