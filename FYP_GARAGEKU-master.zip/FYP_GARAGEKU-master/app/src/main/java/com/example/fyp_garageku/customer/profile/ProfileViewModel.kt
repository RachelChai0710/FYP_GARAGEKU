package com.example.fyp_garageku.customer.profile


import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ProfileViewModel : ViewModel() {
     val userName = MutableLiveData<String>().apply {
        value = "Username"
    }
    val email = MutableLiveData<String>().apply {
        value = "example@gmail.com"
    }
    val phone = MutableLiveData<String>().apply {
        value = "0123456789"
    }

}