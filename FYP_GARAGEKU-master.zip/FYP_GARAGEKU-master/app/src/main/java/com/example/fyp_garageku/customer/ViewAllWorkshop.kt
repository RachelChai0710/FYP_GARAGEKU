package com.example.fyp_garageku.customer

import android.Manifest
import android.annotation.SuppressLint
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.os.Handler
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.AlphabetIndexer
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.adapters.WorkshopAdapter
import com.example.fyp_garageku.databinding.ActivityViewAllWorkshopBinding
import com.example.fyp_garageku.dataclass.*
import com.example.fyp_garageku.helper_class.GeocodingLocation
import com.google.android.gms.location.*
import com.vmadalin.easypermissions.EasyPermissions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.TransactionManager
import org.jetbrains.exposed.sql.transactions.transaction


class ViewAllWorkshop : AppCompatActivity(), EasyPermissions.PermissionCallbacks,
    DialogFilter.FilterDialogListener {
    companion object {
        private const val PERMISSION_LOCATION_REQUEST_CODE = 1
    }

    private lateinit var binding: ActivityViewAllWorkshopBinding
    private lateinit var searchView: androidx.appcompat.widget.SearchView
    private lateinit var searchManager: SearchManager
    private var query = "Search"
    private var selectedService = ""
    private var selectedState = ""
    private var searchType = ""
    private var filter = ""
    private var startIndex: Long = 0
    private var withLocation = false
    private var isService = false
    private var isState = false
    private var isAlphabet = false
    private var isRating = false
    private var isFirstState = true
    private var isFirstService = true
    private var workshopList = mutableListOf<WorkshopData>()
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    private var currentLocation: Location? = null
    private var state = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityViewAllWorkshopBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        handleIntent(intent)

        setSupportActionBar(binding.viewAllWorkshopsToolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        initiaSpinner()
        val context = this

        //Load next 10 workshops if reached the bottom
        binding.viewAllWorkshopsRecWorkshop.addOnScrollListener(object :
            RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                val layoutManager =
                    LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
                if (layoutManager.findLastVisibleItemPosition() == layoutManager.itemCount - 1) {
                    initiaWorkshopRecycleView(
                        withLocation,
                        true,
                        isService,
                        isState,
                        isAlphabet,
                        isRating
                    )
                }
            }
        })

        binding.searchServicesSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {
                }

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    if (!isFirstService) {
                        isService = true
                        isState = false
                        initiaWorkshopRecycleView(
                            withLocation,
                            false,
                            isService,
                            isState,
                            isAlphabet,
                            isRating
                        )
                    } else
                        isFirstService = false
                }
            }

        binding.searchStateSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {
                }

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    if (!isFirstState) {
                        isState = true
                        isService = false
                        initiaWorkshopRecycleView(
                            withLocation,
                            false,
                            isService,
                            isState,
                            isAlphabet,
                            isRating
                        )
                    } else
                        isFirstState = false
                }
            }
        fusedLocationProviderClient =
            LocationServices.getFusedLocationProviderClient(this)
        if (hasLocationPermission()) {
            checkLocation()
            val delay = 1 * 1000
            val handler = Handler()
            var i = 0
            handler.postDelayed(object : Runnable {
                override fun run() {
                    isService = selectedService != "" || searchType == "service"
                    if (isService || searchType == "search")
                        isState = false
                    if (currentLocation != null || i == 3) { // just remove call backs
                        if (currentLocation != null) {
                            val geocoder = Geocoder(this@ViewAllWorkshop)
                            val geoCurrent = geocoder.getFromLocation(
                                currentLocation!!.latitude,
                                currentLocation!!.longitude,
                                1
                            )
                            val arraySpinner =
                                binding.searchStateSpinner.adapter as ArrayAdapter<String>
                            state = geoCurrent.first().locality
                            binding.searchStateSpinner.setSelection(arraySpinner.getPosition(state))
                            isFirstState = true
                            withLocation = true
                            initiaWorkshopRecycleView(
                                withLocation,
                                false,
                                isService,
                                isState,
                                isAlphabet,
                                isRating
                            )
                        } else {
                            withLocation = false
                            initiaWorkshopRecycleView(
                                withLocation,
                                false,
                                isService,
                                isState,
                                isAlphabet,
                                isRating
                            )
                        }
                        handler.removeCallbacks(this)
                    } else { // post again
                        i++
                        checkLocation()
                        handler.postDelayed(this, delay.toLong())
                    }
                }
            }, delay.toLong())
        } else {
            requestLocationPermission()
        }
    }

    @SuppressLint("MissingPermission")
    override fun onStart() {
        super.onStart()

        val mLocationRequest = LocationRequest.create()
        mLocationRequest.interval = 60000
        mLocationRequest.fastestInterval = 5000
        mLocationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        val mLocationCallback: LocationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                if (locationResult == null) {
                    return
                }
                for (location in locationResult.locations) {
                    if (location != null) {
                        //TODO: UI updates.
                    }
                }
            }
        }
        if (!hasLocationPermission()) {
            requestLocationPermission()
        }
        LocationServices.getFusedLocationProviderClient(this)
            .requestLocationUpdates(mLocationRequest, mLocationCallback, null)
    }

    private fun hasLocationPermission() =
        EasyPermissions.hasPermissions(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) &&
                EasyPermissions.hasPermissions(
                    this,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )

    private fun requestLocationPermission() {
        EasyPermissions.requestPermissions(
            this,
            "The application cannot filter the merchant if location permission is not granted!",
            PERMISSION_LOCATION_REQUEST_CODE,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        EasyPermissions.requestPermissions(
            this,
            "The application cannot filter the merchant if location permission is not granted!",
            PERMISSION_LOCATION_REQUEST_CODE,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this)
    }

    override fun onPermissionsDenied(requestCode: Int, perms: List<String>) {
        withLocation = false
        initiaWorkshopRecycleView(withLocation, false, isService, isState, isAlphabet, isRating)
    }

    override fun onPermissionsGranted(requestCode: Int, perms: List<String>) {
        withLocation = true
        initiaWorkshopRecycleView(withLocation, false, isService, isState, isAlphabet, isRating)
        Toast.makeText(this, "Location Granted!", Toast.LENGTH_LONG).show()
    }

    @SuppressLint("MissingPermission")
    private fun checkLocation() {
        fusedLocationProviderClient.lastLocation.addOnSuccessListener { location: Location? ->
            if (location != null) {
                currentLocation = location
            }
        }
    }

    private fun initiaWorkshopRecycleView(
        withLocation: Boolean,
        isScrollBottom: Boolean,
        isService: Boolean,
        isState: Boolean,
        isAlphabet: Boolean,
        isRating: Boolean
    ) {
        if (!isScrollBottom) {
            workshopList.clear()
        }
        val context = this
        binding.viewAllWorkshopsRecWorkshop.removeAllViewsInLayout()
        binding.viewAllWorkshopProgressBar.visibility = View.VISIBLE
        binding.viewAllWorkshopsRecWorkshop.visibility = View.GONE
        binding.resultNotFoundLayout.visibility = View.GONE
        GlobalScope.launch {
            withContext(Dispatchers.IO) {
                if (withLocation && isService) {
                    loadWorkshopsWithLocationService()
                    if (isAlphabet)
                        loadWorkshopWithAlphabet()
                    else if (isRating)
                        loadWorkshopWithRating()

                } else if (isService) {
                    loadWorkshopsWithService()
                    if (isAlphabet)
                        loadWorkshopWithAlphabet()
                    else if (isRating)
                        loadWorkshopWithRating()
                } else if (isState) {
                    loadWorkshopsWithState(withLocation)
                    if (isAlphabet)
                        loadWorkshopWithAlphabet()
                    else if (isRating)
                        loadWorkshopWithRating()
                } else if (withLocation) {
                    loadWorkshopsWithLocation()
                    if (isAlphabet)
                        loadWorkshopWithAlphabet()
                    else if (isRating)
                        loadWorkshopWithRating()
                } else {
                    loadWorkshops()
                    if (isAlphabet)
                        loadWorkshopWithAlphabet()
                    else if (isRating)
                        loadWorkshopWithRating()
                }
            }

            withContext(Dispatchers.Main) {
                val layoutManager =
                    LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
                binding.viewAllWorkshopsRecWorkshop.layoutManager = layoutManager
                binding.viewAllWorkshopsRecWorkshop.addItemDecoration(
                    DividerItemDecoration(
                        binding.viewAllWorkshopsRecWorkshop.context,
                        layoutManager.orientation
                    )
                )
                if (workshopList.isNotEmpty()) {
                    val myAdapter = WorkshopAdapter(context, workshopList)
                    binding.viewAllWorkshopsRecWorkshop.adapter = myAdapter
                    binding.viewAllWorkshopsRecWorkshop.setHasFixedSize(true)
                    binding.viewAllWorkshopProgressBar.visibility = View.GONE
                    binding.viewAllWorkshopsRecWorkshop.visibility = View.VISIBLE
                    binding.resultNotFoundLayout.visibility = View.GONE
                } else {
                    binding.viewAllWorkshopProgressBar.visibility = View.GONE
                    binding.viewAllWorkshopsRecWorkshop.visibility = View.GONE
                    binding.resultNotFoundLayout.visibility = View.VISIBLE
                }

            }
        }
    }

    private suspend fun loadWorkshopsWithLocation() {
        val context = this
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                var workshop: WorkshopData
                addLogger(StdOutSqlLogger)
                val name = query.toUpperCase()
                Merchants.select(Op.build { Merchants.workshop_name.upperCase() like "$name%" })
                    .limit(10, startIndex)
                    .orderBy(Merchants.rating to SortOrder.DESC).map {
                        val address = it[Merchants.address]
                        val locationAdd =
                            GeocodingLocation().getAddressFromLocation(address, context)
                        val results = FloatArray(3)
                        Location.distanceBetween(
                            currentLocation!!.latitude,
                            currentLocation!!.longitude,
                            locationAdd.latitude,
                            locationAdd.longitude,
                            results
                        )
                        if (results[0] < 5000) { // if <5 km away from current location, add the workshop to display
                            workshop = WorkshopData(
                                it[Merchants.merchant_id],
                                it[Merchants.workshop_name],
                                it[Merchants.address],
                                it[Merchants.email_address],
                                it[Merchants.office_phone],
                                it[Merchants.rating].toFloat()
                            )
                            workshopList.add(workshop)
                        }
                    }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private suspend fun loadWorkshops() {
        try {
            val db = Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                var workshop: WorkshopData
                addLogger(StdOutSqlLogger)

                val name = query.toUpperCase()
                Merchants.select(Op.build { Merchants.workshop_name.upperCase() like "$name%" })
                    .limit(10, startIndex)
                    .orderBy(Merchants.rating to SortOrder.DESC).map {
                        workshop = WorkshopData(
                            it[Merchants.merchant_id],
                            it[Merchants.workshop_name],
                            it[Merchants.address],
                            it[Merchants.email_address],
                            it[Merchants.office_phone],
                            it[Merchants.rating].toFloat()
                        )
                        workshopList.add(workshop)
                    }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private suspend fun loadWorkshopsWithLocationService() {
        val context = this
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                var workshop: WorkshopData
                addLogger(StdOutSqlLogger)
                selectedService = binding.searchServicesSpinner.selectedItem.toString()
                Merchant_Services.join(Services, JoinType.INNER, null, null) {
                    (Merchant_Services.service_id eq Services.service_id)
                }
                    .join(Merchants, JoinType.INNER, null, null) {
                        (Merchant_Services.merchant_id eq Merchants.merchant_id)
                    }
                    .join(Service_Categories, JoinType.INNER, null, null) {
                        (Service_Categories.cat_id eq Services.cat_id)
                    }
                    .select(Op.build { Service_Categories.name eq selectedService })
                    .limit(10, startIndex)
                    .orderBy(Merchants.rating to SortOrder.DESC).withDistinct().map {
                        val address = it[Merchants.address]
                        val locationAdd =
                            GeocodingLocation().getAddressFromLocation(address, context)
                        val results = FloatArray(3)
                        Location.distanceBetween(
                            currentLocation!!.latitude,
                            currentLocation!!.longitude,
                            locationAdd.latitude,
                            locationAdd.longitude,
                            results
                        )
                        if (results[0] < 5000) { // if <5 km away from current location, add the workshop to display
                            workshop = WorkshopData(
                                it[Merchants.merchant_id],
                                it[Merchants.workshop_name],
                                it[Merchants.address],
                                it[Merchants.email_address],
                                it[Merchants.office_phone],
                                it[Merchants.rating].toFloat()
                            )
                            var isSame = false
                            for (merchant in workshopList) {
                                if (merchant.name == workshop.name)
                                    isSame = true
                            }
                            if (!isSame) {
                                workshopList.add(workshop)
                            }
                        }
                    }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private suspend fun loadWorkshopsWithService() {
        val context = this
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                var workshop: WorkshopData
                addLogger(StdOutSqlLogger)
                val selectedService = binding.searchServicesSpinner.selectedItem.toString()
                Merchant_Services.join(Services, JoinType.INNER, null, null) {
                    (Merchant_Services.service_id eq Services.service_id)
                }
                    .join(Merchants, JoinType.INNER, null, null) {
                        (Merchant_Services.merchant_id eq Merchants.merchant_id)
                    }
                    .join(Service_Categories, JoinType.INNER, null, null) {
                        (Service_Categories.cat_id eq Services.cat_id)
                    }
                    .select(Op.build { Service_Categories.name eq selectedService })
                    .limit(10, startIndex)
                    .orderBy(Merchants.rating to SortOrder.DESC).map {
                        workshop = WorkshopData(
                            it[Merchants.merchant_id],
                            it[Merchants.workshop_name],
                            it[Merchants.address],
                            it[Merchants.email_address],
                            it[Merchants.office_phone],
                            it[Merchants.rating].toFloat()
                        )
                        var isSame = false
                        for (merchant in workshopList) {
                            if (merchant.name == workshop.name)
                                isSame = true
                        }
                        if (!isSame) {
                            workshopList.add(workshop)
                        }
                    }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private suspend fun loadWorkshopsWithState(withLocation: Boolean) {
        try {
            val db = Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                var workshop: WorkshopData
                addLogger(StdOutSqlLogger)

                Merchants.selectAll()
                    .limit(10, startIndex)
                    .orderBy(Merchants.rating to SortOrder.DESC).map {
                        val address = it[Merchants.address]
                        val locationAdd =
                            GeocodingLocation().getAddressFromLocation(
                                address,
                                this@ViewAllWorkshop
                            )
                        if (locationAdd.locality == binding.searchStateSpinner.selectedItem.toString()) {
                            if (withLocation){
                                val results = FloatArray(3)
                                Location.distanceBetween(
                                    currentLocation!!.latitude,
                                    currentLocation!!.longitude,
                                    locationAdd.latitude,
                                    locationAdd.longitude,
                                    results
                                )
                                if (results[0] < 5000) { // if <5 km away from current location, add the workshop to display
                                    workshop = WorkshopData(
                                        it[Merchants.merchant_id],
                                        it[Merchants.workshop_name],
                                        it[Merchants.address],
                                        it[Merchants.email_address],
                                        it[Merchants.office_phone],
                                        it[Merchants.rating].toFloat()
                                    )
                                    workshopList.add(workshop)
                                }
                            }
                            else {
                                workshop = WorkshopData(
                                    it[Merchants.merchant_id],
                                    it[Merchants.workshop_name],
                                    it[Merchants.address],
                                    it[Merchants.email_address],
                                    it[Merchants.office_phone],
                                    it[Merchants.rating].toFloat()
                                )
                                workshopList.add(workshop)
                            }
                        }
                    }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private suspend fun loadWorkshopWithAlphabet() {
        when (filter) {
            "A - Z" -> {
                workshopList.sortBy { it.name }
            }
            "Z - A" -> {
                workshopList.sortByDescending { it.name }
            }
        }

    }

    private suspend fun loadWorkshopWithRating() {
        val newList = mutableListOf<WorkshopData>()
        for (item in workshopList) {
            if (item.rating!! >= filter.toFloat()) {
                newList.add(item)
            }
        }

        workshopList = newList.sortedBy { it.rating }.toMutableList()
    }


    @SuppressLint("ResourceType")
    private fun initiaSpinner() {
        val context = this
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter.createFromResource(
            context,
            R.array.states,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            // Apply the adapter to the spinner
            binding.searchStateSpinner.adapter = adapter
            if (selectedState != "") {
                binding.searchStateSpinner.setSelection(adapter.getPosition(selectedState))
                isFirstService = true
            }
        }

        GlobalScope.launch {
            val list = withContext(Dispatchers.IO) { loadServices() }

            withContext(Dispatchers.Main) {
                // Create an ArrayAdapter using the string array and a default spinner layout
                ArrayAdapter(
                    context,
                    android.R.layout.simple_spinner_item,
                    list
                ).also { adapter ->
                    // Specify the layout to use when the list of choices appears
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    // Apply the adapter to the spinner
                    binding.searchServicesSpinner.adapter = adapter
                    if (selectedService != "") {
                        binding.searchServicesSpinner.setSelection(
                            adapter.getPosition(
                                selectedService
                            )
                        )
                        isFirstState = true
                    }
                }

            }
        }
    }

    private suspend fun loadServices(): ArrayList<String> {
        var serviceList = ArrayList<String>()
        try {
            val db = Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)

                Service_Categories.select(Op.build {
                    Service_Categories.status eq "Available"
                }).map {
                    serviceList.add(it[Service_Categories.name])
                }

            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
        return serviceList
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent) {
        if (Intent.ACTION_SEARCH == intent.action) {
            query = intent.getStringExtra(SearchManager.QUERY).toString()
            searchType = "search"
            selectedService = ""

        } else {
            searchType = intent.getStringExtra("type")!!
            selectedService = intent.getStringExtra("service")!!
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.cust_view_all_workshop_menu, menu)
        searchView = menu?.findItem(R.id.search)?.actionView as androidx.appcompat.widget.SearchView
        searchView.setBackgroundColor(Color.WHITE)
        searchView.isIconified = false
        searchView.queryHint = query
        search()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == R.id.location) {
            Toast.makeText(this, "location", Toast.LENGTH_SHORT).show()
        } else {
            search()
        }
        return super.onOptionsItemSelected(item)
    }

    fun filter(v: View) {
        val dialog = DialogFilter()
        dialog.show(supportFragmentManager, "Filter")
    }

    private fun search() {
        searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager

        searchView.apply {
            setSearchableInfo(searchManager.getSearchableInfo(componentName))
            isSubmitButtonEnabled = true
        }
        searchView.setOnQueryTextListener(object :
            androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }

        })
    }

    override fun onSelected(type: String, selectedItem: String) {
        when (type) {
            "alphabet" -> {
                isAlphabet = true
                isRating = false
            }
            "rating" -> {
                isRating = true
                isAlphabet = false
            }
        }
        filter = selectedItem
        initiaWorkshopRecycleView(withLocation, false, isService, isState, isAlphabet, isRating)
    }
}