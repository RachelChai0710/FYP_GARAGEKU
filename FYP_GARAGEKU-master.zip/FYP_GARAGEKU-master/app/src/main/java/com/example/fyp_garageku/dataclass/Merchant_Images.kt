package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table

object Merchant_Images : Table() {
    val image_id = integer("image_id").autoIncrement()
    val merchant_id = integer("merchant_id")
}