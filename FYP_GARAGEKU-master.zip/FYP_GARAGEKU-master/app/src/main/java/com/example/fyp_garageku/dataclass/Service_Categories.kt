package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table

object Service_Categories: Table() {
    val cat_id = integer("cat_id").autoIncrement()
    val name = varchar("name",45)
    val status = varchar("status",45)
    override val primaryKey = PrimaryKey(cat_id)
}