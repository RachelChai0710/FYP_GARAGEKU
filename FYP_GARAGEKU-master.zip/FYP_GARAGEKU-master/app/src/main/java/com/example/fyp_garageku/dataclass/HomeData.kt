package com.example.fyp_garageku.dataclass

data class HomeData(var name:String? = "", val id:Int? =0)
