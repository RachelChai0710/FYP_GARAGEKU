package com.example.fyp_garageku.dataclass

import com.example.fyp_garageku.dataclass.Services.autoIncrement
import org.jetbrains.exposed.sql.Table

object Merchant_Services: Table() {
    val merchant_id = integer("merchant_id")
    val service_id = integer("service_id")
}