package com.example.fyp_garageku.merchant.inquiries

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.adapters.ApproveRegistrationAdapter
import com.example.fyp_garageku.adapters.MerchantInquiriesAdapter
import com.example.fyp_garageku.dataclass.*
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.*
import kotlin.collections.ArrayList

class InquiriesFragment : Fragment() {

    private lateinit var inquiriesViewModel: InquiriesViewModel
    private lateinit var selected : String

    private lateinit var unreadTextView : TextView
    private lateinit var readTextView : TextView
    lateinit var repliedTextView : TextView

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        inquiriesViewModel =
                ViewModelProvider(this).get(InquiriesViewModel::class.java)

        val root = inflater.inflate(R.layout.fragment_merchant_inquiries, container, false)

        unreadTextView = root.findViewById(R.id.unread_textview)
        readTextView = root.findViewById(R.id.read_textview)
        repliedTextView = root.findViewById(R.id.replied_textview)

        selected = "Unread"

        unreadTextView.setOnClickListener {
            selected = "Unread"
            changeSelection()
            loadData()
        }
        readTextView.setOnClickListener {
            selected = "Read"
            changeSelection()
            loadData()
        }
        repliedTextView.setOnClickListener {
            selected = "Replied"
            changeSelection()
            loadData()
        }

        changeSelection()
        loadData()

        return root
    }

    private fun changeSelection(){
        unreadTextView.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_default))
        readTextView.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_default))
        repliedTextView.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_default))
        unreadTextView.setTypeface(null, Typeface.NORMAL)
        readTextView.setTypeface(null, Typeface.NORMAL)
        repliedTextView.setTypeface(null, Typeface.NORMAL)

        when (selected) {
            "Unread" -> {
                unreadTextView.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_selected_blue))
                unreadTextView.setTypeface(null, Typeface.BOLD)
            }
            "Read" ->{
                readTextView.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_selected_blue))
                readTextView.setTypeface(null, Typeface.BOLD)
            }
            "Replied" ->{
                repliedTextView.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_selected_blue))
                repliedTextView.setTypeface(null, Typeface.BOLD)
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        loadData()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun loadData(){
        val dataset = ArrayList<MerchantInquiriesData>()
        val sharedPref = activity?.getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        var userID = 0
        userID = sharedPref?.getString("id","")?.toInt()!!

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {

                    addLogger(StdOutSqlLogger)

                    //get data from DB
                    val quotations = Quotations.join(Vehicles, JoinType.INNER, null, null){
                        (Quotations.vehicle_id eq Vehicles.vehicle_id)
                    }.join(Customers, JoinType.INNER, null, null){
                        (Quotations.cust_id eq Customers.cust_id)
                    }.select(
                        Quotations.merchant_id eq userID and (Quotations.status eq selected)
                    ).orderBy(Quotations.date to SortOrder.DESC)

                    for (row in quotations){
                        val formatter: DateTimeFormatter =
                            DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT)
                                .withLocale(Locale.UK)
                                .withZone(ZoneId.systemDefault())
                        val formattedDate = formatter.format(row[Quotations.date])

                        val serviceList : ArrayList<String> = arrayListOf()
                        val quotationID = row[Quotations.quote_id]

                        //get each service for the specific quotation and add to an arraylist
                        val services = Quotation_Services.join(Services, JoinType.INNER, null, null){
                            (Quotation_Services.service_id eq Services.service_id)
                        }.select(Quotation_Services.quote_id eq quotationID)

                        for (service in services){
                            serviceList.add(service[Services.name])
                        }

                        dataset.add(
                            MerchantInquiriesData(
                                quotationID,
                                serviceList,
                                row[Customers.cust_name],
                                formattedDate,
                                row[Vehicles.brand] + " " + row[Vehicles.model] + " " + row[Vehicles.year],
                                row[Quotations.desc]
                            )
                        )
                    }

                    //load data into textview
                    activity?.runOnUiThread{

                        val inquiriesRV = activity?.findViewById<RecyclerView>(R.id.inquiries_recyclerView)
                        val adapter = MerchantInquiriesAdapter(requireContext(), dataset, selected, this@InquiriesFragment )
                        inquiriesRV?.layoutManager = LinearLayoutManager(requireContext())
                        inquiriesRV?.adapter = adapter

                        inquiriesRV?.setHasFixedSize(true)
                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

}