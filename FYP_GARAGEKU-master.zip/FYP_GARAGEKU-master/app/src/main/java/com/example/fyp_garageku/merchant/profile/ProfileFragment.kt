package com.example.fyp_garageku.merchant.profile

import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.adapters.ReviewsAdapter
import com.example.fyp_garageku.dataclass.*
import com.example.fyp_garageku.merchant.editprofile.EditOperationHours
import com.example.fyp_garageku.merchant.editprofile.EditProfile
import com.squareup.picasso.Picasso
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.*


class ProfileFragment : Fragment() {

    private lateinit var profileViewModel: ProfileViewModel

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        profileViewModel =
            ViewModelProvider(this).get(ProfileViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_merchant_profile, container, false)

        //view variables
        val workshopNameTextView: TextView = root.findViewById(R.id.workshop_name)
        val workshopRatingBar: RatingBar = root.findViewById(R.id.workshop_rating)
        val workshopAddressTextView: TextView = root.findViewById(R.id.workshop_address)
        val workshopEmailTextView: TextView = root.findViewById(R.id.email_textview)
        val workshopPhoneTextView: TextView = root.findViewById(R.id.phone_number_textview)
        val workshopWebsiteTextView: TextView = root.findViewById(R.id.website_textview)
        val workshopOperationHoursTextView: TextView =
            root.findViewById(R.id.operation_hours_textview)
        val merchantPictureImageView: ImageView = root.findViewById(R.id.merchant_imageview)

        val reviewsHeader: TextView = root.findViewById(R.id.reviews_header)
        val reviewsRecyclerView: RecyclerView = root.findViewById(R.id.reviews_recyclerView)

        val servicesLayout: LinearLayout = root.findViewById(R.id.services_layout)

        val sharedPref = activity?.getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        var userID = 0
        userID = sharedPref?.getString("id", "")?.toInt()!!

        Picasso.get()
            .load("http://test.onmyfinger.com/images/" + "merchant" + userID + "displaypicture.jpg")
            .placeholder(R.drawable.icon_loading)
            .error(R.drawable.error)
            .into(merchantPictureImageView)

        //fetch data from db
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )

                transaction {
                    addLogger(StdOutSqlLogger)

                    //get data from DB
                    val merchant =
                        Merchants.select(Op.build { Merchants.user_id eq userID }).first()

                    //load data into textview
                    activity?.runOnUiThread {
                        workshopNameTextView.text = merchant[Merchants.workshop_name]
                        workshopAddressTextView.text = merchant[Merchants.address]
                        workshopEmailTextView.text = merchant[Merchants.email_address]
                        workshopPhoneTextView.text = merchant[Merchants.office_phone]
                        workshopWebsiteTextView.text = merchant[Merchants.website]
                        workshopOperationHoursTextView.text = merchant[Merchants.operation_hours]
                        workshopRatingBar.rating = merchant[Merchants.rating].toFloat()
                        servicesLayout.removeAllViews()
                    }

                    //get service categories
                    val serviceCategory = Service_Categories.select{Service_Categories.status eq "Available"}

                    for (category in serviceCategory) {
                        val catID = category[Service_Categories.cat_id]

                        val services =
                            Merchant_Services.join(Services, JoinType.INNER, null, null) {
                                (Merchant_Services.service_id eq Services.service_id)
                            }.select {
                                Services.cat_id eq catID and (Merchant_Services.merchant_id eq userID) and (Services.status eq "Available")
                            }.toMutableList()

                        if (services.isNotEmpty()) {
                            activity?.runOnUiThread {
                                //header
                                val header = layoutInflater.inflate(
                                    R.layout.item_merchant_profile_services_header,
                                    null
                                )
                                header.findViewById<TextView>(R.id.header_textview).text =
                                    category[Service_Categories.name]
                                servicesLayout.addView(header)

                                //content
                                for (item in services) {
                                    val serviceItem = layoutInflater.inflate(
                                        R.layout.item_merchant_profile_services,
                                        null
                                    )
                                    serviceItem.findViewById<TextView>(R.id.item_textview).text =
                                        item[Services.name]
                                    servicesLayout.addView(serviceItem)
                                }
                            }
                        }
                    }

                    //load reviews
                    val list = mutableListOf<ReviewData>()
                    val count = Reviews.join(Bookings, JoinType.INNER, null, null) {
                        Reviews.booking_id eq Bookings.booking_id
                    }.select(Op.build { Bookings.merchant_id eq userID }).count()

                    Reviews.join(Bookings, JoinType.INNER, null, null) {
                        Reviews.booking_id eq Bookings.booking_id
                    }
                        .join(Customers, JoinType.INNER, null, null) {
                            (Bookings.cust_id eq Customers.cust_id)
                        }
                        .select(Op.build { Bookings.merchant_id eq userID })
                        .limit(3)
                        .orderBy(Reviews.review_date, SortOrder.DESC).map{
                            val formatter: DateTimeFormatter =
                                DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT)
                                    .withLocale(Locale.UK)
                                    .withZone(ZoneId.systemDefault())
                            val formattedDate = formatter.format(it[Reviews.review_date])

                            val serviceList = Booking_Services.join(Services,JoinType.INNER, null, null) {
                                (Booking_Services.service_id eq Services.service_id)
                            }
                                .select(Op.build { Booking_Services.booking_id eq it[Bookings.booking_id] }).toMutableList()
                            var service = ""
                            for (item in serviceList){
                                service += if (item[Services.name] == serviceList.last()[Services.name]){
                                    "${item[Services.name]}"
                                } else
                                    "${item[Services.name]} \n"
                            }

                            list.add(
                                ReviewData(
                                    it[Customers.cust_name],
                                    it[Reviews.review],
                                    it[Customers.imageURL],
                                    formattedDate,
                                    it[Reviews.anonymous],
                                    it[Reviews.rating].toFloat(),
                                    service
                                )
                            )
                        }

                    GlobalScope.launch {
                        withContext(Dispatchers.Main) {
                            reviewsHeader.text = "Reviews ($count)"
                            if (list.isNotEmpty()) {
                                val layoutManager =
                                    LinearLayoutManager(
                                        this@ProfileFragment.context,
                                        LinearLayoutManager.VERTICAL,
                                        false
                                    )
                                reviewsRecyclerView.layoutManager = layoutManager
                                reviewsRecyclerView.addItemDecoration(
                                    DividerItemDecoration(
                                        reviewsRecyclerView.context,
                                        layoutManager.orientation
                                    )
                                )
                                val myAdapter = ReviewsAdapter(requireContext(), list)
                                reviewsRecyclerView.adapter = myAdapter
                                reviewsRecyclerView.setHasFixedSize(true)
                                reviewsRecyclerView.isEnabled = true
                            } else {
                                reviewsRecyclerView.isEnabled = false
                                reviewsRecyclerView.visibility = View.GONE
                            }
                        }
                    }

                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()

        root.findViewById<Button>(R.id.edit_profile_button).setOnClickListener {
            val intent = Intent(this.context, EditProfile::class.java)
            startActivity(intent)
        }

        root.findViewById<TextView>(R.id.edit_details_textview).setOnClickListener {
            val intent = Intent(this.context, EditProfile::class.java)
            startActivity(intent)
        }

        root.findViewById<TextView>(R.id.edit_services_textview).setOnClickListener {
            val intent = Intent(this.context, EditProfile::class.java)
            startActivity(intent)
        }

        root.findViewById<TextView>(R.id.edit_operation_hours_textview).setOnClickListener {
            val intent = Intent(this.context, EditOperationHours::class.java)
            startActivity(intent)
        }

        root.findViewById<TextView>(R.id.view_reviews_textview).setOnClickListener {
            val intent = Intent(this.context, MerchantReviews::class.java)
            intent.putExtra("workshopID", userID)
            startActivity(intent)
        }


        return root
    }

}