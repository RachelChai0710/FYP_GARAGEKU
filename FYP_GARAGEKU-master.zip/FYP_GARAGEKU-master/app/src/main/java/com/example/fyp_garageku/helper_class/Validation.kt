package com.example.fyp_garageku.helper_class

import com.google.android.material.textfield.TextInputLayout

class Validation {
    fun isNull(other:String, textInputLayout: TextInputLayout):Boolean{
        if (other.isNullOrBlank()){
            textInputLayout.error = "*Required"
        }
        else
            textInputLayout.error = ""
        return other.isNullOrBlank()
    }

    fun isPhone(other:String,textInputLayout: TextInputLayout):Boolean{
        if (!other.matches("^01[0|1|2|3|4|6|7|8|9]*[0-9]{7,8}\$".toRegex())){
            textInputLayout.error = "Enter in 0123456789 format"
        }else
            textInputLayout.error = ""
        return other.matches("^01[0|1|2|3|4|6|7|8|9]*[0-9]{7,8}\$".toRegex())
    }

    fun isLetter(other:String,textInputLayout: TextInputLayout):Boolean{
        if (!other.matches("^[ A-Za-z]+\$".toRegex())){
            textInputLayout.error = "Please enter only alphabet"
        }else
            textInputLayout.error = ""
        return other.matches("^[ A-Za-z]+\$".toRegex())
    }

    fun isPassword(other:String,textInputLayout: TextInputLayout):Boolean{
        if (!other.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#\$%!\\-_?&])(?=\\S+\$).{8,}".toRegex())){
            textInputLayout.error = "Your password must be at least 8 characters long, contain at least one number, special character " +
                    "and have a mixture of uppercase and lowercase letters."
        }else
            textInputLayout.error = ""
        return other.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#\$%!\\-_?&])(?=\\S+\$).{8,}".toRegex())
    }
}