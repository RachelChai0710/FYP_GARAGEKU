package com.example.fyp_garageku.dataclass

import java.sql.Timestamp

data class CustInquiriesData(
    var quoteID:Int? = 0,
    var merchantID:Int? = 0,
    var name:String? = "",
    var time:String? = "",
    var service:String? = "",
    var status:String? = "")
