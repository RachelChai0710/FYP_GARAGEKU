package com.example.fyp_garageku.merchant.editprofile

import android.content.Context
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.WindowManager
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.MerchantEmployees
import com.example.fyp_garageku.dataclass.Merchants
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction

class EditDetail : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_detail)

        val name = intent.getStringExtra("name")
        val value = intent.getStringExtra("value")

        supportActionBar?.title = name
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val detailEditText = findViewById<EditText>(R.id.detail_textview)

        detailEditText.setText(value)
        if(detailEditText.requestFocus()) {
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.confirm_button_menu, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val detailTextView = findViewById<TextView>(R.id.detail_textview)
        val name = intent.getStringExtra("name")
        val value = intent.getStringExtra("value")
        val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        var userID : Int
        val newValue = detailTextView.text.toString()
        userID = sharedPref?.getString("id", "")?.toInt()!!

        if (item.itemId == R.id.confirm_button) {
            if (value != newValue) {
                //update database
                val thread = Thread {
                    try {
                        Database.connect(
                            "jdbc:mysql://110.4.46.121/carportal",
                            "com.mysql.jdbc.Driver",
                            "fyp", "fyp2020"
                        )
                        transaction {
                            addLogger(StdOutSqlLogger)
                            val merchant =
                                Merchants.select(Op.build { Merchants.user_id eq userID }).first()

                            when (name) {
                                "Workshop Name" ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[workshop_name] = newValue
                                    }
                                "Website" ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[website] = newValue
                                    }
                                "Email" ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[email_address] = newValue
                                    }
                                "Workshop Address" ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[address] = newValue
                                    }
                                "Office Phone" ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[office_phone] = newValue
                                    }
                                "Operation Hours" ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[operation_hours] = newValue
                                    }
                                "Registered Company Name" ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[company_name] = newValue
                                    }
                                "Company Registration No." ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[company_reg_no] = newValue
                                    }
                                "SST ID" ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[sst_id] = newValue
                                    }
                                "Owner Name" ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[owner_name] = newValue
                                    }
                                "Owner Phone" ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[owner_phone] = newValue
                                    }
                                "Manager Name" ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[manager_name] = newValue
                                    }
                                "Manager Phone" ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[manager_phone] = newValue
                                    }
                                "Bank Name" ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[bank_name] = newValue
                                    }
                                "Account Name" ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[bank_account_name] = newValue
                                    }
                                "Account Number" ->
                                    Merchants.update({ Merchants.user_id eq userID }) {
                                        it[bank_account_number] = newValue
                                    }
                                else ->
                                    return@transaction
                            }

                        }
                        intent.putExtra("name", name)
                        intent.putExtra("newValue", newValue)
                        setResult(RESULT_OK, intent)
                        runOnUiThread {
                            Toast.makeText(applicationContext, "Edit successful!", Toast.LENGTH_SHORT).show()
                        }
                        finish()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                thread.start()
            } else {
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}

