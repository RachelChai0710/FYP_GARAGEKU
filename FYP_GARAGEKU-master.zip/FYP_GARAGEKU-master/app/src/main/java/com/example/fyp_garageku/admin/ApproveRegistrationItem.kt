package com.example.fyp_garageku.admin

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.Merchant_Registrations
import com.example.fyp_garageku.dataclass.Merchants
import com.example.fyp_garageku.dataclass.Users
import com.example.fyp_garageku.helper_class.SendEmail
import kotlinx.coroutines.*
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction

class ApproveRegistrationItem : AppCompatActivity() {

    private lateinit var workshopNameTextView: TextView
    private lateinit var companyNameTextView: TextView
    private lateinit var companyRegNumTextView: TextView
    private lateinit var sstIDTextView: TextView
    private lateinit var addressTextView: TextView
    private lateinit var websiteTextView: TextView
    private lateinit var emailTextView: TextView
    private var regID: Int = 0
    private lateinit var registration : ResultRow
    private var userID : Int = 0

    private var invalidEmail = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_approve_registration_item)

        val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        userID = sharedPref?.getString("id", "")?.toInt()!!

        supportActionBar?.title = "Approve Registration"
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        workshopNameTextView = findViewById(R.id.workshop_name_textview)
        companyNameTextView = findViewById(R.id.company_name_textview)
        companyRegNumTextView = findViewById(R.id.company_num_textview)
        sstIDTextView = findViewById(R.id.sst_id_textview)
        addressTextView = findViewById(R.id.address_textview)
        websiteTextView = findViewById(R.id.website_textview)
        emailTextView = findViewById(R.id.email_textview)

        regID = intent.extras?.getInt("id")!!

        //fetch data from db
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    //get data from DB
                    registration =
                        Merchant_Registrations.select(Op.build { Merchant_Registrations.reg_id eq regID })
                            .first()

                    //check if duplicate email
                    val count =
                    Users.select(Op.build {
                            Users.email eq registration[Merchant_Registrations.email_address] }).count()

                    invalidEmail = count != 0L

                    //load data
                    runOnUiThread {
                        workshopNameTextView.text =
                            registration[Merchant_Registrations.workshop_name]
                        companyNameTextView.text = registration[Merchant_Registrations.company_name]
                        companyRegNumTextView.text =
                            registration[Merchant_Registrations.company_reg_no]
                        sstIDTextView.text = registration[Merchant_Registrations.sst_id]
                        addressTextView.text = registration[Merchant_Registrations.address]
                        websiteTextView.text = registration[Merchant_Registrations.website]
                        emailTextView.text = registration[Merchant_Registrations.email_address]

                        if (invalidEmail) {
                            emailTextView.setBackgroundColor(resources.getColor(R.color.bright_red))
                        }
                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.confirm_deny_button_menu, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.confirm_button -> {
                if (invalidEmail){
                    Toast.makeText(applicationContext,
                        "Error : This email already exists.", Toast.LENGTH_SHORT).show()
                } else {
                    showApproveAlertDialog()
                }
                return true
            }
            R.id.reject_button -> {
                showDenyAlertDialog()
                return true
            }
        }

        return super.onOptionsItemSelected(item)
    }

    private fun showApproveAlertDialog() {
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle("Confirm approval?")
        builder.setPositiveButton(
            "Yes"
        ) { dialog, _ ->
            // update database
            val thread = Thread {
                try {
                    Database.connect(
                        "jdbc:mysql://110.4.46.121/carportal",
                        "com.mysql.jdbc.Driver",
                        "fyp", "fyp2020"
                    )
                    transaction {
                        addLogger(StdOutSqlLogger)
                        //update status to complete
                        Merchant_Registrations.update({Merchant_Registrations.reg_id eq regID } )
                        {
                            it[approval_status] = "Approved"
                            it[admin_id] = userID
                        }

                        //add user to db
                        Users.insert {
                            it[email] = registration[Merchant_Registrations.email_address]
                            it[password] = registration[Merchant_Registrations.password]
                            it[user_type_id] = 1
                        }

                        //check user id
                        val user =
                            Users.select(Op.build { Users.email eq registration[Merchant_Registrations.email_address] })
                                .first()

                        //add user to db
                        Merchants.insert {
                            it[workshop_name] = registration[Merchant_Registrations.workshop_name]
                            it[website] = registration[Merchant_Registrations.website]
                            it[address] = registration[Merchant_Registrations.address]
                            it[company_name] = registration[Merchant_Registrations.company_name]
                            it[company_reg_no] = registration[Merchant_Registrations.company_reg_no]
                            it[sst_id] = registration[Merchant_Registrations.sst_id]
                            it[owner_name] = registration[Merchant_Registrations.owner_name]
                            it[owner_phone] = registration[Merchant_Registrations.owner_phone]
                            it[manager_name] = registration[Merchant_Registrations.owner_name]
                            it[manager_phone] = registration[Merchant_Registrations.owner_phone]
                            it[email_address] = registration[Merchant_Registrations.email_address]
                            it[office_phone] = registration[Merchant_Registrations.office_phone]
                            it[bank_name] = registration[Merchant_Registrations.bank_name]
                            it[bank_account_name] = registration[Merchant_Registrations.bank_account_name]
                            it[bank_account_number] = registration[Merchant_Registrations.bank_account_number]
                            it[operation_hours] = registration[Merchant_Registrations.operation_hours]
                            it[user_id] = user[Users.id]
                        }

                        //send email
                        val sender = SendEmail()

                        GlobalScope.launch() {
                            val isSent = withContext(Dispatchers.IO) {
                                sender.sendEmail(
                                    resources.getString(R.string.official_email),
                                    resources.getString(R.string.email_pw),
                                    registration[Merchant_Registrations.email_address],
                                    resources.getString(R.string.email_approve_registration_body) +
                                            resources.getString(R.string.email_closing),
                                    resources.getString(R.string.email_approve_registration_subject),
                                )
                            }
                        }

                    }
                    dialog.dismiss()
                    setResult(RESULT_OK, intent)
                    finish()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            thread.start()
            Toast.makeText(applicationContext,
                "Registration approved!", Toast.LENGTH_SHORT).show()
        }
        builder.setNegativeButton(
            "Cancel"
        ) { dialog, _ ->
            dialog.dismiss()
        }

        builder.show()
    }

    private fun showDenyAlertDialog() {
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle("Reason for rejection")
        val input = EditText(this)
        input.hint = "Reason"
        input.inputType = InputType.TYPE_CLASS_TEXT
        builder.setView(input)
        builder.setPositiveButton(
            "Reject"
        ) { dialog, _ ->
            // update database
            val thread = Thread {
                try {
                    Database.connect(
                        "jdbc:mysql://110.4.46.121/carportal",
                        "com.mysql.jdbc.Driver",
                        "fyp", "fyp2020"
                    )
                    transaction {
                        addLogger(StdOutSqlLogger)
                        //update status to denied
                        Merchant_Registrations.update({Merchant_Registrations.reg_id eq regID } )
                        {
                            it[approval_status] = "Denied"
                            it[admin_id] = userID
                        }


                        //send email
                        val sender = SendEmail()

                        GlobalScope.launch() {
                            val isSent = withContext(Dispatchers.IO) {
                                sender.sendEmail(
                                    resources.getString(R.string.official_email),
                                    resources.getString(R.string.email_pw),
                                    registration[Merchant_Registrations.email_address],
                                    resources.getString(R.string.email_reject_registration_body) +
                                            input.text.toString() +
                                            resources.getString(R.string.email_closing),
                                    resources.getString(R.string.email_reject_registration_subject),
                                )
                            }
                        }

                    }
                    dialog.dismiss()
                    setResult(RESULT_OK, intent)
                    finish()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            thread.start()
            Toast.makeText(applicationContext,
                "Registration denied!", Toast.LENGTH_SHORT).show()
        }
        builder.setNegativeButton(
            "Cancel"
        ) { dialog, _ ->
            dialog.dismiss()
        }

        builder.show()
    }
}