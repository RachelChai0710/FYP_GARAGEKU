package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.`java-time`.timestamp

object Replies:Table() {
    val reply_id = integer("reply_id").autoIncrement()
    val reply = varchar("reply", 200)
    val reply_date = timestamp("reply_date")
    val status = varchar("status",45)
    val quote_id = integer("quote_id").uniqueIndex()
        .references(Quotations.quote_id)

    override val primaryKey = PrimaryKey(reply_id)
}