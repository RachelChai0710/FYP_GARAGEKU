package com.example.fyp_garageku.adapters

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.customer.DialogVehicleFragment
import com.example.fyp_garageku.dataclass.VehiclesData

class MyVehiclesAdapter (private val context: Context,
                         private val dataset : List<VehiclesData>
) :RecyclerView.Adapter<MyVehiclesAdapter.ItemViewHolder>() {

    class ItemViewHolder(private val view : View) :RecyclerView.ViewHolder(view) {
        val txtBrand : TextView = view.findViewById(R.id.vehicle_brand)
        val txtModel : TextView = view.findViewById(R.id.vehicle_model)
        val img:ImageView = view.findViewById(R.id.vehicle_img)
        val txtYear : TextView = view.findViewById(R.id.vehicle_year)
        val txtCarPlate : TextView = view.findViewById(R.id.vehicle_carplate)
        val btnEdit:ImageButton = view.findViewById(R.id.vehicle_btnEdit)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(context)
            .inflate(R.layout.item_vehicles, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        holder.txtCarPlate.text = item.carPlate
        holder.txtBrand.text = item.brand
        holder.txtModel.text = item.model
        holder.txtYear.text = " (${item.year})"
        when (item.car_type) {
            "Car" ->{
                holder.img.setImageResource(R.drawable.icons8_car_48)
            }
            "Motorcycle" -> {
                holder.img.setImageResource(R.drawable.icons8_motorcycle_48)
            }
            "Van" -> {
                holder.img.setImageResource(R.drawable.icons8_van_48)
            }
            "Truck" -> {
                holder.img.setImageResource(R.drawable.icons8_articulated_lorry_48)
            }
        }

        holder.btnEdit.setOnClickListener(){
            val arg = Bundle()
            item.vehicle_id?.let { it1 -> arg.putInt("id", it1) }
            arg.putString("carPlate",item.carPlate)
            arg.putString("carType",item.car_type)
            arg.putString("brand",item.brand)
            arg.putString("model",item.model)
            arg.putInt("position",position)
            item.year?.let { it1 -> arg.putInt("year", it1) }
            item.cc?.let { it1 -> arg.putDouble("cc", it1) }
            arg.putString("action","edit")
            callDialog(arg)
        }

        holder.itemView.setOnClickListener{
            val arg = Bundle()
            item.vehicle_id?.let { it1 -> arg.putInt("id", it1) }
            arg.putString("carPlate",item.carPlate)
            arg.putString("carType",item.car_type)
            arg.putString("brand",item.brand)
            arg.putString("model",item.model)
            item.year?.let { it1 -> arg.putInt("year", it1) }
            item.cc?.let { it1 -> arg.putDouble("cc", it1) }
            arg.putString("action","details")
            callDialog(arg)
        }
    }

    private fun callDialog(arg:Bundle){
        val dialog = DialogVehicleFragment()
        dialog.arguments = arg
        val ft = (context as AppCompatActivity).supportFragmentManager.beginTransaction()
        dialog.show(ft,"Vehicle details")
    }

    override fun getItemCount() = dataset.size


}