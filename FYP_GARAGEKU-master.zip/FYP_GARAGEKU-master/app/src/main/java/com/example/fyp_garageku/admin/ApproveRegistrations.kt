package com.example.fyp_garageku.admin

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.adapters.ApproveRegistrationAdapter
import com.example.fyp_garageku.dataclass.MerchantRegistrationsData
import com.example.fyp_garageku.dataclass.Merchant_Registrations
import com.example.fyp_garageku.dataclass.Merchants
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction

class ApproveRegistrations : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_approve_registrations)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.title = "Approve Registrations"

        loadData(this)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        loadData(this)
    }

    private fun loadData(context : Context){
        //fetch data from db
        val dataset = ArrayList<MerchantRegistrationsData>()

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    //get data from DB
                    val registrations = Merchant_Registrations.select(
                        Op.build { Merchant_Registrations.approval_status eq "Pending"})

                    for (row in registrations){
                        //add to dataset
                        val regID = row[Merchant_Registrations.reg_id]
                        val workshopName = row[Merchant_Registrations.workshop_name]
                        val companyName = row[Merchant_Registrations.company_name]
                        dataset.add(
                            MerchantRegistrationsData(
                            regID,
                            workshopName,
                            companyName,
                        )
                        )
                    }

                    //load data into textview
                    runOnUiThread{
                        val approveRegistrationsRV = findViewById<RecyclerView>(R.id.approve_registrations_recyclerview)

                        approveRegistrationsRV.adapter = ApproveRegistrationAdapter(context, dataset, supportFragmentManager)
                        approveRegistrationsRV.setHasFixedSize(true)
                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }
}