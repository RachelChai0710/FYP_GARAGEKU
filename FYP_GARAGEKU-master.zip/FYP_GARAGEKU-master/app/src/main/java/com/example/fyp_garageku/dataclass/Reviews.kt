package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.`java-time`.timestamp

object Reviews : Table() {
    val review_id = integer("review_id").autoIncrement()
    val review = text("review")
    val rating = decimal("rating",2,3)
    val anonymous = bool("anonymous")
    val review_date = timestamp("review_date")
    val booking_id = integer("booking_id").uniqueIndex()
        .references(Bookings.booking_id)

    override val primaryKey = PrimaryKey(review_id)
}