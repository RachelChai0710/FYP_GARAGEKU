package com.example.fyp_garageku.admin.viewusers

import android.content.Context
import android.graphics.Typeface
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.adapters.MerchantBookingsAdapter
import com.example.fyp_garageku.adapters.ViewUsersAdapter
import com.example.fyp_garageku.dataclass.*
import kotlinx.coroutines.selects.select
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.*
import kotlin.collections.ArrayList

class ViewUsers : AppCompatActivity() {

    private lateinit var selected : String

    private lateinit var customersTextView: TextView
    private lateinit var merchantsTextView : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_users)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.title = "View Users"

        customersTextView = findViewById(R.id.customers_textview)
        merchantsTextView = findViewById(R.id.merchants_textview)

        selected = "Customers"

        customersTextView.setOnClickListener {
            selected = "Customers"
            changeSelection()
            loadData()
        }
        merchantsTextView.setOnClickListener {
            selected = "Merchants"
            changeSelection()
            loadData()
        }

        changeSelection()
        loadData()
    }

    private fun changeSelection(){
        customersTextView.setTextColor(ContextCompat.getColor(this, R.color.text_default))
        merchantsTextView.setTextColor(ContextCompat.getColor(this, R.color.text_default))
        customersTextView.setTypeface(null, Typeface.NORMAL)
        merchantsTextView.setTypeface(null, Typeface.NORMAL)

        when (selected) {
            "Customers" ->
            {
                customersTextView.setTextColor(ContextCompat.getColor(this, R.color.text_selected_blue))
                customersTextView.setTypeface(null, Typeface.BOLD)
            }
            "Merchants" ->
            {
                merchantsTextView.setTextColor(ContextCompat.getColor(this, R.color.text_selected_blue))
                merchantsTextView.setTypeface(null, Typeface.BOLD)
            }
        }
    }

    private fun loadData(){
        val nameList : ArrayList<String> = arrayListOf()
        val idList : ArrayList<Int> = arrayListOf()

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {

                    addLogger(StdOutSqlLogger)
                    //get data from DB
                    if (selected == "Customers"){
                        val data = Customers.selectAll()

                        for (row in data){
                            nameList.add(row[Customers.cust_name])
                            idList.add(row[Customers.cust_id])
                        }

                    } else if (selected == "Merchants"){
                        val data = Merchants.selectAll()

                        for (row in data){
                            nameList.add(row[Merchants.workshop_name])
                            idList.add(row[Merchants.merchant_id])
                        }
                    }


                    //load data into textview
                    runOnUiThread{
                        val userRV = findViewById<RecyclerView>(R.id.users_recyclerView)
                        val adapter = ViewUsersAdapter(this@ViewUsers, nameList, idList, selected )
                        userRV?.layoutManager = LinearLayoutManager(this@ViewUsers)
                        userRV?.adapter = adapter

                        userRV?.setHasFixedSize(true)
                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }


}