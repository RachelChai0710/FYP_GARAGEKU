package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.`java-time`.timestamp

object Quotations : Table() {
    val quote_id = integer("quote_id").autoIncrement()
    val desc = varchar("desc",100)
    val date = timestamp("date")
    val cust_id = integer("cust_id")
        .references(Customers.cust_id)
    val merchant_id = integer("merchant_id")
        .references(Merchants.merchant_id)
    val vehicle_id = integer("vehicle_id")
        .references(Vehicles.vehicle_id)
    val status = varchar("status",45)

    override val primaryKey = PrimaryKey(quote_id)
}