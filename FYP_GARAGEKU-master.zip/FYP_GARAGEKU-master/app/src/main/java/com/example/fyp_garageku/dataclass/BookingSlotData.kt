package com.example.fyp_garageku.dataclass

data class BookingSlotData(var startTime:String? = "", var endTime:String?="",var status:String? = "",var slotID:Int? = 0)
