package com.example.fyp_garageku.helper_class

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitInstance {

    private val retofit by lazy {
        Retrofit.Builder()
            .baseUrl(RestAPI.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    val api:RestAPI by lazy{
        retofit.create(RestAPI::class.java)
    }

}