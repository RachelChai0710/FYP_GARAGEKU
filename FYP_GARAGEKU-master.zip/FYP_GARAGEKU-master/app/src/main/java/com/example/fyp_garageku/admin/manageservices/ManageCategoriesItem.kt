package com.example.fyp_garageku.admin.manageservices

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.Services
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction

class ManageCategoriesItem : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_categories_item)

        supportActionBar?.title = "Edit Service"
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val name = intent.getStringExtra("name")
        val desc = intent.getStringExtra("desc")


        val nameEditText = findViewById<EditText>(R.id.service_name_edittext)
        nameEditText.setText(name)

        val descEditText = findViewById<EditText>(R.id.service_desc_edittext)
        descEditText.setText(desc)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.confirm_button_menu, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.confirm_button) {
            val id = intent.getIntExtra("id", 0)

            val name = intent.getStringExtra("name").toString()
            val desc = intent.getStringExtra("desc").toString()

            val newName = findViewById<EditText>(R.id.service_name_edittext).text.toString()
            val newDesc = findViewById<EditText>(R.id.service_desc_edittext).text.toString()

            if (newName != name || newDesc != desc ){
                val thread = Thread {
                    try {
                        Database.connect(
                            "jdbc:mysql://110.4.46.121/carportal",
                            "com.mysql.jdbc.Driver",
                            "fyp", "fyp2020"
                        )
                        transaction {
                            addLogger(StdOutSqlLogger)

                            Services.update({ Services.service_id eq id }) {
                                it[Services.name] = newName
                                it[Services.description] = newDesc
                            }
                        }
                        setResult(RESULT_OK)
                        finish()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                thread.start()
            } else {
                finish()
            }

        }

        return super.onOptionsItemSelected(item)
    }

}