package com.example.fyp_garageku.dataclass
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table

object Admins:Table() {
    val admin_id: Column<Int> = integer("admin_id")
        .autoIncrement()
        .uniqueIndex()
    val admin_name: Column<String> = varchar("admin_name", 45)
    val user_id: Column<Int> = integer("user_id")
        .uniqueIndex()
        .references(Users.id)
}