package com.example.fyp_garageku.merchant.inquiries

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class InquiriesViewModel : ViewModel() {

    val selected: String = "Unread"
}