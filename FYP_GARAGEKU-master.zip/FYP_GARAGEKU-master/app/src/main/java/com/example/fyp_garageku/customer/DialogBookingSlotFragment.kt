package com.example.fyp_garageku.customer

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import androidx.annotation.RequiresApi
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fyp_garageku.adapters.BookingSlotAdapter
import com.example.fyp_garageku.adapters.DaysAdapter
import com.example.fyp_garageku.databinding.DialogBookingSlotBinding
import com.example.fyp_garageku.dataclass.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.util.*
import java.util.Random
import kotlin.collections.ArrayList

class DialogBookingSlotFragment : DialogFragment(),DaysAdapter.DayDialogListener ,BookingSlotAdapter.BookingSlotDialogListener{
    private var _binding: DialogBookingSlotBinding? = null
    private val binding get() = _binding!!
    private var date = ""
    private var intDay = 0
    private lateinit var listener: BookingSlotDialogListener

    interface BookingSlotDialogListener {
        fun onSelected(slotID: Int,slot: String,date:String)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = DialogBookingSlotBinding.inflate(inflater, container, false)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog?.window?.requestFeature(Window.FEATURE_NO_TITLE)
        binding.bookingSlotBtnClose.setOnClickListener {
            dialog?.dismiss()
        }

        initiaDays()
        return binding.root
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        // Verify that the host activity implements the callback interface
        try {
            // Instantiate the BookingSlotDialogListener so we can send events to the host
            listener = context as BookingSlotDialogListener
        } catch (e: ClassCastException) {
            // The activity doesn't implement the interface, throw exception
            throw ClassCastException(
                (context.toString() +
                        " must implement BookingSlotDialogListener")
            )
        }
    }

    private fun initiaDays() {
        val list = ArrayList<Calendar>()
        var dt = Date()
        val c: Calendar = Calendar.getInstance()
        c.time = dt
        val currentDate : Calendar = Calendar.getInstance()
        currentDate.time = dt
        list.add(currentDate)

        for (i in 1..6) {
            val newDate: Calendar = Calendar.getInstance()
            c.add(Calendar.DATE, 1)
            newDate.set(c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH))
            list.add(newDate)
        }
        val layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        binding.recDays.layoutManager = layoutManager
        val adapter = DaysAdapter(requireContext(), list,this)
        binding.recDays.adapter = adapter
        binding.recDays.setHasFixedSize(true)
        binding.recDays.visibility = View.VISIBLE
    }

    fun initiaBookingSlot(day: String) {
        val context = requireContext()
        binding.recBookingSlot.removeAllViewsInLayout()
        binding.bookingSlotProgressBar.visibility = View.VISIBLE
        binding.bookingSlotNotAvailableLayout.visibility = View.GONE
        binding.recBookingSlot.visibility = View.GONE
        GlobalScope.launch {
            val list = withContext(Dispatchers.IO) { loadBookingSlot(day) }

            withContext(Dispatchers.Main) {
                if (list.isNotEmpty()) {
                    val layoutManager =
                        LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
                    binding.recBookingSlot.layoutManager = layoutManager
                    val myAdapter = context?.let { BookingSlotAdapter(it, list,this@DialogBookingSlotFragment) }
                    binding.recBookingSlot.adapter = myAdapter
                    binding.recBookingSlot.setHasFixedSize(true)
                    binding.recBookingSlot.visibility = View.VISIBLE
                    binding.bookingSlotProgressBar.visibility = View.GONE
                }
                else{
                    binding.bookingSlotProgressBar.visibility = View.GONE
                    binding.bookingSlotNotAvailableLayout.visibility = View.VISIBLE
                }
            }
        }
    }

    private suspend fun loadBookingSlot(day: String): MutableList<BookingSlotData> {
        var slotList: MutableList<ResultRow>
        val bSlotList = mutableListOf<BookingSlotData>()
        var merchantID = 0
        if (arguments != null) {
            merchantID = requireArguments().getInt("workshopID")
        }
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)

                slotList = Merchant_Booking_Slots.join(
                    Time_Slots,
                    JoinType.INNER,
                    additionalConstraint = { Merchant_Booking_Slots.timeslot_id eq Time_Slots.timeslot_id })
                    .join(
                        Merchants,
                        JoinType.INNER,
                        additionalConstraint = { Merchant_Booking_Slots.merchant_id eq Merchants.merchant_id })
                    .select {
                        Merchant_Booking_Slots.merchant_id eq merchantID and
                                (Time_Slots.day eq day)
                    }.orderBy(Time_Slots.start_time,SortOrder.ASC)
                    .toMutableList()
                if (slotList.isNotEmpty()){
                    for (item in slotList){
                        var status = "Unavailable"
                        val count = Bookings.select {
                            Bookings.bookedDate eq date and
                                    (Bookings.slot_id eq item[Merchant_Booking_Slots.timeslot_id]) and
                                    (Bookings.merchant_id eq merchantID) and
                                    (Bookings.status eq "Placed")
                        }.count().toInt()
                        if (count < item[Merchant_Booking_Slots.max_cust]){
                            status = "Available"
                        }
                        val slot = BookingSlotData(item[Time_Slots.start_time],item[Time_Slots.end_time],status,item[Time_Slots.timeslot_id])
                        val sdf = SimpleDateFormat("HHmm")
                        val currentDate = sdf.format(Date())

                        val c: Calendar = Calendar.getInstance()
                        val day = c.get(Calendar.DAY_OF_WEEK)

                        if(intDay == day){
                            if (item[Time_Slots.start_time].toInt() > currentDate.toInt())
                                bSlotList.add(slot)
                        }
                        else{
                            bSlotList.add(slot)
                        }
                    }
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
        return bSlotList
    }

    override fun onClickRecDay(day: String,date:String,intDay:Int) {
        this.date = date
        this.intDay = intDay
        initiaBookingSlot(day)
    }

    override fun onClickRecSlot(slotID: Int, slot: String) {
        listener.onSelected(slotID,slot,date)
        dialog?.dismiss()
    }
}