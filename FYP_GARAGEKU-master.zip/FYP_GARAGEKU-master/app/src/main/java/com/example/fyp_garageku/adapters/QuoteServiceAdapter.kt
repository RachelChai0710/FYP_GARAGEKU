package com.example.fyp_garageku.adapters

import android.content.Context
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.ServiceData
import java.util.function.Predicate

class QuoteServiceAdapter (
    private val context: Context,
    private val dataset: List<ServiceData>,
    var checkedService: ArrayList<Int>,
    private val isBooking: Boolean
) : RecyclerView.Adapter<QuoteServiceAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val checkBox:CheckBox = view.findViewById(R.id.chb_service)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(context)
            .inflate(R.layout.item_quote_service, parent, false)
        return ItemViewHolder(adapterLayout)
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        if (isBooking){
            holder.checkBox.setTextColor(context.getColor(R.color.white))
        }
        val item = dataset[position]
        holder.checkBox.text = item.service
        holder.itemView.setOnClickListener {
            holder.checkBox.isChecked = !holder.checkBox.isChecked

        }
        holder.checkBox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked){
                item.id?.let { checkedService?.add(it) }
            }
            else{
                var removedItem = Predicate{id:Int -> id == item.id}
                checkedService?.removeIf(removedItem)
            }
        }
    }

    override fun getItemCount() = dataset.size

    fun getCheckedServiceList() = checkedService

}