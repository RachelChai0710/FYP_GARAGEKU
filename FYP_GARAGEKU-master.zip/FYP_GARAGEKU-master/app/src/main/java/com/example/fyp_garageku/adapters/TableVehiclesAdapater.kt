package com.example.fyp_garageku.adapters

import android.content.Context
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.VehiclesData

class TableVehiclesAdapater (private val context: Context,
                             private val dataset : List<VehiclesData>,
                             private val isBooking: Boolean
) : RecyclerView.Adapter<TableVehiclesAdapater.ItemViewHolder>() {
    private var lastChecked: RadioButton? = null
    private var lastCheckedPos = 0
    private lateinit var selectedVehicle:VehiclesData
    class ItemViewHolder(private val view : View) : RecyclerView.ViewHolder(view) {
        val txtBrand : TextView = view.findViewById(R.id.txtBrand)
        val txtModel : TextView = view.findViewById(R.id.txtModel)
        val txtCarPlate : TextView = view.findViewById(R.id.txtCarPlate)
        val radVehicle:RadioButton = view.findViewById(R.id.rad_vehicle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(context)
            .inflate(R.layout.item_table_vehicle, parent, false)

        return ItemViewHolder(adapterLayout)
    }
    @RequiresApi(Build.VERSION_CODES.M)
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        holder.txtBrand.text = item.brand
        holder.txtModel.text = item.model
        holder.txtCarPlate.text = item.carPlate
        holder.radVehicle.tag = position
        if (lastChecked == null){
            holder.radVehicle.isChecked = true
        }

        if (isBooking){
            holder.txtBrand.setTextColor(context.getColor(R.color.white))
            holder.txtModel.setTextColor(context.getColor(R.color.white))
            holder.txtCarPlate.setTextColor(context.getColor(R.color.white))
        }

        //for default check in first item
        if (position == 0  && holder.radVehicle.isChecked) {
            lastChecked = holder.radVehicle
            lastCheckedPos = 0
            selectedVehicle = dataset[position]
        }

        holder.radVehicle.setOnClickListener(View.OnClickListener { v ->
            val radio = v as RadioButton
            val clickedPos = (radio.tag as Int).toInt()
            if (radio.isChecked) {
                if (lastChecked != null) {
                    lastChecked!!.isChecked = false
                }
                lastChecked = radio
                lastCheckedPos = clickedPos
                selectedVehicle = dataset[position]
            } else lastChecked = null
        })

    }

    override fun getItemCount() = dataset.size

    fun getSelectedVehicle():VehiclesData{
        return selectedVehicle
    }
}