package com.example.fyp_garageku

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import com.example.fyp_garageku.databinding.ActivityChangePasswordBinding
import com.example.fyp_garageku.databinding.ActivityRecoveryPasswordBinding
import com.example.fyp_garageku.dataclass.Users
import com.example.fyp_garageku.helper_class.Hash
import com.example.fyp_garageku.helper_class.Validation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction

class RecoveryPassword : AppCompatActivity() {
    private lateinit var binding: ActivityRecoveryPasswordBinding
    private val validator = Validation()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecoveryPasswordBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        binding.recoveryTxtNewPw.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateNewPassword()
            }
        })
        binding.recoveryTxtConfirmPw.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateConfirmPassword()
            }
        })
    }
    fun changePasswordOnClick(view: View){
        binding.recoveryProgress.visibility = View.VISIBLE
        val context = this
        if (validateNewPassword() && validateConfirmPassword()) {
            val hash = Hash()
            val hashedNewPW = hash.getSHA512(binding.recoveryTxtNewPw.text?.trim().toString())
            GlobalScope.launch {
                    val isSuccess = withContext(Dispatchers.IO){changeDBPW(hashedNewPW)}
                    if (isSuccess){
                        withContext(Dispatchers.Main){
                            Toast.makeText(context, "Your password is changed", Toast.LENGTH_LONG).show()
                            val intent = Intent(context, Login::class.java)
                            startActivity(intent)
                        }
                    }

                withContext(Dispatchers.Main){
                    binding.recoveryProgress.visibility = View.GONE
                }
            }
        }
    }
    private suspend fun changeDBPW(hashedNewPW: String):Boolean{
        var user = 0
        val email = intent.getStringExtra("email").toString()
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)
                //get data from DB
                user = Users.update({ Users.email eq email}) {
                    it[password] = hashedNewPW
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return user != 0
    }

    private fun validateNewPassword():Boolean{
        return !validator.isNull(binding.recoveryTxtNewPw.text?.trim().toString(),binding.recoveryNewPw) && validator.isPassword(binding.recoveryTxtNewPw.text?.trim().toString(),binding.recoveryNewPw)
    }

    private fun validateConfirmPassword():Boolean{
        var isMatch = false
        val isNull = validator.isNull(binding.recoveryTxtConfirmPw.text?.trim().toString(),binding.recoveryConfirmPw)

        if (binding.recoveryTxtNewPw.text?.trim().toString() == binding.recoveryTxtConfirmPw.text?.trim().toString()){
            isMatch = true
            binding.recoveryConfirmPw.error = ""
        }
        else{
            isMatch = false
            binding.recoveryConfirmPw.error = getString(R.string.pw_not_same)
        }
        return !isNull && isMatch
    }
}