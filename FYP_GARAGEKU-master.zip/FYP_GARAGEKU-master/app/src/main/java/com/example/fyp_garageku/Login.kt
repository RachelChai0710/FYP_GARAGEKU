package com.example.fyp_garageku

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.example.fyp_garageku.admin.AdminHomepage
import com.example.fyp_garageku.customer.CustomerHomepage
import com.example.fyp_garageku.databinding.ActivityLoginBinding
import com.example.fyp_garageku.dataclass.Admins
import com.example.fyp_garageku.dataclass.Customers
import com.example.fyp_garageku.dataclass.Merchants
import com.example.fyp_garageku.dataclass.Users
import com.example.fyp_garageku.helper_class.Hash
import com.example.fyp_garageku.merchant.MerchantHomepage
import com.facebook.*
import com.facebook.login.LoginResult
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.SignInButton
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.util.*


class Login : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private val helper = Hash()
    private val callbackManager = CallbackManager.Factory.create()
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var editor: SharedPreferences.Editor
    private lateinit var mGoogleSignInClient: GoogleSignInClient
    private var RC_SIGN_IN = 0
    private val context = this
    private val EMAIL = "email"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        val view = binding.root
        sharedPreferences = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        editor = sharedPreferences.edit()

        setContentView(view)

        //Facebook Login
        facebookLogin()

        //Gmail Login
        googleLogin()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    //Use this function if FB error showed key hash does not match any stored key hashes and add the key hash to https://developers.facebook.com/docs/facebook-login/android
    private fun getKeyHashFB(){
        // Add code to print out the key hash
        // Add code to print out the key hash
        try {
            val info =
                packageManager.getPackageInfo("com.example.fyp_garageku", PackageManager.GET_SIGNATURES)
            for (signature in info.signatures) {
                val md: MessageDigest = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                Log.e("KeyHash:", Base64.getEncoder().encodeToString(md.digest()))
            }
        } catch (e: PackageManager.NameNotFoundException) {
            Log.e("KeyHash:", e.toString())
        } catch (e: NoSuchAlgorithmException) {
            Log.e("KeyHash:", e.toString())
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        //FB callback manager
        callbackManager.onActivityResult(requestCode, resultCode, data)

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode === RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            val task: Task<GoogleSignInAccount> =
                GoogleSignIn.getSignedInAccountFromIntent(data)
            handleSignInResult(task)
        }
    }

    //FB Login functions
    private fun facebookLogin() {
        //set permission for the fb login button
        binding.fbLoginButton.setReadPermissions(listOf(EMAIL))
        var accessToken = AccessToken.getCurrentAccessToken()
        var isLoggedIn = accessToken != null && !accessToken.isExpired
        // Callback registration
        binding.fbLoginButton.registerCallback(
            callbackManager,
            object : FacebookCallback<LoginResult?> {
                override fun onSuccess(loginResult: LoginResult?) {
                    accessToken = AccessToken.getCurrentAccessToken()
                    val isExpired  =(accessToken?.isExpired)
                    isLoggedIn = accessToken != null && !isExpired!!
                    editor.putString("userType", "customer").apply()
                    accessToken?.let { loadFBUserProfile(it, loginResult?.accessToken?.userId) }
                    Toast.makeText(context, "You have logged in successfully!", Toast.LENGTH_LONG)
                        .show()
                }

                override fun onCancel() {
                    // App code
                }

                override fun onError(exception: FacebookException) {
                    Toast.makeText(
                        context,
                        "Failed to log in! An error was occurred",
                        Toast.LENGTH_LONG
                    ).show()
                    Log.e("facebook login error", exception.toString())
                }
            })


    }

    private fun loadFBUserProfile(newAccessToken: AccessToken, userID: String?) {
        val context = this
        val parameters = Bundle()
        parameters.putString(
            "fields",
            "id, first_name, middle_name, last_name, picture.type(large), email,gender"
        )
        GraphRequest(newAccessToken,
            "/$userID/",
            parameters,
            HttpMethod.GET,
            GraphRequest.Callback { response ->
                val jsonObject = response.jsonObject
                var firstName = ""
                var lastName = ""
                var middleName = ""
                var username = ""
                var email = ""
                var id = ""
                var gender = ""
                var imageURL = "https://graph.facebook.com/$id/picture?type=normal"
                if (BuildConfig.DEBUG) {
                    FacebookSdk.setIsDebugEnabled(true)
                    FacebookSdk.addLoggingBehavior(LoggingBehavior.INCLUDE_ACCESS_TOKENS)
                }


                if (jsonObject != null) {
                    // Facebook Id
                    if (jsonObject.has("id")) {
                        id = jsonObject.getString("id")
                    }
                    // Facebook First Name
                    if (jsonObject.has("first_name")) {
                        firstName = jsonObject.getString("first_name")
                        username = firstName
                    }

                    // Facebook Middle Name
                    if (jsonObject.has("middle_name")) {
                        middleName = jsonObject.getString("middle_name")
                        if (!middleName.equals("")) {
                            username = "$username $middleName"
                        }
                    }

                    // Facebook Last Name
                    if (jsonObject.has("last_name")) {
                        lastName = jsonObject.getString("last_name")
                        username = "$username $lastName"
                    }

                    // Facebook Profile Pic URL
                    if (jsonObject.has("picture")) {
                        val facebookPictureObject = jsonObject.getJSONObject("picture")
                        if (facebookPictureObject.has("data")) {
                            val facebookDataObject = facebookPictureObject.getJSONObject("data")
                            if (facebookDataObject.has("url")) {
                                imageURL = facebookDataObject.getString("url")
                                imageURL.replace("type=normal", "type=album&height=500&width=500")
                            }
                        }
                    }

                    // Facebook Email
                    if (jsonObject.has("email")) {
                        email = jsonObject.getString("email")

                    }

                    // Facebook gender
                    if (jsonObject.has("gender")) {
                        gender = jsonObject.getString("gender")

                    }
                }

                editor.putString("email", email).apply()
                editor.putString("imageURL", imageURL).apply()
                editor.putString("username", username).apply()
                editor.putString("gender", gender).apply()

                insertCustToDB(email, username, gender,"Facebook",imageURL)

                val intent = Intent(context, CustomerHomepage::class.java)
                startActivity(intent)
                finish()
            }).executeAsync()

    }

    private fun insertCustToDB(email: String, username: String, gender: String,type:String,imageURL:String?) {
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)
                    var isExist = false
                    //get data from DB
                    val user = Users.selectAll().forEach {
                        if (it[Users.email].equals(email)) {
                            isExist = true
                            val cust =
                                Customers.select(Op.build { Customers.user_id eq it[Users.id] })
                                    .first()
                            editor.putString("id", cust[Customers.cust_id].toString()).apply()
                            Customers.update({Customers.user_id eq it[Users.id]}) {
                                it[Customers.imageURL] = imageURL.toString()
                            }
                        }
                    }

                    if (!isExist) {
                        val userID = Users.insert {
                            it[Users.email] = email
                            it[user_type_id] = 2
                        } get Users.id

                        val custID = Customers.insert {
                            it[user_id] = userID
                            it[cust_name] = username
                            if (gender != "")
                                it[Customers.gender] = gender
                            it[login_type] = type
                            it[Customers.imageURL] = imageURL.toString()
                        } get Customers.cust_id
                        editor.putString("id", custID.toString()).apply()
                        editor.putString("phone", "-").apply()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
        thread.join()
    }

    //Google Login functions
    private fun googleLogin() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestProfile()
            .build()
        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso)

        binding.googleLoginButton.setSize(SignInButton.SIZE_STANDARD);
        binding.googleLoginButton.setOnClickListener(View.OnClickListener {
            val signInIntent: Intent = mGoogleSignInClient.getSignInIntent()
            startActivityForResult(signInIntent, RC_SIGN_IN)
        })
    }

    private fun handleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            loadGoogleUserProfile()
            val account = GoogleSignIn.getLastSignedInAccount(this)
            if (account!=null){
                val intent = Intent(this, CustomerHomepage::class.java)
                startActivity(intent)
                finish()
            }
        } catch (e: ApiException) {
            e.printStackTrace()
            Toast.makeText(
                context,
                "Failed to log in! An error was occurred",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun loadGoogleUserProfile() {
        val acct = GoogleSignIn.getLastSignedInAccount(context)
        if (acct != null) {
            val username = acct.displayName
            val email = acct.email
            val imageURL: Uri? = acct.photoUrl
            editor.putString("userType", "customer").apply()
            editor.putString("email", email).apply()
            editor.putString("imageURL", imageURL.toString()).apply()
            editor.putString("username", username).apply()
            if (username != null && email != null) {
                insertCustToDB(email, username, "","Gmail",imageURL.toString())
            }
        }
    }

    fun forgotPassword(v: View) {
        val intent = Intent(this, ForgotPassword::class.java)
        startActivity(intent)
    }

    fun login(v: View) {
        binding.loginProgressLayout.visibility = View.VISIBLE

        //Get user's input
        val email = binding.loginInputEmail.text?.trim().toString()
        val password = binding.loginInputPassword.text?.trim().toString()
        var userType = ""
        //Convert password to hash value
        val hashUserPw = helper.getSHA512(password)

        //store current user's email to shared preference
        editor.putString("email", email).apply()

        var loginStatus = false

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)
                    //get data from DB
                    val user = Users.select(Op.build { Users.email eq email }).first()
                    if (user[Users.password] == hashUserPw) {
                        loginStatus = true
                        editor.putString("userID", user[Users.id].toString()).apply()
                        when (user[Users.user_type_id]) {
                            1 -> {
                                userType = "merchant"
                                val merchant =
                                    Merchants.select(Op.build { Merchants.user_id eq user[Users.id] })
                                        .first()
                                editor.putString("id", merchant[Merchants.merchant_id].toString())
                                    .apply()
                            }
                            2 -> {
                                userType = "customer"
                                val cust =
                                    Customers.select(Op.build { Customers.user_id eq user[Users.id] })
                                        .first()
                                editor.putString("id", cust[Customers.cust_id].toString()).apply()
                                editor.putString("phone", cust[Customers.cust_phone].toString())
                                    .apply()
                                editor.putString("username", cust[Customers.cust_name].toString())
                                    .apply()
                            }
                            else -> {
                                userType = "admin"
                                val admin =
                                    Admins.select(Op.build { Admins.user_id eq user[Users.id] })
                                        .first()
                                editor.putString("id", admin[Admins.admin_id].toString()).apply()
                            }
                        }
                        editor.putString("userType", userType).apply()

                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
        thread.join()
        binding.loginProgressLayout.visibility = View.GONE
        if (loginStatus) {

            Toast.makeText(this, "You have logged in successfully!", Toast.LENGTH_LONG).show()
            if (userType == "merchant") {
                val intent = Intent(this, MerchantHomepage::class.java)
                startActivity(intent)
                finish()
            } else if (userType == "admin") {
                val intent = Intent(this, AdminHomepage::class.java)
                startActivity(intent)
                finish()
            } else {
                val intent = Intent(this, CustomerHomepage::class.java)
                startActivity(intent)
                finish()
            }
        } else {
            Toast.makeText(
                this,
                "Failed to log in! Your email or password is incorrect.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    fun register(v: View) {
        val intent = Intent(this, Registration::class.java)
        startActivity(intent)
    }
}