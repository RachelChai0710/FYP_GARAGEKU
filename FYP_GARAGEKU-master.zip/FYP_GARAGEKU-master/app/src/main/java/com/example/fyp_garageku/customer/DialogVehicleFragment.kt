package com.example.fyp_garageku.customer

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.example.fyp_garageku.R
import com.example.fyp_garageku.databinding.DialogVehicleBinding
import com.example.fyp_garageku.dataclass.Customers
import com.example.fyp_garageku.dataclass.Users
import com.example.fyp_garageku.dataclass.Vehicles
import com.example.fyp_garageku.helper_class.Validation
import kotlinx.coroutines.*
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction

class DialogVehicleFragment : DialogFragment() {
    private var _binding: DialogVehicleBinding? = null
    private val binding get() = _binding!!
    private val validator = Validation()
    private lateinit var listener: VehicleDialogListener
    private var position = 0

    interface VehicleDialogListener {
        fun onUpdated(position: Int)
        fun onInserted()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = DialogVehicleBinding.inflate(inflater, container, false)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog?.window?.requestFeature(Window.FEATURE_NO_TITLE)
        binding.vehicleBtnClose.setOnClickListener {
            dialog?.dismiss()
        }
        var action = ""
        initiaSpinner()

        if (arguments != null) {
            val args = arguments
            action = args?.getString("action").toString()
            position = args?.getInt("position")!!
            when (action) {
                "edit" -> {
                    binding.vehicleBtnSubmit.text = activity?.getString(R.string.update)
                    binding.vehicleDialogTitle.text = activity?.getString(R.string.edit_vehicle)
                    showDetails(args)
                }
                "details" -> {
                    binding.vehicleDialogSpinnerCarType.isEnabled = false
                    binding.vehicleDialogSpinnerBrand.isEnabled = false
                    binding.vehicleDialogSpinnerCc.isEnabled = false
                    binding.vehicleDialogSpinnerYear.isEnabled = false
                    binding.vehicleDialogTxtCarPlate.isEnabled = false
                    binding.vehicleDialogCarPlate.isCounterEnabled = false
                    binding.vehicleDialogModel.isEnabled = false
                    binding.vehicleBtnSubmit.visibility = View.GONE
                    showDetails(args)
                }
            }
        } else {
            binding.vehicleDialogTitle.text = activity?.getString(R.string.add_new_vehicle)
            binding.vehicleBtnSubmit.text = activity?.getString(R.string.add)
        }

        binding.vehicleBtnSubmit.setOnClickListener() {
            if (validateCarplate() && validateModel()) {
                when (binding.vehicleBtnSubmit.text) {
                    getString(R.string.update) -> {
                        editDetails()
                    }
                    getString(R.string.add) -> {
                        addVehicle()
                    }
                }
            } else {
                Toast.makeText(activity, "Please enter all required fields!", Toast.LENGTH_LONG)
                    .show()
            }
        }

        binding.vehicleDialogTxtCarPlate.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateCarplate()
            }
        })

        binding.vehicleDialogTxtModel.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                validateModel()
            }
        })
        return binding.root
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        // Verify that the host activity implements the callback interface
        try {
            // Instantiate the VehicleDialogListener so we can send events to the host
            listener = context as VehicleDialogListener
        } catch (e: ClassCastException) {
            // The activity doesn't implement the interface, throw exception
            throw ClassCastException(
                (context.toString() +
                        " must implement VehicleDialogListener")
            )
        }
    }

    private fun validateCarplate(): Boolean {
        return !validator.isNull(
            binding.vehicleDialogTxtCarPlate.text?.trim().toString(),
            binding.vehicleDialogCarPlate
        )
    }

    private fun validateModel(): Boolean {
        return !validator.isNull(
            binding.vehicleDialogTxtModel.text?.trim().toString(),
            binding.vehicleDialogModel
        )
    }

    private fun initiaSpinner() {
        // Create an ArrayAdapter using the string array and a default spinner layout
        activity?.let {
            //Brand Spinner
            ArrayAdapter.createFromResource(
                it,
                R.array.car_brands,
                android.R.layout.simple_spinner_item
            ).also { adapter ->
                // Specify the layout to use when the list of choices appears
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                // Apply the adapter to the spinner
                binding.vehicleDialogSpinnerBrand.adapter = adapter
            }

            //Car Type Spinner
            ArrayAdapter.createFromResource(
                it,
                R.array.car_type,
                android.R.layout.simple_spinner_item
            ).also { adapter ->
                // Specify the layout to use when the list of choices appears
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                // Apply the adapter to the spinner
                binding.vehicleDialogSpinnerCarType.adapter = adapter
            }

            //CC Spinner
            ArrayAdapter.createFromResource(
                it,
                R.array.cc,
                android.R.layout.simple_spinner_item
            ).also { adapter ->
                // Specify the layout to use when the list of choices appears
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                // Apply the adapter to the spinner
                binding.vehicleDialogSpinnerCc.adapter = adapter
            }

            //Year Spinner
            ArrayAdapter.createFromResource(
                it,
                R.array.years,
                android.R.layout.simple_spinner_item
            ).also { adapter ->
                // Specify the layout to use when the list of choices appears
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                // Apply the adapter to the spinner
                binding.vehicleDialogSpinnerYear.adapter = adapter
            }
        }
    }

    private fun showDetails(args: Bundle?) {
        if (args != null) {
            binding.vehicleDialogTxtCarPlate.setText(args.getString("carPlate"))
            binding.vehicleDialogTxtModel.setText(args.getString("model"))
            val brand = args.getString("brand").toString()
            val carType = args.getString("carType").toString()
            val year = args.getInt("year")
            val cc = args.getDouble("cc")

            GlobalScope.async {
                setBrandSpinner(brand)
                setCarTypeSpinner(carType)
                setYearSpinner(year)
                setCCSpinner(cc)
            }
        }
    }

    private fun setCarTypeSpinner(carType: String) {
        val adapter = binding.vehicleDialogSpinnerCarType.adapter
        val count = adapter.count - 1
        for (i in 0..count) {
            val item = adapter.getItem(i).toString()
            if (item == carType)
                binding.vehicleDialogSpinnerCarType.setSelection(i)
        }
    }

    private fun setYearSpinner(year: Int) {
        val adapter = binding.vehicleDialogSpinnerYear.adapter
        val count = adapter.count - 1
        for (i in 0..count) {
            val item = adapter.getItem(i).toString().toInt()
            if (item == year)
                binding.vehicleDialogSpinnerYear.setSelection(i)
        }
    }

    private fun setBrandSpinner(brand: String) {
        val adapter = binding.vehicleDialogSpinnerBrand.adapter
        val count = adapter.count - 1
        for (i in 0..count) {
            val item = adapter.getItem(i).toString()
            if (item == brand)
                binding.vehicleDialogSpinnerBrand.setSelection(i)
        }
    }

    private fun setCCSpinner(cc: Double) {
        val adapter = binding.vehicleDialogSpinnerCc.adapter
        val count = adapter.count - 1
        for (i in 0..count) {
            val item = adapter.getItem(i).toString().toDouble()
            if (item == cc)
                binding.vehicleDialogSpinnerCc.setSelection(i)
        }
    }

    private fun editDetails() {
        var isUpdated = false
        GlobalScope.launch {
            withContext(Dispatchers.IO) {
                isUpdated = updateVehicle()
            }
            withContext(Dispatchers.Main) {
                if (isUpdated) {
                    Toast.makeText(activity, "Vehicle info is updated!", Toast.LENGTH_LONG).show()
                    dialog?.dismiss()
                    listener.onUpdated(position)
                } else {
                    Toast.makeText(
                        activity,
                        "Failed to update vehicle info! Please try again",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private suspend fun updateVehicle(): Boolean {
        val vehicleID = arguments?.getInt("id")
        var isUpdated = false
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)
                //get data from DB
                val vehicle =
                    Vehicles.update({ Vehicles.vehicle_id eq (vehicleID?.toInt() ?: 0) }) {
                        it[car_type] = binding.vehicleDialogSpinnerCarType.selectedItem.toString()
                        it[car_plate] = binding.vehicleDialogTxtCarPlate.text?.trim().toString()
                        it[brand] = binding.vehicleDialogSpinnerBrand.selectedItem.toString()
                        it[model] = binding.vehicleDialogTxtModel.text?.trim().toString()
                        it[year] = binding.vehicleDialogSpinnerYear.selectedItem.toString().toInt()
                        it[cc] =
                            binding.vehicleDialogSpinnerCc.selectedItem.toString().toBigDecimal()
                    }
                isUpdated = vehicleID != 0
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return isUpdated
    }

    private fun addVehicle() {
        var isInserted = false
        GlobalScope.launch {
            withContext(Dispatchers.IO) {
                isInserted = insertVehicle()
            }
            withContext(Dispatchers.Main) {
                if (isInserted) {
                    Toast.makeText(
                        activity,
                        "You have successfully added your vehicle",
                        Toast.LENGTH_LONG
                    ).show()

                    dialog?.dismiss()

                    listener.onInserted()
                } else {
                    Toast.makeText(
                        activity,
                        "Failed to add vehicle! Please try again",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private suspend fun insertVehicle(): Boolean {
        var isInserted = false
        val sharedPref = activity?.getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        val id = sharedPref?.getString("id", "")?.toInt()
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)
                //get data from DB
                val id = Vehicles.insert {
                    it[car_type] = binding.vehicleDialogSpinnerCarType.selectedItem.toString()
                    it[car_plate] = binding.vehicleDialogTxtCarPlate.text?.trim().toString()
                    it[brand] = binding.vehicleDialogSpinnerBrand.selectedItem.toString()
                    it[model] = binding.vehicleDialogTxtModel.text?.trim().toString()
                    it[year] = binding.vehicleDialogSpinnerYear.selectedItem.toString().toInt()
                    it[cc] = binding.vehicleDialogSpinnerCc.selectedItem.toString().toBigDecimal()
                    it[cust_id] = (id ?: 0)
                } get Vehicles.vehicle_id
                isInserted = id != 0
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return isInserted
    }
}