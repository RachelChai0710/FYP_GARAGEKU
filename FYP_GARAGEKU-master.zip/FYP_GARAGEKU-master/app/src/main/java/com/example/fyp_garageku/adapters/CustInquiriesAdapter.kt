package com.example.fyp_garageku.adapters

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.fyp_garageku.R
import com.example.fyp_garageku.admin.ApproveRegistrationItem
import com.example.fyp_garageku.customer.InquiriesDetails
import com.example.fyp_garageku.customer.WorkshopDetails
import com.example.fyp_garageku.dataclass.*
import com.squareup.picasso.Picasso
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import javax.mail.Quota

class CustInquiriesAdapter(
    private val context: Context,
    private val dataset: List<CustInquiriesData>,
    private val custID:Int,
    private val listener:CustInquiriesAdapterListener,
) : RecyclerView.Adapter<CustInquiriesAdapter.ItemViewHolder>() {

    interface CustInquiriesAdapterListener {
        fun onInquiryCountUpdated(row:Int)
    }

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val img: ImageView = view.findViewById(R.id.inquiries_workshop_img)
        val txtName: TextView = view.findViewById(R.id.inquiries_workshop_name)
        val txtTime :TextView = view.findViewById(R.id.inquiries_time)
        val txtMessage:TextView = view.findViewById(R.id.inquiries_message)
        val imgRead: ImageView = view.findViewById(R.id.img_read)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(context)
            .inflate(R.layout.item_inquiries, parent, false)
        return ItemViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        holder.txtName.text = item.name
        holder.txtTime.text = item.time.toString()
        holder.txtMessage.text = "${item.service}"
        if (item.status == "Read"){
            holder.imgRead.visibility = View.GONE
        }
        else
            holder.imgRead.visibility = View.VISIBLE
        Picasso.get()
            .load("http://test.onmyfinger.com/images/merchant${item.merchantID}displaypicture.jpg")
            .placeholder(R.drawable.placeholder)
            .error(R.drawable.placeholder)
            .into(holder.img)
        holder.itemView.setOnClickListener {
            item.merchantID?.let { it1 -> updateStatus(it1) }
            holder.imgRead.visibility = View.GONE
            val intent = Intent(context, InquiriesDetails::class.java)
            intent.putExtra("name",item.name)
            (context as Activity).startActivityForResult(intent, 2404)
        }
    }

    override fun getItemCount() = dataset.size

    private fun updateStatus(merchantID:Int){
        GlobalScope.launch {
            withContext(Dispatchers.IO){
                try {
                    Database.connect(
                        "jdbc:mysql://110.4.46.121/carportal",
                        "com.mysql.jdbc.Driver",
                        "fyp", "fyp2020"
                    )
                    transaction {
                        addLogger(StdOutSqlLogger)
                        val row = Replies.join(Quotations, JoinType.INNER,additionalConstraint = {Replies.quote_id eq Quotations.quote_id})
                            .update({ Quotations.cust_id eq custID and (Quotations.merchant_id eq merchantID)}) {
                            it[Replies.status] = "Read"
                        }
                        listener.onInquiryCountUpdated(row)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

}