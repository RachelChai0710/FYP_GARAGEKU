package com.example.fyp_garageku.customer

import android.R
import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fyp_garageku.adapters.QuoteServiceAdapter
import com.example.fyp_garageku.adapters.TableVehiclesAdapater
import com.example.fyp_garageku.databinding.ActivityBookAppointmentBinding
import com.example.fyp_garageku.dataclass.*
import com.example.fyp_garageku.helper_class.AlarmReceiver
import com.example.fyp_garageku.helper_class.Hash
import com.example.fyp_garageku.helper_class.Validation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction
import java.util.*
import kotlin.collections.ArrayList

class BookAppointment : AppCompatActivity(),DialogBookingSlotFragment.BookingSlotDialogListener {
    private lateinit var binding: ActivityBookAppointmentBinding
    private var serviceList = ArrayList<ServiceData>()
    private lateinit var tableVehiclesAdapater: TableVehiclesAdapater
    private var bookingSlotID = 0
    private var name = ""
    private val validator = Validation()
    private lateinit var serviceAdapter: QuoteServiceAdapter
    private lateinit var alarmManager:AlarmManager
    private lateinit var pendingIntent:PendingIntent

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBookAppointmentBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        createNotificationChannel()
        serviceList = intent.getParcelableArrayListExtra<ServiceData>("serviceList") as ArrayList<ServiceData>
        name = intent.getStringExtra("name").toString()
        initiaRecService()
        initiaRecycleView()

        binding.bookingTimeSlot.setEndIconOnClickListener {
            val dialog = DialogBookingSlotFragment()
            val arg = Bundle()
            val merchantID = intent.getIntExtra("workshopID",0)
            arg.putInt("workshopID", merchantID)
            dialog.arguments = arg
            dialog.show(supportFragmentManager, "Booking Slot")
        }
    }

    fun bookNowOnClick(v:View){
        var validDate = validDate()
        val validSlot = validSlot()

        if (validDate && validSlot){
            GlobalScope.launch {
                val bookingID = withContext(Dispatchers.IO) { insertBooking()}
                withContext(Dispatchers.Main){
                    val builder: AlertDialog.Builder? = AlertDialog.Builder(this@BookAppointment)
                    if (bookingID != 0){
                        val hash = Hash()
                        val title = getString(com.example.fyp_garageku.R.string.successfully_add_booking_title) +
                                " #${hash.getShortHash(bookingID.toLong())}"
                        builder?.apply {
                            setCancelable(false)
                            setMessage(getString(com.example.fyp_garageku.R.string.successfully_add_booking))
                            setTitle(title)
                            setIcon(com.example.fyp_garageku.R.drawable.ic_baseline_beenhere_24)
                            setPositiveButton(R.string.ok
                            ) { dialog, id ->
                                dialog.dismiss()
                                this@BookAppointment.finish()
                            }
                        }
                        setBookingAlert(bookingID)
                    }else{
                        builder?.apply {
                            setCancelable(false)
                            setMessage(getString(com.example.fyp_garageku.R.string.failed_add_booking))
                            setTitle(getString(com.example.fyp_garageku.R.string.failed_add_booking_title))
                            setIcon(com.example.fyp_garageku.R.drawable.ic_cross)
                            setPositiveButton(com.example.fyp_garageku.R.string.try_again
                            ) { dialog, _ ->
                                dialog.dismiss()
                            }
                            setNegativeButton(R.string.cancel
                            ) { dialog, _ ->
                                dialog.dismiss()
                                this@BookAppointment.finish()
                            }
                        }
                    }
                    val dialog = builder!!.create()
                    dialog.show()
                }
            }
        }
    }

    private fun validDate() = !validator.isNull(binding.bookingTxtDate.text?.trim().toString(),
        binding.bookingDate)

    private fun validSlot() = !validator.isNull(binding.bookingTxtTimeSlot.text?.trim().toString(),
        binding.bookingTimeSlot)

    private suspend fun insertBooking():Int{
        var bookingID = 0
        val checkedServiceList = serviceAdapter.getCheckedServiceList()
        if (checkedServiceList.isNotEmpty()) {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)
                    val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
                    val id = sharedPref?.getString("id", "")?.toInt()
                    val merchantID = intent.getIntExtra("workshopID", 0)
                    val vehicleID = tableVehiclesAdapater.getSelectedVehicle().vehicle_id!!.toInt()

                    bookingID = Bookings.insert {
                        it[slot_id] = bookingSlotID
                        it[cust_id] = (id?.toInt() ?: 0)
                        it[bookedDate] = binding.bookingTxtDate.text?.trim().toString()
                        it[merchant_id] = merchantID
                        it[vehicle_id] = vehicleID
                    } get Bookings.booking_id

                    if (bookingID != 0) {
                        for (item in checkedServiceList) {
                            Booking_Services.insert {
                                it[booking_id] = bookingID
                                it[service_id] = item
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        else{
            withContext(Dispatchers.Main){
                Toast.makeText(this@BookAppointment,"Please select at least 1 service", Toast.LENGTH_LONG).show()
            }
        }
        return bookingID
    }

    private fun initiaRecService() {
        val layoutManager = GridLayoutManager(this, 2)
        binding.bookingRecService.layoutManager = layoutManager
        serviceAdapter =  QuoteServiceAdapter(this, serviceList,ArrayList(),true)
        binding.bookingRecService.adapter = serviceAdapter
        binding.bookingRecService.setHasFixedSize(true)
    }

    private fun initiaRecycleView() {
        val context = this
        GlobalScope.launch {
            val list = withContext(Dispatchers.IO) {
                loadVehicles()
            }

            withContext(Dispatchers.Main) {
                val layoutManager = LinearLayoutManager(context)
                binding.bookingRecVehicle.layoutManager = layoutManager
                binding.bookingRecVehicle.addItemDecoration(
                    DividerItemDecoration(
                        binding.bookingRecVehicle.context,
                        layoutManager.orientation
                    )
                )
                tableVehiclesAdapater = context?.let { TableVehiclesAdapater(it, list,true) }!!
                binding.bookingRecVehicle.adapter = tableVehiclesAdapater
                binding.bookingRecVehicle.setHasFixedSize(true)
                binding.bookingProgressBar.visibility = View.GONE
            }
        }
    }

    private fun loadVehicles(): MutableList<VehiclesData> {
        binding.bookingRecVehicle.removeAllViewsInLayout()
        val vehicleList = mutableListOf<VehiclesData>()

        val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        val id = sharedPref?.getString("id", "")?.toInt()

        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                var vehiclesData: VehiclesData
                addLogger(StdOutSqlLogger)

                Vehicles.select(Op.build {
                    Vehicles.cust_id eq (id?.toInt() ?: 0)
                }).map {
                    vehiclesData = VehiclesData(
                        it[Vehicles.vehicle_id],
                        it[Vehicles.car_type],
                        it[Vehicles.brand],
                        it[Vehicles.model],
                        it[Vehicles.cust_id],
                        it[Vehicles.year],
                        it[Vehicles.car_plate],
                        it[Vehicles.cc].toDouble()
                    )
                    vehicleList.add(vehiclesData)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return vehicleList
    }

    //Callback from timeslot dialog
    override fun onSelected(slotID: Int, slot: String,date:String) {
        bookingSlotID = slotID
        binding.bookingTxtTimeSlot.setText(slot)
        binding.bookingTxtDate.setText(date)
        validDate()
        validSlot()
    }

    private fun createNotificationChannel(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val name:CharSequence = "GaragekuBookingChannel"
            val desc = "Channel for all booking alert"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel("garagekuBooking",name,importance)
            channel.description = desc

            val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun setBookingAlert(bookingID:Int){
        alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this,AlarmReceiver::class.java)
        val content =
            "${getString(com.example.fyp_garageku.R.string.reminder_line1)} ${binding.bookingTxtTimeSlot.text}"
        val title = "${getString(com.example.fyp_garageku.R.string.booking_reminder)} ($name)"
        intent.putExtra("title",title)
        intent.putExtra("content",content)
        val notificationID = System.currentTimeMillis().toInt()
        pendingIntent = PendingIntent.getBroadcast(this, notificationID,intent,0)
        GlobalScope.launch {
            withContext(Dispatchers.IO){
                insertNotification(notificationID,bookingID)
            }
        }
        val cal = Calendar.getInstance()
        cal.timeInMillis = System.currentTimeMillis()
        cal.set(Calendar.YEAR,binding.bookingTxtDate.text.toString().substring(6).toInt())
        cal.set(Calendar.DAY_OF_MONTH,binding.bookingTxtDate.text.toString().substring(0,2).toInt())
        cal.set(Calendar.MONTH,binding.bookingTxtDate.text.toString().substring(3,5).toInt() - 1)
        cal.set(Calendar.HOUR_OF_DAY,binding.bookingTxtTimeSlot.text.toString().substring(0,2).toInt() - 1)
        cal.set(Calendar.MINUTE,binding.bookingTxtTimeSlot.text.toString().substring(2,4).toInt())
        cal.set(Calendar.SECOND,0)

        alarmManager.set(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pendingIntent)

    }
    private fun insertNotification(notificationID:Int,bookingID:Int) {
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)
                Pending_Booking_Notification.insert {
                    it[booking_id] = bookingID
                    it[notification_id] = notificationID
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


}