package com.example.fyp_garageku.admin

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.InputType
import android.util.Base64
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.view.marginLeft
import androidx.core.view.marginRight
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.fyp_garageku.R
import com.example.fyp_garageku.adapters.ManageAdvertisementsAdapter
import com.example.fyp_garageku.adapters.MerchantImageGridAdapter
import com.example.fyp_garageku.dataclass.*
import com.example.fyp_garageku.helper_class.RetrofitInstance
import com.skydoves.expandablelayout.expandableLayout
import com.squareup.picasso.Picasso
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.SqlExpressionBuilder.isNull
import org.jetbrains.exposed.sql.transactions.transaction
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.ByteArrayOutputStream
import java.io.InputStream
import android.widget.LinearLayout





class ManageAdvertisements : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_advertisements)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.title = "Manage Advertisements"

        findViewById<Button>(R.id.add_advertisement_button).setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"

            getPicture.launch(intent)
        }

        loadData()

    }

    private var getPicture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data: Intent? = result.data

            val imgURL  = data?.data

            val layout = LinearLayout(this)
            layout.orientation = LinearLayout.VERTICAL

            val layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            layoutParams.setMargins(20, 0, 20, 0)

            layout.layoutParams = layoutParams

            val previewImageView = ImageView(this)

            val editText = EditText(this)
            editText.hint = "Title"
            editText.inputType = InputType.TYPE_CLASS_TEXT

            val params : ViewGroup.LayoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT )
            previewImageView.layoutParams = params

            Picasso.get()
                .load(imgURL)
                .resize(900,540)
                .centerCrop()
                .into(previewImageView)

            val inputStream = contentResolver.openInputStream(imgURL!!)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            val byteArray = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArray)
            val base64img: String =
                Base64.encodeToString(byteArray.toByteArray(), Base64.DEFAULT)

            layout.addView(editText)
            layout.addView(previewImageView)

            val builder: AlertDialog.Builder = AlertDialog.Builder(this)
            builder.setTitle("Enter title")
            builder.setMessage("Add a title to this advertisement")
            builder.setView(layout)
            builder.setPositiveButton(
                "Yes"
            ) { _, _ ->
                uploadImage(base64img, editText.text.toString())
            }
            builder.setNegativeButton(
                "Cancel"
            ) { dialog, _ ->
                dialog.dismiss()
            }
            builder.show()
        }
    }

    private fun uploadImage(base64img : String, title : String){
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    val newImageID = Advertisement_Images.insert {
                        it[Advertisement_Images.title] = title
                    } get Advertisement_Images.image_id

                    val name = "advertisement$newImageID.jpg"

                    val call: Call<CallResponse> =
                        RetrofitInstance.api.UploadImage(base64img, name)

                    call.enqueue(object : Callback<CallResponse> {
                        override fun onResponse(
                            call: Call<CallResponse>,
                            response: Response<CallResponse>
                        ) {
                            if (response.isSuccessful) {
                                loadData()
                            }
                        }
                        override fun onFailure(call: Call<CallResponse>, t: Throwable) {
                            Toast.makeText(
                                applicationContext,
                                t.message,
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    })

                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

    private fun loadData(){
        val imageRecyclerView = findViewById<RecyclerView>(R.id.image_recyclerview)
        val imageList = ArrayList<String>()
        val imageIDList = ArrayList<Int>()
        val titleList = ArrayList<String>()
        val gridLayoutManager = StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL)
        imageRecyclerView.layoutManager = gridLayoutManager

        //get list of images from database
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    //get data from DB
                    val images = Advertisement_Images.selectAll()

                    for (row in images){
                        val id = row[Advertisement_Images.image_id]
                        val title = row[Advertisement_Images.title]
                        imageList.add("advertisement$id.jpg")
                        imageIDList.add(id)
                        titleList.add(title)
                    }

                    //load data into textview
                    runOnUiThread{
                        val imageGridAdapter = ManageAdvertisementsAdapter(this@ManageAdvertisements, imageList, imageIDList, titleList)
                        imageRecyclerView.adapter = imageGridAdapter
                    }

                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

}