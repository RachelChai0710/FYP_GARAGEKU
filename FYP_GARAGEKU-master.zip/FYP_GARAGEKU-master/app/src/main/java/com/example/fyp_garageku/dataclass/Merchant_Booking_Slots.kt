package com.example.fyp_garageku.dataclass

import com.example.fyp_garageku.dataclass.Merchant_Registrations.autoIncrement
import com.example.fyp_garageku.dataclass.Merchant_Registrations.default
import com.example.fyp_garageku.dataclass.Merchant_Registrations.references
import com.example.fyp_garageku.dataclass.Merchant_Registrations.uniqueIndex
import org.jetbrains.exposed.sql.Table

object Merchant_Booking_Slots: Table() {
    val slot_id = integer("slot_id").autoIncrement()
    val merchant_id = integer("merchant_id")
        .uniqueIndex()
        .references(Merchants.merchant_id)
    val timeslot_id = integer("timeslot_id")
        .uniqueIndex()
        .references(Time_Slots.timeslot_id)
    val max_cust = integer("max_cust")

}