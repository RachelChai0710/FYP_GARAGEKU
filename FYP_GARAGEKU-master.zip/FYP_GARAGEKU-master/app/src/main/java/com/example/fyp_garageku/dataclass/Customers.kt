package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table

object Customers: Table () {
    val cust_id = integer("cust_id").autoIncrement().uniqueIndex()
    val cust_name = varchar("cust_name", 50)
    val cust_phone = varchar("cust_phone", 11)
    val login_type = varchar("login_type", 10)
    val gender = varchar("gender",6)
    val user_id = integer("user_id")
        .references(Users.id)
    val imageURL = text("imageURL")
    override val primaryKey = PrimaryKey(cust_id)
}