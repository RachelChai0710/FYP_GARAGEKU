package com.example.fyp_garageku.admin.viewusers

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.Customers
import com.example.fyp_garageku.dataclass.Merchants
import com.squareup.picasso.Picasso
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.StdOutSqlLogger
import org.jetbrains.exposed.sql.addLogger
import org.jetbrains.exposed.sql.select
import org.jetbrains.exposed.sql.transactions.transaction

class ViewMerchants : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_merchants)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.title = "View User"

        val id = intent.getIntExtra("id", 0)

        val merchantImageView = findViewById<ImageView>(R.id.merchant_imageview)
        val merchantNameTextView = findViewById<TextView>(R.id.merchant_name_textview)
        val websiteTextView = findViewById<TextView>(R.id.website_textview)
        val emailTextView = findViewById<TextView>(R.id.email_textview)
        val phoneNumTextView = findViewById<TextView>(R.id.phone_number_textview)
        val addressTextView = findViewById<TextView>(R.id.address_textview)
        val companyNameTextView = findViewById<TextView>(R.id.company_name_textview)
        val companyNumTextView = findViewById<TextView>(R.id.company_num_textview)
        val sstIDTextView = findViewById<TextView>(R.id.sst_id_textview)
        val ownerNameTextView = findViewById<TextView>(R.id.owner_name_textview)
        val ownerPhoneTextView = findViewById<TextView>(R.id.owner_phone_textview)

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {

                    addLogger(StdOutSqlLogger)
                    //get data from DB
                    val merchant = Merchants.select { Merchants.merchant_id eq id }.first()

                    //load data into textview
                    runOnUiThread{
                        Picasso.get()
                            .load("http://test.onmyfinger.com/images/" + "merchant" + id + "displaypicture.jpg")
                            .placeholder(R.drawable.icon_loading)
                            .error(R.drawable.error)
                            .into(merchantImageView)

                        merchantNameTextView.text = merchant[Merchants.workshop_name]
                        websiteTextView.text = merchant[Merchants.website]
                        emailTextView.text = merchant[Merchants.email_address]
                        phoneNumTextView.text = merchant[Merchants.office_phone]
                        addressTextView.text = merchant[Merchants.address]
                        companyNameTextView.text = merchant[Merchants.company_name]
                        companyNumTextView.text = merchant[Merchants.company_reg_no]
                        sstIDTextView.text = merchant[Merchants.sst_id]
                        ownerNameTextView.text = merchant[Merchants.owner_name]
                        ownerPhoneTextView.text = merchant[Merchants.owner_phone]
                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }
}