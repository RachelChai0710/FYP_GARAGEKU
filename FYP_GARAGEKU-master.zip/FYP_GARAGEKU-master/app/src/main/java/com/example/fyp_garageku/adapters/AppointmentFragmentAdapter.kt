package com.example.fyp_garageku.adapters

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.fyp_garageku.customer.*


class AppointmentFragmentAdapter(fragmentManager: FragmentManager,lifeCycle:Lifecycle) :
    FragmentStateAdapter(fragmentManager,lifeCycle) {

    override fun getItemCount(): Int = 5

    override fun createFragment(position: Int): Fragment {
        when(position){
            1 ->
                return ToApproveAppointmentsFragment()
            2 ->
                return ToServiceAppointmentsFragment()
            3 ->
                return ToReviewAppointmentsFragment()
            4 ->
                return CancelledAppointmentsFragment()
        }
        return AllAppointmentsFragment()
    }


}