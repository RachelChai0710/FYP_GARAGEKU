package com.example.fyp_garageku.helper_class

import android.content.Context
import android.location.Address
import android.location.Geocoder
import java.util.*


class GeocodingLocation {

    fun getAddressFromLocation(address:String, context: Context):Address{
        val geocoder = Geocoder(context, Locale.getDefault())
        return geocoder.getFromLocationName(address, 1)[0]
    }

}