package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table

object Merchants : Table () {
    val merchant_id = integer("merchant_id")
    val workshop_name = varchar("workshop_name", 45)
    val website = varchar("website", 45)
    val address = varchar("address", 100)
    val company_name = varchar("company_name", 45)
    val company_reg_no = varchar("company_reg_no", 45)
    val sst_id = varchar("sst_id", 15)
    val owner_name = varchar("owner_name",45)
    val owner_phone = varchar("owner_phone",11)
    val manager_name = varchar("manager_name",45)
    val manager_phone = varchar("manager_phone",11)
    val email_address = varchar("email_address", 45)
    val office_phone = varchar("office_phone", 11)
    val bank_name = varchar("bank_name", 45)
    val bank_account_name = varchar("bank_account_name", 45)
    val bank_account_number = varchar("bank_account_number", 45)
    val operation_hours = varchar("operation_hours", 45)
    val rating = decimal("rating",2,3)

    val user_id = integer("user_id")
        .uniqueIndex()
        .references(Users.id)
}
