package com.example.fyp_garageku.adapters

import android.content.Context
import android.text.Html
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.BookingSlotData
import com.example.fyp_garageku.dataclass.Time_Slots
import com.example.fyp_garageku.dataclass.VehiclesData
import org.jetbrains.exposed.sql.ResultRow

class BookingSlotAdapter (private val context: Context,
                          private val dataset : List<BookingSlotData>,
                          private val listener: BookingSlotDialogListener
) : RecyclerView.Adapter<BookingSlotAdapter.ItemViewHolder>() {
    private var lastChecked: RadioButton? = null
    private var lastCheckedPos = 0
    private var selectedSlot: String = ""

    interface BookingSlotDialogListener {
        fun onClickRecSlot(slotID: Int, slot:String)
    }

    class ItemViewHolder(private val view : View) : RecyclerView.ViewHolder(view) {
        val txtTo : TextView = view.findViewById(R.id.txtTo)
        val txtFrom : TextView = view.findViewById(R.id.txtFrom)
        val txtSeparator : TextView = view.findViewById(R.id.separator)
        val radSlot:RadioButton = view.findViewById(R.id.rad_slot)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(context)
            .inflate(R.layout.item_booking_slot, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        holder.txtTo.text = item.endTime
        holder.txtFrom.text = item.startTime

        if (item.status == "Unavailable"){
            val strikeEndTime = "<strike><font color=\'#696969\'>${item.endTime}</font></strike>"
            val strikeStartTime = "<strike><font color=\'#696969\'>${item.startTime}</font></strike>"
            val strikeSeparator = "<strike><font color='#696969'>${holder.txtSeparator.text}</font></strike>"
            holder.txtTo.text = Html.fromHtml(strikeEndTime)
            holder.txtFrom.text = Html.fromHtml(strikeStartTime)
            holder.txtSeparator.text = Html.fromHtml(strikeSeparator)
            holder.radSlot.visibility = View.INVISIBLE
        }

        holder.radSlot.tag = position
        if (lastChecked == null){
            holder.radSlot.isChecked = true
        }

        //for default check in first item
        if (position == 0  && holder.radSlot.isChecked) {
            lastChecked = holder.radSlot
            lastCheckedPos = 0
            selectedSlot = "${holder.txtFrom.text} - ${holder.txtTo.text}"
        }

        holder.radSlot.setOnClickListener { v ->
            if (item.status=="Available"){
                val radio = v as RadioButton
                val clickedPos = (radio.tag as Int).toInt()
                if (radio.isChecked) {
                    if (lastChecked != null) {
                        lastChecked!!.isChecked = false
                    }
                    lastChecked = radio
                    lastCheckedPos = clickedPos
                    selectedSlot = "${holder.txtFrom.text} - ${holder.txtTo.text}"
                    item.slotID?.let { listener.onClickRecSlot(it,selectedSlot) }
                } else lastChecked = null
            }
        }


    }

    override fun getItemCount(): Int = dataset.size
}