package com.example.fyp_garageku.dataclass

import org.jetbrains.exposed.sql.Table

object Users:Table() {
    val id = integer("id").autoIncrement()
    val email = varchar("email",40)
    val password = char("password",128)
    val user_type_id = integer("user_type_id")
        .references(UserTypes.id)
    override val primaryKey = PrimaryKey(id)
}