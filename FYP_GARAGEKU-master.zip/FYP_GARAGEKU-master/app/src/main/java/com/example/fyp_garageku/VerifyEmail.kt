package com.example.fyp_garageku

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.fyp_garageku.databinding.ActivityVerifyEmailBinding
import com.example.fyp_garageku.dataclass.Customers
import com.example.fyp_garageku.dataclass.Users
import com.example.fyp_garageku.helper_class.SendEmail
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.StdOutSqlLogger
import org.jetbrains.exposed.sql.addLogger
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.transactions.transaction
import java.text.SimpleDateFormat
import java.util.*

class VerifyEmail : AppCompatActivity() {
    private var emailInput = ""
    private var phone = ""
    private var username = ""
    private var hashedPw = ""
    private var genderInput = ""
    private var code = 0
    private lateinit var binding: ActivityVerifyEmailBinding
    private lateinit var context: Context
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVerifyEmailBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        context = this
        emailInput = intent.getStringExtra("email").toString()
        phone = intent.getStringExtra("phone").toString()
        username = intent.getStringExtra("username").toString()
        hashedPw = intent.getStringExtra("password").toString()
        genderInput = intent.getStringExtra("gender").toString()
        code = intent.getIntExtra("verificationCode", 0)
        val hideEmail = emailInput.replace("(?<=.{3}).(?=.*@)".toRegex(), "*")

        binding.lblVerification.text = "${getString(R.string.verification_code_text)} $hideEmail"
    }

    fun btnResendOnClick(v: View) {
        binding.verifyRegProgressLayout.bringToFront()
        binding.verifyRegProgressLayout.visibility = View.VISIBLE
        val sender = SendEmail()
        val job = GlobalScope.launch() {
            val sdf = SimpleDateFormat("dd/M/yyyy hh:mm:ss")
            code = Random(System.nanoTime()).nextInt(999999 - 100000 + 1) + 100000
            val currentDate = sdf.format(Date())
            val senderEmail = "bait2073mad@gmail.com"
            val password = "bait2073"
            val recipient = emailInput
            val subject = "Registration Email Verification"
            val message = "Dear $username, \n" +
                    "Thank you for registering at " + getString(R.string.company_name) +
                    "\nWe have received your registration on $currentDate.\n" +
                    "Verification Code: " + "$code"
            val result = withContext(Dispatchers.IO) {
                sender.sendEmail(
                    senderEmail,
                    password,
                    recipient,
                    message,
                    subject
                )
            }
            withContext(Dispatchers.Main) {
                if (result) {
                    Toast.makeText(
                        context,
                        "Verification Code has been sent to your email!",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    Toast.makeText(
                        context,
                        "Failed to resend verification code! Please try again.",
                        Toast.LENGTH_LONG
                    ).show()
                }
                binding.verifyRegProgressLayout.visibility = View.GONE
            }

        }
    }

    fun btnValidateOnClick(v: View) {
        binding.verifyRegProgressLayout.bringToFront()
        binding.verifyRegProgressLayout.visibility = View.VISIBLE
        val isInserted = false
        if (binding.verificationPinView.text?.trim().toString().toInt() == code) {
            val job = GlobalScope.launch {
                val isInserted = withContext(Dispatchers.IO){insertToDB()}
                withContext(Dispatchers.Main) {
                    if (isInserted) {
                        Toast.makeText(
                            context,
                            "You has successfully registered!",
                            Toast.LENGTH_LONG
                        ).show()
                        val intent = Intent (context, Login::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(
                            context,
                            "Failed to register! Please try again.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    binding.verifyRegProgressLayout.visibility = View.GONE
                }
            }

        }
        else{
            Toast.makeText(this,getString(R.string.verification_error),Toast.LENGTH_LONG).show()
        }
    }


    private suspend fun insertToDB():Boolean {
        var inserted = false
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)
                val userID = Users.insert {
                    it[Users.email] = emailInput
                    it[password] = hashedPw
                    it[user_type_id] = 2
                } get Users.id

                val custID = Customers.insert {
                    it[user_id] = userID
                    it[cust_name] = username
                    it[login_type] = "email"
                    it[cust_phone] = phone
                    it[Customers.gender] = genderInput
                } get Customers.cust_id
                inserted = true
            }

        } catch (e: Exception) {
            e.printStackTrace()
            inserted = false
        }
        return inserted
    }

}