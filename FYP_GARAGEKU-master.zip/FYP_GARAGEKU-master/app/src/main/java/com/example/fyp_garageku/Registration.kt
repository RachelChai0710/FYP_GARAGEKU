package com.example.fyp_garageku

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import com.example.fyp_garageku.customer.registration.RegistrationFragment
import com.example.fyp_garageku.databinding.ActivityRegistrationBinding
import com.example.fyp_garageku.merchant.registration.Registration

class Registration : AppCompatActivity() {
    private lateinit var binding: ActivityRegistrationBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistrationBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter.createFromResource(
            this,
            R.array.type_of_acc,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            // Apply the adapter to the spinner
            binding.typeOfAccSpinner.adapter = adapter
        }
        binding.typeOfAccSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {
                }

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    val type = parent?.getItemAtPosition(position).toString()
                    val manager = supportFragmentManager
                    when(type){
                        "Customer" -> {
                            val fragment = RegistrationFragment()
                            val transaction = manager.beginTransaction()
                            transaction.replace(R.id.registration_frag_view, fragment)
                            transaction.commit()
                        }
                        "Merchant" -> {
                            val fragment = Registration()
                            val transaction = manager.beginTransaction()
                            transaction.replace(R.id.registration_frag_view, fragment)
                            transaction.commit()
                        }
                    }
                }
            }
    }

}