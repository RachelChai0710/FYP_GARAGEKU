package com.example.fyp_garageku.dataclass

import com.example.fyp_garageku.dataclass.Admins.autoIncrement
import com.example.fyp_garageku.dataclass.Admins.references
import com.example.fyp_garageku.dataclass.Admins.uniqueIndex
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table

object Time_Slots:Table(){
    val timeslot_id: Column<Int> = integer("timeslot_id")
        .autoIncrement()
        .uniqueIndex()
    val day: Column<String> = varchar("day", 45)
    val start_time: Column<String> = varchar("start_time", 45)
    val end_time: Column<String> = varchar("end_time", 45)
}