package com.example.fyp_garageku.adapters

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.Advertisement_Images
import com.squareup.picasso.Picasso
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.StdOutSqlLogger
import org.jetbrains.exposed.sql.addLogger
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.transactions.transaction

class ManageAdvertisementsAdapter (private val context: Context,
                                   private val images: ArrayList<String>,
                                   private val imageID: ArrayList<Int>,
                                   private val titles: ArrayList<String>) :
    RecyclerView.Adapter<ManageAdvertisementsAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imageView : ImageView = view.findViewById(R.id.imageview)
        val textView : TextView = view.findViewById(R.id.textview)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_grid_image_long, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        holder.textView.text = titles[position]

        val path = images[position]

        Picasso.get()
            .load("http://test.onmyfinger.com/images/$path")
            .placeholder(R.drawable.icon_loading)
            .resize(900, 540)
            .centerCrop()
            .into(holder.imageView)

        holder.imageView.setOnClickListener {
            //handle click event on image
            val builder: AlertDialog.Builder = AlertDialog.Builder(context)
            builder.setTitle("Confirm")
            builder.setMessage("Remove this advertisement?")
            builder.setPositiveButton(
                "Yes"
            ) { _, _ ->
                removeImage(imageID[position])
                deleteItem(position)
            }
            builder.setNegativeButton(
                "Cancel"
            ) { dialog, _ ->
                dialog.dismiss()
            }
            builder.show()
        }
    }

    private fun removeImage(imageID : Int){
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    Advertisement_Images.deleteWhere { Advertisement_Images.image_id eq imageID }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

    override fun getItemCount() = images.size

    private fun deleteItem(position: Int){
        images.removeAt(position)
        imageID.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, images.size)
    }
}   
