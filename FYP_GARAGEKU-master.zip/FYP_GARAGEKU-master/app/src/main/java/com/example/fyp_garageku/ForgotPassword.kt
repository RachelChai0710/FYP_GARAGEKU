package com.example.fyp_garageku

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.fyp_garageku.databinding.ActivityForgotPasswordBinding
import com.example.fyp_garageku.dataclass.Users
import com.example.fyp_garageku.helper_class.SendEmail
import com.example.fyp_garageku.helper_class.Validation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction
import java.text.SimpleDateFormat
import java.util.*
import java.util.Random
import java.util.concurrent.TimeUnit

class ForgotPassword : AppCompatActivity() {
    private lateinit var binding: ActivityForgotPasswordBinding
    private var code = 0
    private val validator = Validation()
    private var email = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityForgotPasswordBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.forgotPwTxtEmail.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                email = binding.forgotPwTxtEmail.text?.trim().toString()
                validateEmail()
            }
        })
    }

    fun sendOnClick(v: View) {
        email = binding.forgotPwTxtEmail.text?.trim().toString()
        if (validateEmail()) {
            binding.forgotPwProgress.bringToFront()
            binding.forgotPwProgress.visibility = View.VISIBLE
            val sender = SendEmail()
            val sdf = SimpleDateFormat("dd/M/yyyy HH:mm:ss")
            code = Random(System.nanoTime()).nextInt(999999 - 100000 + 1) + 100000
            val currentDate = sdf.format(Date())
            val senderEmail = getString(R.string.official_email)
            val password = getString(R.string.email_pw)
            val subject = "Forgot Password Verification Code"
            val message = "Dear Customer, \n" +
                    "You have requested the reset password verification code on $currentDate. \n" +
                    "Verification Code: " + "$code"
            GlobalScope.launch {
                val isExist = withContext(Dispatchers.IO) { checkEmail() }
                if (isExist) {
                    withContext(Dispatchers.Main){
                        binding.resendMessage.visibility = View.VISIBLE
                        binding.forgotPwBtnSend.isEnabled = false
                    }
                    val isSent = withContext(Dispatchers.IO) {
                        sender.sendEmail(
                            senderEmail,
                            password,
                            email,
                            message,
                            subject
                        )
                    }
                    if (isSent) {
                        withContext(Dispatchers.Main) {
                            binding.forgotPwCode.visibility = View.VISIBLE
                            binding.forgotPwLblCode.visibility = View.VISIBLE
                            binding.forgotPwProgress.visibility = View.GONE
                            binding.forgotPwBtnSubmit.isEnabled = true
                        }
                    } else {
                        withContext(Dispatchers.Main) {
                            binding.forgotPwCode.visibility = View.GONE
                            binding.forgotPwLblCode.visibility = View.GONE
                            binding.forgotPwProgress.visibility = View.GONE
                            binding.forgotPwBtnSubmit.isEnabled = false
                        }
                    }
                    withContext(Dispatchers.Main){ updateTime()}

                } else {
                    withContext(Dispatchers.Main) {
                       binding.forgotPwEmail.error = getString(R.string.email_not_exist)
                        binding.forgotPwProgress.visibility = View.GONE
                    }
                }
            }

        }
    }

    private suspend fun checkEmail(): Boolean {
        var isExist = false
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)
                //get data from DB
                val user = Users.selectAll().forEach {
                    if (it[Users.email].equals(email)) {
                        isExist = true
                    }
                }

            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return isExist
    }

    fun submitOnClick(v: View) {
        if (validateCode()) {
            if (binding.forgotPwCode.text?.trim().toString().toInt() == code) {
                val intent = Intent(this, RecoveryPassword::class.java)
                intent.putExtra("email", email)
                startActivity(intent)
                finish()
            } else {
                binding.forgotPwCode.error = getString(R.string.verification_error)
            }
        }
    }

    private fun updateTime() {
        //60s timer
        val duration = TimeUnit.MINUTES.toMillis(1)

        object : CountDownTimer(duration, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                binding.resendMessage.text =
                    getString(R.string.forgot_pw_alert) + " " + millisUntilFinished / 1000 + "s."
            }

            override fun onFinish() {
                binding.forgotPwBtnSend.isEnabled = true
                binding.resendMessage.text = getString(R.string.forgot_pw_alert) + " 0s."
            }
        }.start()

    }

    private fun validateEmail(): Boolean {
        return !validator.isNull(email, binding.forgotPwEmail)
    }

    private fun validateCode(): Boolean {
       if (binding.forgotPwCode.text?.trim().toString().isNullOrBlank()){
           Toast.makeText(this,"Please enter the verification code!",Toast.LENGTH_LONG).show()
       }
        return !binding.forgotPwCode.text?.trim().toString().isNullOrBlank()
    }

}