package com.example.fyp_garageku.dataclass

data class AppointmentsData(val bookingID:Int? = 0,
                            val merchantID:Int? = 0,
                            val bookedDate:String? = "",
                            val slot:String? = "",
                            var status:String? = "",
                            val name:String? = "",
                            val vehicle:String? = "",
                            val service:String? = "")
