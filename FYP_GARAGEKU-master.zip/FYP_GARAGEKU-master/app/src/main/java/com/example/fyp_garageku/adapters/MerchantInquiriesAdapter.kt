package com.example.fyp_garageku.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.dataclass.MerchantInquiriesData
import com.example.fyp_garageku.dataclass.Quotations
import com.example.fyp_garageku.merchant.inquiries.InquiriesReply
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction


class MerchantInquiriesAdapter (private val context: Context,
                                val dataset : ArrayList<MerchantInquiriesData>,
                                private val selectedType : String,
                                val fragment : Fragment
) : RecyclerView.Adapter<MerchantInquiriesAdapter.ItemViewHolder>() {

    class ItemViewHolder(private val view: View) : RecyclerView.ViewHolder(view) {
        val vehicleTextView : TextView = view.findViewById(R.id.vehicle_textview)
        val dateTextView : TextView = view.findViewById(R.id.date_textview)
        val servicesTextView : TextView = view.findViewById(R.id.services_textview)
        val layout : LinearLayout = view.findViewById(R.id.item_layout)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_merchant_inquiries, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        holder.vehicleTextView.text = item.vehicle
        holder.dateTextView.text = item.date
        var servicesText = ""
        for (service in item.services){
            servicesText = servicesText + service + "\n"
        }
        servicesText = servicesText.trim()
        holder.servicesTextView.text = servicesText

        holder.layout.setOnClickListener {
            if (selectedType != "Replied") {
                //update status to read
                val thread = Thread {
                    try {
                        Database.connect(
                            "jdbc:mysql://110.4.46.121/carportal",
                            "com.mysql.jdbc.Driver",
                            "fyp", "fyp2020"
                        )
                        transaction {
                            addLogger(StdOutSqlLogger)
                            Quotations.update({ Quotations.quote_id eq item.quoteID }) {
                                it[status] = "Read"
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                thread.start()

                val intent = Intent(context, InquiriesReply::class.java)
                intent.putExtra("id", item.quoteID)
                intent.putExtra("service", servicesText)
                intent.putExtra("customer", item.customer)
                intent.putExtra("vehicle", item.vehicle)
                intent.putExtra("date", item.date)
                intent.putExtra("description", item.description)
                fragment.startActivityForResult(intent, 12)
            }
        }

    }

    override fun getItemCount() = dataset.size

    private fun clear() {
        val size: Int = dataset.size
        if (size > 0) {
            for (i in 0 until size) {
                dataset.removeAt(0)
            }
            notifyItemRangeRemoved(0, size)
        }
    }

    private fun deleteItem(position: Int){
        dataset.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, dataset.size)
    }

}
