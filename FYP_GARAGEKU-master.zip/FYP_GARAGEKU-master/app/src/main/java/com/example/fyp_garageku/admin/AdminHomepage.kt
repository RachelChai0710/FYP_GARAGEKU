package com.example.fyp_garageku.admin

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.LinearLayout
import com.example.fyp_garageku.Login
import com.example.fyp_garageku.R
import com.example.fyp_garageku.admin.manageservices.ManageCategories
import com.example.fyp_garageku.admin.viewusers.ViewUsers

class AdminHomepage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_homepage)

        supportActionBar?.title = "Administrator Homepage"

        //set onclick events for layouts
        findViewById<LinearLayout>(R.id.manage_advertisements_layout).setOnClickListener {
            val intent = Intent(this, ManageAdvertisements::class.java)
            startActivity(intent)
        }
        findViewById<LinearLayout>(R.id.manage_categories_layout).setOnClickListener {
            val intent = Intent(this, ManageCategories::class.java)
            startActivity(intent)
        }
        findViewById<LinearLayout>(R.id.approve_registrations_layout).setOnClickListener {
            val intent = Intent(this, ApproveRegistrations::class.java)
            startActivity(intent)
        }
        findViewById<LinearLayout>(R.id.view_users_layout).setOnClickListener {
            val intent = Intent(this, ViewUsers::class.java)
            startActivity(intent)
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.sign_out_menu, menu)
        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.sign_out){
            val editor = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)?.edit()
            editor?.clear()?.apply()
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
            finish()
            return super.onOptionsItemSelected(item)
        }
        return super.onOptionsItemSelected(item)
    }
}