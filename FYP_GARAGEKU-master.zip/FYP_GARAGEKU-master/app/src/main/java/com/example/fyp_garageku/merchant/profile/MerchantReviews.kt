package com.example.fyp_garageku.merchant.profile

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.annotation.RequiresApi
import androidx.core.widget.NestedScrollView
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fyp_garageku.adapters.ReviewsAdapter
import com.example.fyp_garageku.databinding.ActivityAllReviewsBinding
import com.example.fyp_garageku.dataclass.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.*

class MerchantReviews : AppCompatActivity() {
    private lateinit var binding: ActivityAllReviewsBinding
    private var startIndex:Long = 0
    private lateinit var myAdapter: ReviewsAdapter
    private var reviewList = mutableListOf<ReviewData>()
    private var merchantId = 0

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.title = "Reviews"

        binding = ActivityAllReviewsBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        initiateRecycleView()
        merchantId = intent.getIntExtra("workshopID",0)
        binding.allReviewsNestedScrollView.setOnScrollChangeListener(NestedScrollView.OnScrollChangeListener { v, scrollX, scrollY, oldScrollX, oldScrollY ->
            val view: View = v.getChildAt(v.childCount - 1)
            val diff: Int =
                view.bottom + v.paddingBottom - (v.height + v.scrollY)
            if (diff == 0) {
                startIndex += 10
                binding.allReviewsProgress.visibility = View.VISIBLE
                initiateRecycleView()
            }
        })
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun initiateRecycleView(){
        binding.allReviewsRecReview.removeAllViewsInLayout()
        binding.allReviewsProgress.bringToFront()
        binding.allReviewsProgress.visibility = View.VISIBLE
        GlobalScope.launch {
            withContext(Dispatchers.IO){
                loadReview()
            }
            withContext(Dispatchers.Main) {
                if(reviewList.isNotEmpty()){
                    val layoutManager =
                        LinearLayoutManager(this@MerchantReviews, LinearLayoutManager.VERTICAL, false)
                    binding.allReviewsRecReview.layoutManager = layoutManager
                    binding.allReviewsRecReview.addItemDecoration(
                        DividerItemDecoration(
                            binding.allReviewsRecReview.context,
                            layoutManager.orientation
                        )
                    )
                    val myAdapter = ReviewsAdapter(this@MerchantReviews, reviewList)
                    binding.allReviewsRecReview.adapter = myAdapter
                    binding.allReviewsRecReview.setHasFixedSize(true)
                    binding.allReviewsProgress.visibility = View.GONE
                    binding.allReviewsRecReview.visibility = View.VISIBLE
                }
                else{
                    binding.allReviewsRecReview.visibility = View.GONE
                }
            }
        }

    }

    @RequiresApi(Build.VERSION_CODES.O)
    private suspend fun loadReview(){
        try {
            Database.connect(
                "jdbc:mysql://110.4.46.121/carportal",
                "com.mysql.jdbc.Driver",
                "fyp", "fyp2020"
            )
            transaction {
                addLogger(StdOutSqlLogger)

                Reviews.join(Bookings, JoinType.INNER,null, null){
                    Reviews.booking_id eq Bookings.booking_id
                }
                    .join(Customers, JoinType.INNER,null,null){
                        (Bookings.cust_id eq Customers.cust_id)
                    }
                    .select(Op.build { Bookings.merchant_id eq merchantId })
                    .limit(10,startIndex)
                    .orderBy(Reviews.review_date, SortOrder.DESC).map {
                        val formatter: DateTimeFormatter =
                            DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT)
                                .withLocale(Locale.UK)
                                .withZone(ZoneId.systemDefault())
                        val formattedDate = formatter.format(it[Reviews.review_date])

                        val serviceList = Booking_Services.join(Services,JoinType.INNER, null, null) {
                            (Booking_Services.service_id eq Services.service_id)
                        }
                            .select(Op.build { Booking_Services.booking_id eq it[Bookings.booking_id] }).toMutableList()
                        var service = ""
                        for (item in serviceList){
                            service += if (item[Services.name] == serviceList.last()[Services.name]){
                                "${item[Services.name]}"
                            } else
                                "${item[Services.name]} \n"
                        }

                        reviewList.add(ReviewData(
                            it[Customers.cust_name],
                            it[Reviews.review],
                            it[Customers.imageURL],
                            formattedDate,
                            it[Reviews.anonymous],
                            it[Reviews.rating].toFloat(),
                            service
                        ))
                    }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}