package com.example.fyp_garageku.merchant.editprofile

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.fyp_garageku.R
import com.example.fyp_garageku.adapters.MerchantImageGridAdapter
import com.example.fyp_garageku.dataclass.*
import com.example.fyp_garageku.helper_class.RetrofitInstance
import com.squareup.picasso.Picasso
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.ByteArrayOutputStream

class EditMerchantPhotos : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_merchant_photos)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.title = "Manage Photos"

        findViewById<Button>(R.id.add_photo_button).setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"

            getPicture.launch(intent)
        }

        loadData()
    }

    private var getPicture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data: Intent? = result.data

            val imgURL  = data?.data

            val previewImageView = ImageView(this)

            val params : ViewGroup.LayoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT )
            previewImageView.layoutParams = params

            Picasso.get()
                .load(imgURL)
                .resize(800,800)
                .centerCrop()
                .into(previewImageView)

            val inputStream = contentResolver.openInputStream(imgURL!!)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            val byteArray = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArray)
            val base64img: String =
                Base64.encodeToString(byteArray.toByteArray(), Base64.DEFAULT)

            val builder: AlertDialog.Builder = AlertDialog.Builder(this@EditMerchantPhotos)
            builder.setTitle("Confirm")
            builder.setMessage("Upload this image?")
            builder.setView(previewImageView)
            builder.setPositiveButton(
                "Yes"
            ) { _, _ ->
                uploadImage(base64img)
            }
            builder.setNegativeButton(
                "Cancel"
            ) { dialog, _ ->
                dialog.dismiss()
            }
            builder.show()
        }
    }

    private fun uploadImage(base64img : String){
        val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        var userID = 0
        userID = sharedPref?.getString("id","")?.toInt()!!

        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    val newImageID = Merchant_Images.insert {
                        it[merchant_id] = userID
                    } get Merchant_Images.image_id

                    val name = "merchant_image_$newImageID.jpg"

                    Log.d("name", name)

                    val call: Call<CallResponse> =
                        RetrofitInstance.api.UploadImage(base64img, name)

                    call.enqueue(object : Callback<CallResponse> {
                        override fun onResponse(
                            call: Call<CallResponse>,
                            response: Response<CallResponse>
                        ) {
                            if (response.isSuccessful) {
                                loadData()
                            }
                        }
                        override fun onFailure(call: Call<CallResponse>, t: Throwable) {
                            Toast.makeText(
                                applicationContext,
                                t.message,
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    })

                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }

    private fun loadData(){
        val sharedPref = getSharedPreferences("GaragekuSP", Context.MODE_PRIVATE)
        var userID = 0
        userID = sharedPref?.getString("id","")?.toInt()!!

        val imageRecyclerView = findViewById<RecyclerView>(R.id.image_recyclerview)
        val imageList = ArrayList<String>()
        val imageIDList = ArrayList<Int>()
        val gridLayoutManager = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        imageRecyclerView.layoutManager = gridLayoutManager

        //get list of images from database
        val thread = Thread {
            try {
                Database.connect(
                    "jdbc:mysql://110.4.46.121/carportal",
                    "com.mysql.jdbc.Driver",
                    "fyp", "fyp2020"
                )
                transaction {
                    addLogger(StdOutSqlLogger)

                    //get data from DB
                    val images = Merchant_Images.select(Op.build { Merchant_Images.merchant_id eq userID})

                    for (row in images){
                        val id = row[Merchant_Images.image_id]
                        imageList.add("merchant_image_$id.jpg")
                        imageIDList.add(id)
                    }

                    //load data into textview
                    runOnUiThread{
                        val imageGridAdapter = MerchantImageGridAdapter(this@EditMerchantPhotos, imageList, imageIDList)
                        imageRecyclerView.adapter = imageGridAdapter
                    }

                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()


    }

}