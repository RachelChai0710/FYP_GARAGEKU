package com.example.fyp_garageku.adapters

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.fyp_garageku.R
import com.example.fyp_garageku.customer.DialogBookingSlotFragment
import com.example.fyp_garageku.customer.DialogVehicleFragment
import org.jetbrains.exposed.sql.ResultRow
import java.text.DateFormatSymbols
import java.text.SimpleDateFormat
import java.util.*

class DaysAdapter(
    private val context: Context,
    private val dataset: List<Calendar>,
    private val listener: DayDialogListener
) : RecyclerView.Adapter<DaysAdapter.ItemViewHolder>() {
    private var selected = 0
    private var selectedCardView: CardView? = null
    private var selectTxtDay: TextView? = null
    private var selectTxtDate: TextView? = null

    interface DayDialogListener {
        fun onClickRecDay(day:String,date:String,intDay:Int)
    }

    class ItemViewHolder(view : View) : RecyclerView.ViewHolder(view) {
        val txtDate : TextView = view.findViewById(R.id.recDays_date)
        val txtDay : TextView = view.findViewById(R.id.recDays_day)
        val item:CardView = view.findViewById(R.id.card_view_dayDate)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(context)
            .inflate(R.layout.item_days, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    @RequiresApi(Build.VERSION_CODES.M)
    @SuppressLint("ResourceAsColor")
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val weekdays: Array<String> = DateFormatSymbols(Locale.ENGLISH).weekdays
        val months: Array<String> = DateFormatSymbols(Locale.ENGLISH).months
        val day = weekdays[dataset[position].get(Calendar.DAY_OF_WEEK)]
        val date = dataset[position].get(Calendar.DAY_OF_MONTH).toString() + " " +months[dataset[position].get(Calendar.MONTH)]
        val sdf = SimpleDateFormat("dd/MM/yyyy")
        val formattedDate = sdf.format(dataset[position].time)
        holder.txtDay.text = day
        holder.txtDate.text = date

        //default selected view
        if (selected == 0 && selectedCardView == null){
            holder.item.setCardBackgroundColor(context.getColor(R.color.mariner))
            holder.txtDay.setTextColor(context.getColor(R.color.white))
            holder.txtDate.setTextColor(context.getColor(R.color.white))
            selectedCardView = holder.item
            selectTxtDay = holder.txtDay
            selectTxtDate = holder.txtDate
            listener.onClickRecDay(day,formattedDate,dataset[position].get(Calendar.DAY_OF_WEEK))
        }

        holder.itemView.setOnClickListener {
            selectedCardView?.setCardBackgroundColor(context.getColor(R.color.white))
            selectTxtDay?.setTextColor(context.getColor(R.color.black))
            selectTxtDate?.setTextColor(context.getColor(R.color.black))
            holder.item.setCardBackgroundColor(context.getColor(R.color.mariner))
            holder.txtDay.setTextColor(context.getColor(R.color.white))
            holder.txtDate.setTextColor(context.getColor(R.color.white))
            selectedCardView = holder.item
            selectTxtDay = holder.txtDay
            selectTxtDate = holder.txtDate
            listener.onClickRecDay(day,formattedDate,dataset[position].get(Calendar.DAY_OF_WEEK))
        }
    }

    override fun getItemCount(): Int = dataset.size

}